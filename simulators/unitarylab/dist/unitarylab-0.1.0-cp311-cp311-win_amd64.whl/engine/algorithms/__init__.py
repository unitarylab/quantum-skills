"""
Quantum Algorithms Module
=========================

This module provides quantum algorithms including:
- schrodingerization: Schrödingerization for PDE solving
- simon: Simon's algorithm
- shor: Shor's algorithm
"""


from .schrodingerization import (
    HeatEquationAlgorithm,
    AdvectionEquationAlgorithm,
    backHeatEquationAlgorithm,
    Heat2dEquationAlgorithm,
)

from .cryptology import SimonAlgorithm,ShorAlgorithm,DiscreteLogAlgorithm
from .hamiltonian_simulation import SuzukiTrotterAlgorithm,QDriftAlgorithm
from .fundamental_algorithm import AmplitudeAmplificationAlgorithm,HadamardTransformAlgorithm,HadamardTestAlgorithm,AmplitudeEstimationAlgorithm,QPEAlgorithm
from .linear_algebra import LCUAlgorithm,QSPAlgorithm,HHLAlgorithm
from .quantum_machine_learning import QNNAlgorithm,QCBMAlgorithm,QAOAAlgorithm,VQEAlgorithm,VQCAlgorithm


__all__ = [
    # PDE Solving
    "HeatEquationAlgorithm",
    "AdvectionEquationAlgorithm",
    "backHeatEquationAlgorithm",
    "Heat2dEquationAlgorithm",
    
    # cryptology algorithm
    "SimonAlgorithm",
    "ShorAlgorithm",
    "DiscreteLogAlgorithm",

    #hamiltonian_simulation
    "SuzukiTrotterAlgorithm",
    "QDriftAlgorithm",

    #fundamental_algorithm
    "AmplitudeAmplificationAlgorithm",
    "HadamardTransformAlgorithm",
    "HadamardTestAlgorithm",
    "AmplitudeEstimationAlgorithm",
    "QPEAlgorithm",

    #linear_algebra
    "LCUAlgorithm",
    "HHLAlgorithm",
    "QSPAlgorithm",

    #quantum_machine_learning
    "QNNAlgorithm",
    "QCBMAlgorithm",
    "VQCAlgorithm",
    "QAOAAlgorithm",
    "VQEAlgorithm",
]
