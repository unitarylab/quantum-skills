"""
Schrödingerization Module
=========================

This module provides quantum algorithms for solving partial differential equations (PDEs):
"""

from .equation_heat import HeatEquationAlgorithm
from .equation_advection import AdvectionEquationAlgorithm
from .equation_backHeat import backHeatEquationAlgorithm
from .equation_heat2d import Heat2dEquationAlgorithm


__all__ = [
    "HeatEquationAlgorithm",
    "AdvectionEquationAlgorithm",
    "backHeatEquationAlgorithm",
    "Heat2dEquationAlgorithm",
]