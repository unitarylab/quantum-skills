"""
Quantum classical_register implementation for enhanced quantum circuit simulation.
"""
import uuid

class ClassicalRegister:
    """
    Classical register used to store measurement results of qubits.
    """
    def __init__(self, name: str, n_bits: int):
        self.name = name
        self.n_qubits = n_bits  
        self.id = uuid.uuid4().hex
        # Initialize storage space, defaulting all values to -1
        self.values = [-1] * n_bits 

    def __getitem__(self, index):
        """
        Consistent with Register logic, returns a list of tuples containing (self, indices).
        """
        if isinstance(index, slice):
            indices = list(range(self.n_qubits))[index]
        elif isinstance(index, tuple):
            indices = list(index)
        elif isinstance(index, list):
            indices = index
        elif isinstance(index, int):
            indices = [index]
        else:
            raise TypeError(f"Indices must be int, slice, or list, not {type(index).__name__}")

        # Range validation
        if max(indices) >= self.n_qubits or min(indices) < -self.n_qubits:
            raise IndexError(f"Index {indices} out of range for '{self.name}'")

        return [(self, indices)]

    def __repr__(self):
        return f"ClassicalRegister(name='{self.name}', n_bits={self.n_qubits}), values={self.values})"

    def __len__(self):
        return self.n_qubits