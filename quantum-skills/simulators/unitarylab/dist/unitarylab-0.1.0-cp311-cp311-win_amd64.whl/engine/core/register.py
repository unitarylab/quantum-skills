"""
Quantum register implementation for enhanced quantum circuit simulation.
"""

import uuid


class Register:
    """
    Quantum register representing a group of qubits.

    A register provides indexing utilities so qubits can be accessed
    using Python-style indexing (e.g. r[0], r[1:3], r[[0,2]]).
    """

    def __init__(self, name: str, n_qubits: int):
        """
        Create a quantum register.

        """
        self.name = name
        self.n_qubits = n_qubits
        self.id = uuid.uuid4().hex

    def __getitem__(self, index):
        """
        Access qubits inside the register.
        """
        if isinstance(index, slice):
            indices = list(range(self.n_qubits))[index]

        elif isinstance(index, tuple):
            indices = list(index)

        elif isinstance(index, list):
            indices = index

        elif isinstance(index, int):
            indices = [index]

        else:
            raise TypeError(
                f"Register indices must be integers, slices, or lists, not {type(index).__name__}"
            )

        if max(indices) >= self.n_qubits or min(indices) < -self.n_qubits:
            raise IndexError(
                f"Register index {indices} out of range for register '{self.name}' with {self.n_qubits} qubits"
            )

        return [(self, indices)]

    def __repr__(self):
        """
        Return a readable string representation of the register.
        """
        return f"Register(name='{self.name}', n_qubits={self.n_qubits})"

    def __len__(self):
        """
        Return the number of qubits in the register.
        """
        return self.n_qubits

    def __eq__(self, other):
        """
        Check if two registers represent the same object.

        Registers are considered equal if they share the same unique ID.
        """
        if not isinstance(other, Register):
            return False
        return self.id == other.id

    def __hash__(self):
        """
        Return a hash value so the register can be used as dictionary keys.
        """
        return hash((self.name, self.n_qubits, self.id))