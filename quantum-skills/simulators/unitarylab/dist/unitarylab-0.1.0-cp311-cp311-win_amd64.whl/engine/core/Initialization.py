"""
Construct a quantum circuit for preparing a given normalized quantum state vector.
"""

from .gate_sequence import GateSequence
import numpy as np


def state_preparation(v, backend='torch'):
    """
    Prepare a quantum state circuit that initializes qubits to a given state vector.

    This function constructs a quantum circuit that prepares the input normalized
    state vector |v⟩ using a recursive decomposition method.

    Parameters
    ----------
    v : array-like
        Target state vector (must be normalized and length = 2^n).

    backend : str, optional
        Backend used for the circuit (default: 'torch').

    Returns
    -------
    GateSequence
        Quantum circuit that prepares the state |v⟩.
    """

    # Convert list to numpy array
    if isinstance(v, list):
        v = np.array(v)

    eps = 1e-12

    # Check if the input vector is normalized
    if abs(np.linalg.norm(v) - 1) > eps:
        raise ValueError('The vector is not unit!')

    # Determine number of qubits
    nx = int(np.log2(v.shape[0]))

    # Create quantum circuit
    qc = GateSequence(nx, name='state', backend=backend)

    # Base case: single qubit state preparation
    if nx == 1:

        # Extract phases of amplitudes
        p1 = np.angle(v[0])
        p2 = np.angle(v[1])

        # Compute rotation angle
        theta = np.arccos(np.abs(v[0]))

        # Apply global phase
        if abs(p1) > eps:
            qc.gp(p1)

        # Apply Y rotation to control amplitude
        if abs(theta) > eps:
            qc.ry(2 * theta, 0)

        # Apply relative phase
        if abs(p2 - p1) > eps:
            qc.p(p2 - p1, 0)

        return qc

    # Recursive case: split vector into two halves
    v1, v2 = v[:2**(nx-1)], v[2**(nx-1):]

    norm1, norm2 = np.linalg.norm(v1), np.linalg.norm(v2)

    # Compute rotation to distribute probability
    theta = np.arccos(norm1)

    qc.ry(2 * theta, nx-1)

    # Prepare first half state conditioned on control qubit = 0
    if abs(norm1) > eps:
        qc.append(
            state_preparation(v1 / norm1, backend=backend),
            target=range(nx-1),
            control=nx-1,
            control_sequence='0'
        )

    # Prepare second half state conditioned on control qubit = 1
    if abs(norm2) > eps:
        qc.append(
            state_preparation(v2 / norm2, backend=backend),
            target=range(nx-1),
            control=nx-1,
            control_sequence='1'
        )

    return qc