"""
Enhanced GateSequence implementation that inherits from unitarylab's GateSequence
with added register management and drawing functionality.
"""

from typing import Union, List
from ..backend import get_backend_gate_sequence, get_backend
from .register import Register
from .classical_register import ClassicalRegister
import numpy as np

class GateSequence:
    """
    GateSequence wrapper that uses an instance of unitarylab's GateSequence
    (composition instead of inheritance) for gate operations and other core
    functionality.
    """
    
    def __init__(self, *args, **kwargs):
        """
        Quantum Gate Sequence Container.

        This class provides a high-level interface for constructing and
        manipulating quantum circuits.

        It wraps the backend ``GateSequence`` implementation and adds:

        - Register management
        - Global qubit indexing
        - Circuit composition
        - Visualization support
        - Backend abstraction

        Parameters
        ----------
        num_qubits : int
            Number of qubits in the circuit.

        registers : Register
            Quantum registers used in the circuit.

        name : str, optional
            Circuit name.

        backend : str, optional
            Backend type used for gate execution.

        Notes
        -----
        This class uses **composition instead of inheritance** to wrap
        the backend GateSequence implementation.
        """
        self.registers = []  # List of registers used in this circuit
        self._register_mappings = {}  # {register_name: {'start': start_qubit, 'end': end_qubit}}
        self._total_qubits = 0
        self._used_qubits = set()
        self._matrix = None
        self._backend=""

        self.classical_registers = []        # List of cl_registers used in this circuit
        self._cl_register_mappings = {}      # {cl_register_name: {'start': start_cl_qubit, 'end': end_cl_qubit}}
        self._total_clbits = 0               
        self._measure_map = []               # map：[(Quantum_qubit_global_index, Cl_register_global_index), ...]
        
        incoming_regs=[]

        if len(args) >= 1 and isinstance(args[0], int):
            # Called with num_qubits: GateSequence(num_qubits, ...)
            num_qubits = args[0]
            incoming_regs.append(Register("q", num_qubits))
            
            # Check whether all subsequent parameters are classical registers.
            if len(args) > 1:
                remaining_args = args[1:]
                if not all(isinstance(r, ClassicalRegister) for r in remaining_args):
                    raise ValueError(
                        "When the first argument is an integer, the subsequent arguments must be ClassicalRegister objects. "
                    )
                incoming_regs.extend(remaining_args)
        
        elif len(args) >= 1:
            # Called with register and cl_register objects : GateSequence(register1,cl_register1, ...)
            incoming_regs = args
            if not all(isinstance(r, (Register, ClassicalRegister)) for r in incoming_regs):
                raise ValueError(
                    "The parameter must be a Register or ClassicalRegister object, or start with an integer to indicate the number of qubits."
                )
        else:
            raise ValueError("GateSequence: At least one parameter (bit count or register object) is required.")
        # Add registers and cl_registers to mapping (this assigns global qubit indices)
        for reg in incoming_regs:
            if isinstance(reg, Register):
                self.add_register(reg)
            elif isinstance(reg, ClassicalRegister):
                self.add_classical_register(reg)

        name = kwargs.get('name', 'Sequence')
        self.name = name
        self._backend = get_backend()
        OriginalGateSequence = get_backend_gate_sequence()
        # Initialize underlying OriginalGateSequence instance with total number of qubits
        self._seq = OriginalGateSequence(self._total_qubits, name)
    
    def get_backend_type(self):
        """Return the backend tyoe of  this circuit."""
        return self._backend


    def get_num_qubits(self):
        """Return the total number of qubits in this circuit."""
        return self._total_qubits

    def update_name(self, name: str):
        """Update the name of the circuit."""
        self.name = name
        self._seq.update_name(name)

    def data(self):
        """Return the underlying data of the GateSequence."""
        return self._seq.data()
    
    def copy(self):
        """Create a copy of this GateSequence."""
        new_seq = GateSequence(self._total_qubits, name=self._seq.get_name())
        new_seq.registers = self.registers.copy()
        new_seq._register_mappings = self._register_mappings.copy()
        new_seq._total_qubits = self._total_qubits
        new_seq._used_qubits = self._used_qubits.copy()

        new_seq.classical_registers = self.classical_registers.copy()
        new_seq._cl_register_mappings = self._cl_register_mappings.copy()
        new_seq._total_clbits = self._total_clbits
        new_seq._measure_map = self._measure_map.copy()
        new_seq._seq = self._seq
        return new_seq

    def add_register(self, register: Register):
        """Add a register to the internal mapping."""
        if register in self.registers:
            raise ValueError(f"Register '{register.name}' already exists in this circuit")
        
        start_qubit = self._total_qubits
        self._total_qubits += register.n_qubits
        
        self._register_mappings[register] = start_qubit
        self.registers.append(register)
    
    def add_classical_register(self,cl_register:ClassicalRegister):
        """Add a classical_register to the internal mapping."""
        if cl_register in self.classical_registers:
            raise ValueError(f"ClassicalRegister '{cl_register.name}' already exists")
        start_bit = self._total_clbits
        self._cl_register_mappings[cl_register] = start_bit
        self.classical_registers.append(cl_register)
        self._total_clbits += cl_register.n_qubits

    def _get_global_qubit_index(self, register: Register, local_index: Union[int, List[int]]):
        """Get the global qubit index for a register's local index."""
        if register not in self._register_mappings: 
            raise KeyError(f"Register '{register.name}' not found in this circuit")

        if isinstance(local_index, int):
            local_index = [local_index]
        
        if max(local_index) >= register.n_qubits or min(local_index) < -register.n_qubits:
            raise IndexError(f"Register index {local_index} out of range for register '{register.name}'")
        
        return [self._register_mappings[register] + i%register.n_qubits for i in local_index]
    
    def _format_indices(self, target, update=True):
        """
        Resolve a target specification to actual global qubit indices.
        
        Args:
            target: Can be:
                - Register indexing result: [(register, local_index)]
                - Integer: direct qubit index
                - List of integers: multiple direct qubit indices
        
        Returns:
            List of global qubit indices
        """
        # The allowed input for target is a list.
        if isinstance(target, list):
            flattened = []
            for item in target:
                if isinstance(item, list):
                    flattened.extend(item)
                else:
                    flattened.append(item)
            target = flattened

        if isinstance(target, int):
            target = [target]
        
        elif isinstance(target, (slice, range)):
            target = list(target)

        elif isinstance(target, list) and all(isinstance(t, int) for t in target):
            pass

        elif isinstance(target, Register):
            target = self._get_global_qubit_index(target, range(target.n_qubits))

        elif isinstance(target, list) and all(isinstance(t, Register) for t in target):
            indices = []
            for reg in target:
                indices.extend(self._get_global_qubit_index(reg, range(reg.n_qubits)))
            target = indices

        elif isinstance(target, list) and all(isinstance(t, tuple) for t in target):
            indices = []
            for reg, local_index in target:
                indices.extend(self._get_global_qubit_index(reg, local_index))
            target = indices
        
        if update:
            self._used_qubits.update(target)

        return target[0] if len(target) == 1 else target
    
    def _format_states(self, control_sequence, num_ctrl_qubits):
        """
        Format control sequence to binary list.
        
        Args:
            control_sequence: Can be int, str, or list of ints
            num_ctrl_qubits: Number of control qubits
        
        Returns:
            List of ints (0/1)
        """
        if num_ctrl_qubits == 0:
            return None
        if isinstance(control_sequence, int):
            control_sequence = bin(control_sequence)[2:].zfill(num_ctrl_qubits)
        if not control_sequence:
            control_sequence = [1] * num_ctrl_qubits
        if isinstance(control_sequence, (str, list)):
            control_sequence = [int(x) for x in control_sequence]
        if len(control_sequence) != num_ctrl_qubits:
            raise ValueError(f"control_sequence length must be equal to number of control qubits!")
        return control_sequence[0] if len(control_sequence) == 1 else control_sequence

    # Single-qubit gates with register support
    def x(self, qubit):
        """
        Apply Pauli-X gate.

        Parameters
        ----------
        qubit : int | Register | list
            Target qubit index or register indexing result.
        """
        qubit = self._format_indices(qubit)
        self._seq.x(qubit)
    
    def y(self, qubit):
        """Apply Y gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.y(qubit)
    
    def z(self, qubit):
        """Apply Z gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.z(qubit)
    
    def h(self, qubit):
        """Apply H gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.h(qubit)
    
    def s(self, qubit):
        """Apply S gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.s(qubit)
    
    def sdag(self, qubit):
        """Apply S† gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.sdag(qubit)
    
    def t(self, qubit):
        """Apply T gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.t(qubit)
    
    def tdag(self, qubit):
        """Apply T† gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.tdag(qubit)
    
    def sqrtx(self, qubit):
        """Apply √X gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.sqrtx(qubit)
    
    def sqrtxdag(self, qubit):
        """Apply √X† gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.sqrtxdag(qubit)
    
    def sqrty(self, qubit):
        """Apply √Y gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.sqrty(qubit)
    
    def sqrtydag(self, qubit):
        """Apply √Y† gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.sqrtydag(qubit)
    
    def i(self, qubit):
        """Apply I gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.i(qubit)
    
    # Rotation gates with register support
    def rx(self, angle, qubit):
        """Apply RX gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.rx(angle, qubit)
    
    def ry(self, angle, qubit):
        """Apply RY gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.ry(angle, qubit)
    
    def rz(self, angle, qubit):
        """Apply RZ gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.rz(angle, qubit)
    
    def u1(self, lambda_, qubit):
        """Apply U1 gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.u1(lambda_, qubit)
    
    def u2(self, phi, lambda_, qubit):
        """Apply U2 gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.u2(phi, lambda_, qubit)
    
    def u3(self, theta, phi, lambda_, qubit):
        """Apply U3 gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.u3(theta, phi, lambda_, qubit)
    
    def p(self, angle, qubit):
        """Apply P gate. qubit can be register indexing result or integer."""
        qubit = self._format_indices(qubit)
        self._seq.p(angle, qubit)
    
    def gp(self, angle):
        """Apply Global Phase gate."""
        self._seq.gp(angle)
    
    # Two-qubit gates with register support
    def swap(self, qubit1, qubit2):
        """Apply SWAP gate. qubits can be register indexing results or integers."""
        qubit1 = self._format_indices(qubit1)
        qubit2 = self._format_indices(qubit2)
        if isinstance(qubit1, list) or isinstance(qubit2, list):
            raise ValueError("SWAP gate cannot act on multiple qubits!")
        if qubit1 == qubit2:
            raise ValueError("SWAP gate cannot act on the same qubit!")
        
        self._seq.swap(qubit1, qubit2)
    
    # Control gates with register support
    def cnot(self, control, target, control_sequence=None):
        """Apply CNOT gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CNOT gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.cnot(control, target, control_sequence)
        else:
            self._seq.cnot(control, target)
    
    def cz(self, control, target, control_sequence=None):
        """Apply CZ gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CZ gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.cz(control, target, control_sequence)
        else:
            self._seq.cz(control, target)
    
    def ch(self, control, target, control_sequence=None):
        """Apply CH gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CH gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.ch(control, target, control_sequence)
        else:
            self._seq.ch(control, target)
    
    def cs(self, control, target, control_sequence=None):
        """Apply CS gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CS gate cannot act on multiple control qubits!")
            
        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.cs(control, target, control_sequence)
        else:
            self._seq.cs(control, target)
    
    def cx(self, control, target, control_sequence=None):
        """Apply CX gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CX gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.cx(control, target, control_sequence)
        else:
            self._seq.cx(control, target)
    
    def cy(self, control, target, control_sequence=None):
        """Apply CY gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CY gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.cy(control, target, control_sequence)
        else:
            self._seq.cy(control, target)
    
    def cp(self, angle, control, target, control_sequence=None):
        """Apply CP gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CP gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.mcp(angle, [control], target, control_sequence)
        else:
            self._seq.mcp(angle, [control], target)

    def crx(self, angle, control, target, control_sequence=None):
        """Apply CRX gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CRX gate cannot act on multiple control qubits!")
        
        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.mcrx(angle, [control], target, control_sequence)
        else:
            self._seq.mcrx(angle, [control], target)

    def cry(self, angle, control, target, control_sequence=None):
        """Apply CRY gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CRY gate cannot act on multiple control qubits!")

        control_sequence = self._format_states(control_sequence, 1)
        if control_sequence is not None:
            self._seq.mcry(angle, [control], target, control_sequence)
        else:
            self._seq.mcry(angle, [control], target)
    
    def crz(self, angle, control, target, control_sequence=None):
        """Apply CRZ gate. control and target can be register indexing results or integers."""
        control = self._format_indices(control)
        target = self._format_indices(target)
        if isinstance(control, list):
            raise ValueError("CRZ gate cannot act on multiple control qubits!")
            
        control_sequence = self._format_states(control_sequence, 1) 
        if control_sequence is not None:
            self._seq.mcrz(angle, [control], target, control_sequence)
        else:
            self._seq.mcrz(angle, [control], target)
    
    # Multi-control gates with register support
    def mcx(self, controls, target, control_sequence=None):
        """Apply MCX gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcx(controls, target, control_sequence)
        else:
            self._seq.mcx(controls, target)
    
    def mcy(self, controls, target, control_sequence=None):
        """Apply MCY gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcy(controls, target, control_sequence)
        else:
            self._seq.mcy(controls, target)
    
    def mcz(self, controls, target, control_sequence=None):
        """Apply MCZ gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcz(controls, target, control_sequence)
        else:
            self._seq.mcz(controls, target)
    
    def mch(self, controls, target, control_sequence=None):
        """Apply MCH gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mch(controls, target, control_sequence)
        else:
            self._seq.mch(controls, target)
    
    # Multi-control rotation gates with register support
    def mcrx(self, angle, controls, target, control_sequence=None):
        """Apply MCRX gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcrx(angle, controls, target, control_sequence)
        else:
            self._seq.mcrx(angle, controls, target)
    
    def mcry(self, angle, controls, target, control_sequence=None):
        """Apply MCRY gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcry(angle, controls, target, control_sequence)
        else:
            self._seq.mcry(angle, controls, target)
    
    def mcrz(self, angle, controls, target, control_sequence=None):
        """Apply MCRZ gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcrz(angle, controls, target, control_sequence)
        else:
            self._seq.mcrz(angle, controls, target)
    
    def mcp(self, angle, controls, target, control_sequence=None):
        """Apply MCP gate. controls and target can be register indexing results or integers."""
        controls = self._format_indices(controls)
        target = self._format_indices(target)
        if isinstance(controls, int):
            controls = [controls]
        control_sequence = self._format_states(control_sequence, len(controls))
        if control_sequence is not None:
            self._seq.mcp(angle, controls, target, control_sequence)
        else:
            self._seq.mcp(angle, controls, target)

    def unitary(self, matrix, target, control=[], control_sequence=None):
        """
        Apply a custom unitary gate.
        """
        if not isinstance(matrix, np.ndarray):
            try:
                if hasattr(matrix, 'numpy'):
                    matrix = matrix.numpy()
                else:
                    matrix = np.array(matrix)
            except ValueError:
                raise ValueError("The matrix must be a numpy array")

        if matrix.shape[0] != 2**len(target):
            raise ValueError(f"Unitary matrix must have shape (2**{len(target)}, 2**{len(target)})")
        if matrix.shape[1] != 2**len(target):
            raise ValueError(f"Unitary matrix must have shape (2**{len(target)}, 2**{len(target)})")
        if not np.allclose(matrix @ matrix.conj().T, np.eye(2**len(target))):
            raise ValueError("The matrix must be unitary")

        target = self._format_indices(target)
        control = self._format_indices(control)
        if isinstance(control, int):
            control = [control]
        control_sequence = self._format_states(control_sequence, len(control))
        if control_sequence is not None:
            self._seq.unitary(matrix, target, control, control_sequence)
        else:
            self._seq.unitary(matrix, target)

    def _format_cl_indices(self, target):
        """
        将经典位目标解析为实际的全局经典位索引。
        """
        # The allowed input for target is a list.
        if isinstance(target, list):
            flattened = []
            for item in target:
                if isinstance(item, list):
                    flattened.extend(item)
                else:
                    flattened.append(item)
            target = flattened

        if isinstance(target, int):
            target = [target]
        
        elif isinstance(target, (slice, range)):
            target = list(target)

        elif isinstance(target, list) and all(isinstance(t, int) for t in target):
            pass

        elif isinstance(target, ClassicalRegister):
            target = self._format_cl_indices(target[:])

        elif isinstance(target, list) and all(isinstance(t, tuple) for t in target):
            indices = []
            for reg, local_index in target:
                if reg not in self._cl_register_mappings:
                    raise KeyError(f"ClassicalRegister '{reg.name}' not found in this circuit")
                
                start_bit = self._cl_register_mappings[reg]
                local_indices = [local_index] if isinstance(local_index, int) else local_index
                for i in local_indices:
                    indices.append(start_bit + (i % reg.n_qubits))
            target = indices

        return target[0] if len(target) == 1 else target

    def measure(self,target, clbit):
        """Measure the target qubit(s) in the circuit."""
        q_idx = self._format_indices(target)
        c_idx = self._format_cl_indices(clbit)


        qs = [q_idx] if isinstance(q_idx, int) else q_idx
        cs = [c_idx] if isinstance(c_idx, int) else c_idx

        if len(qs) != len(cs):
            raise ValueError(f"Qubits ({len(qs)}) and Classical bits ({len(cs)}) count mismatch!")
        
        for q, c in zip(qs, cs):
            for existing_q, existing_c in self._measure_map:
                if q == existing_q and c != existing_c:
                    raise ValueError(
                        f"Conflict: Qubit {q} is already mapped to Classical Bit {existing_c}. "
                        f"Cannot re-map to {c}."
                    )
                if c == existing_c and q != existing_q:
                    raise ValueError(
                        f"Conflict: Classical Bit {c} is already receiving result from Qubit {existing_q}. "
                        f"Cannot re-map from {q}."
                    )
            if (q, c) not in self._measure_map:
                self._measure_map.append((q, c))

        self._seq.measure(qs,cs)

    def __getattr__(self, name):
        """Delegate attribute access to the underlying OriginalGateSequence instance."""
        return getattr(self._seq, name)

    def decompose(self, times=1):
        """Decompose the gate sequence.

        Parameters:
        times: Number of decompositions, defaults to 1

        Returns:

        The underlying GateSequence object after decomposition (returned by OriginalGateSequence)
        """
        
        new_seq = self.copy()
        new_seq._seq = self._seq.decompose(times)
        return new_seq
    
    def dagger(self):
        """Return the conjugate transpose of the current quantum circuit."""
        new_seq = self.copy()
        new_seq._seq = self._seq.dagger()
        new_seq.update_name(f"dag_{self.name}")
        return new_seq
    
    def reverse(self):
        """Returns the reverse path of the current quantum circuit"""
        new_seq = self.copy()
        new_seq._seq = self._seq.reverse()
        new_seq.update_name(f"rev_{self.name}")
        return new_seq
    
    def draw(self, filename=None, title=None, style='dark', compact=True):
        """Plot a quantum circuit diagram

        Parameters:

        filename: If provided, save the graph to this file

        title: The title of the circuit diagram

        Returns:
        A Matplotlib Figure object
        """
        from ..drawer.circuit_drawer import CircuitDrawer
        drawer = CircuitDrawer(style=style)
        return drawer.draw(self, filename=filename, title=title, compact=compact)
    
    def analyze(self, sections=None, show=True, qubit=None):
        """
        Analyze the quantum circuit and optionally display selected sections.

        Parameters
        ----------
        sections : str, list[str], or None, optional
            Sections to display. If None, commonly used sections
            will be shown by default.

        show : bool, optional
            Whether to immediately display the analysis result.
            Default is True.

        qubit : int or None, optional
            Required when "qubit_history" is requested.

        Returns
        -------
        CircuitInfo
            A CircuitInfo object for further analysis.
        """
        from ..circuit_analysis.circuit_info import CircuitInfo
        info = CircuitInfo(self)

        if show:
            info.show(sections=sections, qubit=qubit)

        return info

    
    def append(self, block_gate_sequence, target, control=[], control_sequence=None):
        """Add a sub-line to the end of the current line.

        Parameters:
        `block_gate_sequence`: The sub-line to add (can be `GateSequence` or data)

        `target`: The target qubit (can be a register index or an integer)

        `control`: The control qubit (optional)

        `control_sequence`: The control sequence (optional)
        """
        target = self._format_indices(target)
        control = self._format_indices(control)
        if isinstance(target, int):
            target = [target]
        if isinstance(control, int):
            control = [control]
        control_sequence = self._format_states(control_sequence, len(control))
        if control_sequence is not None:
            self._seq.append(block_gate_sequence._seq, target, control, control_sequence)
        else:
            self._seq.append(block_gate_sequence._seq, target)
    
    def prepend(self, block_gate_sequence, target, control=[], control_sequence=None):
        """Add a sub-line at the beginning of the current line.

        Parameters:
        `block_gate_sequence`: The sub-line to add (can be `GateSequence` or data)

        `target`: The target qubit (can be a register index or an integer)

        `control`: The control qubit (optional)

        `control_sequence`: The control sequence (optional)
        """
        target = self._format_indices(target)
        control = self._format_indices(control)
        if isinstance(target, int):
            target = [target]
        if isinstance(control, int):
            control = [control]
        control_sequence = self._format_states(control_sequence, len(control))
        if control_sequence is not None:
            self._seq.prepend(block_gate_sequence._seq, target, control, control_sequence)
        else:
            self._seq.prepend(block_gate_sequence._seq, target)
    
    def inverse(self):
        """Return the inverse (conjugate transpose) of the current quantum circuit."""
        new_seq = self.copy()
        new_seq._seq = self._seq.inverse()
        new_seq.update_name(f"inv_{self.name}")
        return new_seq
    
    def repeat(self, times=1):
        """Repeat the current quantum circuit a specified number of times.

        Parameters:

        times: The number of repetitions, defaults to 1.

        Returns:

        A GateSequence object with the repeated values.
        """
        new_seq = self.copy()
        new_seq._seq = self._seq.repeat(times)
        new_seq.update_name(f"{self.name}**{times}")
        return new_seq

    def control(self, num_ctrl_qubits=1, control_sequence=None):
        """Add control qubits to the gate sequence.

        Parameters:

        num_ctrl_qubits: Number of qubits, defaults to 1

        control_sequence: Control sequence, defaults to ''
        """
        new_seq = self.copy()
        register = Register('ct', num_ctrl_qubits)
        new_seq.add_register(register)
        control_sequence = self._format_states(control_sequence, num_ctrl_qubits)

        new_seq._seq = self._seq.control(num_ctrl_qubits, control_sequence)
        new_seq.update_name(f"ctrl_{self.name}")
        return new_seq

    def initialize(self, v, target, control=[], control_sequence=None):
        import numpy as np

        if isinstance(v, list):
            v = np.array(v)
        n = int(np.log2(v.shape[0]))
        target = self._format_indices(target, update=False)
        if isinstance(target, int):
            target = [target]
        
        if n != len(target):
            raise ValueError(f"The target length {len(target)} does not match the dimension of initial vectors!")

        for i in target:
            if i in self._used_qubits:
                raise ValueError(f"The circuit cannot be initialized since target qubit {i} is already used!")
        
        from .Initialization import state_preparation
        self.append(state_preparation(v,backend=self.get_backend_type()), target, control, control_sequence)
        self._used_qubits.update(target)

    def _fill_value_to_register(self, global_c_idx, value):
        """Auxiliary method: Find the corresponding register object based on the global index and fill in the value"""
        for creg in self.classical_registers:
            start = self._cl_register_mappings[creg]
            end = start + creg.n_qubits
            if start <= global_c_idx < end:
                local_idx = global_c_idx - start
                creg.values[local_idx] = value
                break

    def execute(self, initial_state=None):
        """Execute the gate sequence.
        
        Returns:

        The GateSequence object after execution
        """
        
        if initial_state is None:
            initial_state = [0] * 2**self.get_num_qubits()
            initial_state[0] = 1.0
                
        result,cl_map= self._seq.execute(initial_state)
        for c_idx, val in cl_map.items():
            self._fill_value_to_register(c_idx, val)

        if not isinstance(result, np.ndarray):
            if hasattr(result, 'numpy'):
                result = result.numpy()
            else:
                result = np.array(result)
        return result
    
    def get_matrix(self, m: int = 0):
        """
        Extract unitary matrix from GateSequence.
        
        Parameters:
        m: Number of qubits to use (0 for all)
        
        Returns:
        Unitary matrix
        """
        n = self.get_num_qubits()
        if m <= 0 or m > n:
            m = n

        if (self._matrix is not None) and (m==n):
            if self.data() == self._matrix[0]:
                return self._matrix[1]

        gs1 = GateSequence(n + m)
        gs1.append(self, range(n))
        u0 = np.eye(2**m, 2**n).flatten()
        state = gs1.execute(u0)
        matrix = state.reshape((2**m, 2**n)).T
        
        matrix = matrix[:2**m, :]
        if m == n:
            self._matrix = (self.data().copy(), matrix)
        return matrix