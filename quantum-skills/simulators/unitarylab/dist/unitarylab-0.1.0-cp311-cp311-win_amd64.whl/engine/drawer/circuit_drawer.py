# 导入所需的模块和函数
# 注意：这些导入在原始代码中可能存在，但为了完整性，这里明确列出
import numpy as np
import re
import json
from .default_parameter import *
from ..core.gate_sequence import GateSequence



# 定义CircuitDrawer类，用于绘制量子电路
class CircuitDrawer():
    # 初始化方法
    def __init__(self, scale=1.0, ax=None, width_per_layer=30, style='dark'):
        """Initialize the CircuitDrawer object
        Parameters:
        num_qubits: Number of qubits
        gate_list: List of gates
        style: Plotting style configuration (optional)
        ax: Matplotlib axis object (optional)
        width_per_layer: Maximum width per layer
        """

        self._style = dark_style
        if isinstance(style, dict):
            self._style.update(style)
        elif isinstance(style, str):
            if style == 'dark':
                pass
            elif style == 'light':
                self._style = light_style
            elif style.startswith('{') and style.endswith('}'):
                self._style.update(json.loads(style))
            elif style.endswith('.json'):
                with open(style, 'r') as f:
                    self._style.update(json.load(f))
        else:
            raise ValueError("style must be a dict or a json string or a json file path")
        
        self._scale = scale
        self._ax = ax  # 初始化轴对象，如果没有提供则为None
        self._patches_mod = None
        self._width_per_layer = width_per_layer  # 存储每个门层的门数
        if width_per_layer <= 0:
            self._width_per_layer = 1e10
        
        self.n_qubits = None
        self.gate_layer_list = []  # 初始化门层列表为空列表
        self.max_width = 0.0  # 初始化最大宽度为0.0

    # 折叠门的方法
    def get_layered_gates(self, gate_list):
        """The door list is folded according to the folding parameters to generate a door layer list.
        The one-dimensional door list is converted into a two-dimensional door layer list.
        Each door layer contains doors drawn at the same horizontal position.
        """
        # 将门列表根据width_per_layer参数折叠成多层，并计算每个门的坐标(x,y)
        # x为门的起始位置，y为门的底部位置
        result = [[]]
        x_offset = self._style['x_offset']
        y_offset = self._style['y_offset']
        
        x = x_offset  # 当前行的起始x位置
        y = 0  # 当前行的y位置
        layer = 0  # 当前层的编号
        layer_width = 0.0
        
        for gate_str in gate_list:
            if isinstance(gate_str, dict):
                gate = gate_str
            else:
                gate = json.loads(gate_str)
            # 根据门的名称计算宽度
            name = gate.get('name', '')
            name = self._style["displaytext"].get(name.lower(), name)

            qmin = min(gate['target'])
            qmax = max(gate['target'])
            char_width = self.get_text_width(name)
            gate_width = char_width * self._style['scale_char']
            # 多比特门需要额外的间距来标明比特
            if len(gate['target']) > 1:
                gate_width += 0.2

            # 将字符宽度转换为合适的门宽度（至少为1）
            gate_width = max(self._style['gatewidth'], gate_width)

            # 计算当前门的起始位置
            gate_start = x + x_offset
            
            # 检查当前门是否能放入当前行
            if gate_start + gate_width > self._width_per_layer:
                # 移动到下一行
                layer += 1  # 增加层编号
                result.append([])  # 添加新的空层
                x = x_offset  # 重置x坐标到行首
                y -= (self.n_qubits + 1)  # 更新y坐标
                gate_start = x + x_offset  # 当前门的起始位置
                layer_width = 0.0  # 为新层初始化宽度
            
            gate['x'] = gate_start
            gate['y'] = y - qmax - y_offset  # 门的起始y位置
            gate['qmin'] = qmin  # 最小量子比特
            gate['qmax'] = qmax  # 最大量子比特
            gate['gate_width'] = gate_width  # 门的实际宽度

            # 保存结果
            result[layer].append(gate)
            
            # 更新当前行的x位置，为下一个门做准备
            # 下一个门的起始位置是当前门的起始位置加上当前门的宽度
            x = gate_start + gate_width
            layer_width = x  # 更新当前层的宽度
            self.max_width = max(self.max_width, layer_width)
        
        self.gate_layer_list = result
    
    # 新的折叠门方法。 改变了 gate['x'] 和 gate['y']的获取方式。
    def compact_get_layered_gates(self, gate_list):
        """
        Compact layout computation logic.

        Special optimizations for the Measure gate:

        1. Upon encountering a Measure gate, automatically align to the rightmost edge of all qubits in the current layer.

        2. After placing the Measure gate, force the cursors of all qubits to be synchronized to the right side of the Measure gate.
        """
        x_offset = self._style['x_offset']
        y_offset = self._style['y_offset']
        
        # 初始化：每个比特的光标包含所在的层级 (layer) 和当前的 x 坐标
        qubit_cursors = [{'layer': 0, 'x': 2 * x_offset} for _ in range(self.n_qubits)] 
        
        result = [[]]
        self.max_width = 0.0

        for gate_str in gate_list:
            if isinstance(gate_str, dict):
                gate = gate_str
            else:
                gate = json.loads(gate_str)

            # --- Step 1: 确定门涉及的比特范围 ---
            # 考虑控制比特和目标比特
            all_control = gate.get('control', [])
            all_target = gate['target']
            all_involved = list(set(all_target + all_control))
            
            all_qmin = min(all_involved)
            all_qmax = max(all_involved)
            qmin, qmax = min(all_target), max(all_target)
            
            # 受影响的区域（包括比特间的连线区域）
            affected_qubits = range(all_qmin, all_qmax + 1)

            # --- Step 2: 识别是否为测量门 ---
            is_measure = gate.get('id', '').lower() in ['measure', 'm']

            # --- Step 3: 确定层级 (Layer) ---
            # 门必须放在所有相关比特最晚的那一层
            current_layer = max(qubit_cursors[q]['layer'] for q in affected_qubits)
            # print( gate.get('id', '').lower(),is_measure)
            
            # --- Step 4: 确定起始 X 坐标 ---
            if is_measure:
                # 测量门逻辑：寻找当前层中所有比特走到的最远距离，实现全场对齐
                base_x = max(
                    (qubit_cursors[q]['x'] if qubit_cursors[q]['layer'] == current_layer else x_offset)
                    for q in range(self.n_qubits)
                )
                current_x = max(base_x, self.max_width)
            else:
                # 普通门逻辑：只需避开受影响比特的进度
                current_x = max(
                    (qubit_cursors[q]['x'] if qubit_cursors[q]['layer'] == current_layer else x_offset)
                    for q in affected_qubits
                )

            # --- Step 5: 计算门的物理宽度 ---
            name = gate.get('name', '')
            name = self._style["displaytext"].get(name.lower(), name)
            char_width = self.get_text_width(name)
            gate_width = char_width * self._style['scale_char']
            
            # 多比特门额外间距
            if len(all_target) > 1:
                gate_width += 0.2
            # 确保不小于最小宽度
            gate_width = max(self._style['gatewidth'], gate_width)

            # --- Step 6: 检查折叠逻辑 ---
            if current_x + gate_width > self._width_per_layer:
                current_layer += 1
                current_x = 2 * x_offset
                
            # 动态扩展结果列表
            while len(result) <= current_layer:
                result.append([])

            # --- Step 7: 写入门位置信息 ---
            layer_y_base = -(current_layer * (self.n_qubits + 1))
            gate['x'] = current_x
            gate['y'] = layer_y_base - qmax - y_offset
            gate['qmin'] = qmin
            gate['qmax'] = qmax
            gate['gate_width'] = gate_width
            gate['layer'] = current_layer

            result[current_layer].append(gate)

            # --- Step 8: 更新光标 (核心需求实现点) ---
            # 新的结束位置 = 起点 + 宽度 + 间距
            new_cursor_x = current_x + gate_width + x_offset
            
            if is_measure:
                # 如果是测量门，强制“清空”全场，所有比特的光标全部推到右侧
                for q in range(self.n_qubits):
                    qubit_cursors[q]['layer'] = current_layer
                    qubit_cursors[q]['x'] = new_cursor_x
            else:
                # 如果是普通门，仅更新涉及到的比特路径
                for q in affected_qubits:
                    qubit_cursors[q]['layer'] = current_layer
                    qubit_cursors[q]['x'] = new_cursor_x
            
            # 更新画布总跨度
            self.max_width = max(self.max_width, new_cursor_x)

        self.gate_layer_list = result

    # 计算字符串在默认字体中的宽度
    def get_text_width(self, text):
        """
        Calculates the width of a string in the default font.

        Parameters:

        text: The string whose width you want to calculate.

        Returns:

        The width of the string (in relative units).
            
        """

        from pylatexenc.latex2text import LatexNodes2Text

        if not text:
            return 0.0

        # 去掉Latex表达式中的 _ 和 ^
        text = text.replace("$$", "$")
        math_pattern = r"(?<!\\)\$(.*?)(?<!\\)\$"
        matches = re.finditer(math_pattern, text)
        clean_text = text
        for match in reversed(list(matches)):
            start, end = match.span()
            math_content = match.group(1)
            # 去除下划线和上标
            cleaned_content = re.sub(r'[_^]', '', math_content)
            clean_text = clean_text[:start] + f"${cleaned_content}$" + clean_text[end:]
            
        text = LatexNodes2Text().latex_to_text(text.replace("$$", ""))

        sum_text = 0.0
        for c in text:
            try:
                sum_text += CHAR_WIDTHS[c][0]
            except KeyError:
                # if non-ASCII char, use width of 'c', an average size
                sum_text += CHAR_WIDTHS["c"][0]
        return sum_text

    # 绘制方法，主入口点
    def draw(self, gate_sequence:GateSequence, filename=None, title=False, compact=True):
        """The main entry point for Matplotlib plotters.
        Parameters:
        filename: Output filename (optional)
        title: Figure title (optional)
        compact: Whether to use a compact layout (optional)
        Returns:
        Matplotlib Figure object
        """

        self.n_qubits = gate_sequence._seq.get_num_qubits()  # 存储量子位数

        # 导入Matplotlib相关模块
        from matplotlib import patches
        from matplotlib import pyplot as plt
        from matplotlib import font_manager
    
        # 存储patches模块到全局数据中
        self._patches_mod = patches

        # 如果没有用户提供的轴对象，则创建新的图形和轴
        if self._ax is None:
            default_ax = True  # 标记为使用内部创建的轴
            figure = plt.figure()  # 创建新的图形对象
            figure.patch.set_facecolor(color=self._style["backgroundcolor"])  # 设置图形背景颜色
            self._ax = figure.add_subplot(111)  # 添加子图轴
        else:
            default_ax = False  # 标记为使用用户提供的轴
            figure = self._ax.get_figure()  # 获取用户提供的轴所属的图形
        
        self._ax.axis("off")  # 关闭坐标轴显示
        self._ax.set_aspect("equal")  # 设置坐标轴比例为相等
        # 关闭所有刻度标签
        self._ax.tick_params(labelbottom=False, labeltop=False, labelleft=False, labelright=False)

        # 计算坐标和索引
        # 首先确保门列表已经折叠
        if not self.gate_layer_list:
            gate_list = gate_sequence._seq.data()
            if not compact:
                self.get_layered_gates(gate_list)
            else:
                self.compact_get_layered_gates(gate_list)
                
        # 计算折叠次数和最大x索引
        layers = len(self.gate_layer_list)

        # 初始化量子比特
        qubit_labels = ['$q_{' + str(i) + '}$' for i in range(self.n_qubits)]
        qubit_labels = []
        for register in gate_sequence.registers:
            for i in range(register.n_qubits):
                qubit_labels.append('$' + register.name + '_{' + str(i) + '}$')

        xmax = self.max_width + self._style['x_offset']
        ymax = layers * (self.n_qubits + 1) - 1

        # 设置坐标轴限制，考虑边距
        xl = -self._style["margin"][0]  # 左侧边距
        xr = xmax + self._style["margin"][1]  # 右侧边距
        yb = -ymax - self._style["margin"][2] + 0.5  # 底部边距
        yt = self._style["margin"][3] + 0.5  # 顶部边距
        self._ax.set_xlim(xl, xr)  # 设置X轴范围
        self._ax.set_ylim(yb, yt)  # 设置Y轴范围
        
        # 如果提供了标题，设置图标题
        if title != False:
            if not title:
                title = gate_sequence.name
            # 尝试使用支持中文的字体
            try:
                # 获取系统中可用的字体
                zh_fonts = [f.name for f in font_manager.fontManager.ttflist if 'SimHei' in f.name or 'Microsoft YaHei' in f.name or 'STSong' in f.name]
                if zh_fonts:
                    self._ax.set_title(title, fontsize=self._style["fontsize"], fontfamily=zh_fonts[0])
                else:
                    self._ax.set_title(title, fontsize=self._style["fontsize"])
            except:
                # 如果设置中文字体失败，使用默认字体
                self._ax.set_title(title, fontsize=self._style["fontsize"])

        # 更新图形大小，为了向后兼容，需要按默认值缩放
        base_fig_w = (xr - xl)  # 基础图形宽度
        base_fig_h = (yt - yb)  # 基础图形高度

        # 如果用户提供了轴对象，该轴的大小优先于任何其他设置
        if not default_ax:
            # 从_ax获取轴的边界框大小，然后重置缩放
            bbox = self._ax.get_window_extent().transformed(figure.dpi_scale_trans.inverted())
            self._scale = bbox.width / base_fig_w

        # 如果使用默认轴且缩放比例不是1.0，使用该缩放因子
        elif self._scale != 1.0:
            figure.set_size_inches(base_fig_w * self._scale, base_fig_h * self._scale)

        # 如果设置了"figwidth"样式参数，使用该参数缩放
        elif self._style["figwidth"] > 0.0:
            # 为了获得实际英寸，需要按因子缩放
            self._scale = self._style["figwidth"] / base_fig_w
            figure.set_size_inches(self._style["figwidth"], base_fig_h * self._scale)

        # 否则，使用默认大小
        else:
            figure.set_size_inches(base_fig_w, base_fig_h)

        # 绘图会随'set_size_inches'缩放，但字体和线宽不会自动缩放
        if self._scale != 1.0:
            # 手动调整字体大小
            self._style["fontsize"] *= self._scale  # 主字体大小
            # 手动调整线宽
            self._style["lwidth1"] *= self._scale
            self._style["lwidth15"] *= self._scale
            self._style["lwidth2"] *= self._scale
            self._style["lwidth3"] *= self._scale
            self._style["lwidth4"] *= self._scale
        
        # 绘制寄存器和线路
        self._draw_regs_wires(layers, xmax, qubit_labels)

        # 绘制所有操作（门）
        self._draw_ops()

        # 如果指定了文件名，则保存图形
        if filename:
            figure.savefig(
                filename,
                dpi=self._style["dpi"],  # 分辨率
                bbox_inches="tight",  # 紧密的边界框
                facecolor=figure.get_facecolor(),  # 保持背景颜色
            )
        if default_ax:
            matplotlib_close_if_inline(figure)  # 如果在inline模式下，关闭图形
            return figure  # 返回图形对象

    #Draw the register names and numbers, wires, and vertical lines at the ends
    def _draw_regs_wires(self, layers, xmax, qubit_labels):
        """Draw the register names and numbers, wires, and vertical lines at the ends"""
        import matplotlib.patches as patches
        import matplotlib.patheffects as patheffects
        for layer_num in range(layers):
            # quantum registers
            for i, qubit_label in enumerate(qubit_labels):
                y = -i - layer_num * (self.n_qubits + 1)


                # ---------- 绘制灰色圆形 badge ----------
                x_label = self._style["x_offset"] - 0.2
                radius = 0.35

                circle = patches.Circle(
                    (x_label, y),
                    radius=radius,
                    facecolor="#2B2B2B",        # 深灰背景
                    edgecolor="#3A3A3A",        # 轻微边框
                    linewidth=1,
                    zorder=PORDER_TEXT,
                )
                self._ax.add_patch(circle)
                # ---------- 绘制 Q0 文本 ----------
                text = self._ax.text(
                    x_label,
                    y,
                    f"Q{i}",                   # 大写 Q0
                    ha="center",
                    va="center",
                    fontsize=0.9 * self._style["fontsize"],
                    color="white",
                    fontweight="bold",
                    zorder=PORDER_TEXT + 1,
                )

                # 轻微 glow 效果
                text.set_path_effects([
                    patheffects.withStroke(linewidth=3, foreground="black", alpha=0.25)
                ])
                # draw the qubit wire
                self._line([self._style["x_offset"], y], [xmax, y], zorder=PORDER_REGLINE)

            # 绘制折叠区域两端的垂直线（连接线）
            # 判断是否需要绘制右侧连接线：当有折叠且当前折叠数小于总折叠数时
            feedline_r = layers > 1 and layers > layer_num
            # 判断是否需要绘制左侧连接线：当当前折叠数大于0时
            feedline_l = layer_num > 0
            
            # 如果需要绘制左侧或右侧连接线
            if feedline_l or feedline_r:
                # 计算左侧连接线的x坐标
                xpos_l = self._style["x_offset"]
                # 计算右侧连接线的x坐标
                xpos_r = xmax
                # 计算连接线的起始y坐标
                ypos1 = -layer_num * (self.n_qubits + 1)
                # 计算连接线的结束y坐标
                ypos2 = -(layer_num + 1) * (self.n_qubits) - layer_num + 1
                
                # 绘制左侧连接线
                if feedline_l:
                    self._ax.plot(
                        [xpos_l, xpos_l],  # x坐标列表（垂直线）
                        [ypos1, ypos2],  # y坐标列表
                        color=self._style["linecolor"],  # 线颜色
                        linewidth=self._style["lwidth15"],  # 线宽度
                        zorder=PORDER_REGLINE,  # 绘图顺序（确保在线路图层）
                    )
                
                # 绘制右侧连接线
                if feedline_r:
                    self._ax.plot(
                        [xpos_r, xpos_r],  # x坐标列表（垂直线）
                        [ypos1, ypos2],  # y坐标列表
                        color=self._style["linecolor"],  # 线颜色
                        linewidth=self._style["lwidth15"],  # 线宽度
                        zorder=PORDER_REGLINE,  # 绘图顺序（确保在线路图层）
                    )
            
            # # 在比特标签区域创建遮罩矩形，用于清理折叠产生的线路或盒子
            # # 这可以使ControlFlow和其他包裹门的折叠区域更整洁
            # box = self._patches_mod.Rectangle(
            #     xy=(self._style["x_offset"] - 0.1, -layer_num * (self.n_qubits + 1) + self._style['y_offset']),  # 矩形左下角坐标
            #     width=-25.0,  # 矩形宽度（负值表示向左延伸）
            #     height=-(layer_num + 1) * (self.n_qubits + 1),  # 矩形高度（负值表示向下延伸）
            #     fc=self._style["backgroundcolor"],  # 填充颜色（使用背景色）
            #     ec=self._style["backgroundcolor"],  # 边框颜色（使用背景色）
            #     linewidth=self._style["lwidth15"],  # 边框宽度
            #     zorder=PORDER_MASK,  # 绘图顺序（确保在遮罩图层，覆盖其他元素）
            # )
            # # 将遮罩矩形添加到轴对象中
            # self._ax.add_patch(box)

        # # draw index number
        # if self._style["index"]:
        #     for layer_num in range(max_x_index):
        #         if self._fold > 0:
        #             x_coord = layer_num % self._fold + self.x_offset + 0.53
        #             y_coord = -(layer_num // self._fold) * (self.n_qubits + 1) + 0.65
        #         else:
        #             x_coord = layer_num + self.x_offset + 0.53
        #             y_coord = 0.65
        #         self._ax.text(
        #             x_coord,
        #             y_coord,
        #             str(layer_num + 1),
        #             ha="center",
        #             va="center",
        #             fontsize=self._style["sfs"],
        #             color=self._style["tc"],
        #             clip_on=True,
        #             zorder=PORDER_TEXT,
        #         )

    # 绘制操作（门）的方法
    def _draw_ops(self):
        """Draw gates in a circuit
        """
        for layer in self.gate_layer_list:  # 遍历每一层门

            # 绘制当前层中的每个门
            for gate in layer:  # 遍历当前层中的每个门

                # 检查gate对象是否具有target和ctrl属性（注意：这些属性可能在实际门对象中定义）
                has_ctrl = len(gate.get('control', [])) > 0

                if has_ctrl:
                    self._control_gate(gate)

                # 绘制单量子比特门
                elif (not has_ctrl) and len(gate['target']) == 1:
                    self._gate(gate)
                                
                # 绘制多量子比特门作为最终默认情况
                else:
                    self._multiqubit_gate(gate)  # 直接使用gate作为节点
    def _draw_gradient_box(self, xpos, ypos, width, height):
        import matplotlib.colors as mcolors
        import matplotlib.patches as patches

        # 渐变颜色
        top_color = (31/255, 82/255, 240/255, 0.15)
        bottom_color = (31/255, 82/255, 240/255, 1.0)

        cmap = mcolors.LinearSegmentedColormap.from_list(
            "gate_gradient",
            [top_color, bottom_color]
        )

        # 创建圆角框
        box = patches.FancyBboxPatch(
            (xpos, ypos),
            width,
            height,
            boxstyle="round,pad=0,rounding_size=0.11",
            linewidth=0,
            edgecolor="#1F52F0",
            facecolor="none",
            zorder=PORDER_GATE,
        )

        self._ax.add_patch(box)

        # 渐变
        N = 100
        gradient = np.linspace(0, 1, N)
        gradient_rgba = cmap(gradient).reshape(N, 1, 4)

        extent = (xpos, xpos + width, ypos, ypos + height)

        im = self._ax.imshow(
            gradient_rgba,
            extent=extent,
            aspect='auto',
            origin='upper',
            zorder=PORDER_GATE - 0.1
        )

        im.set_clip_path(box)

        return box
    # 绘制单量子比特门的方法
    def _gate(self, gate):
        """Draw a qubit gate"""
        xpos, ypos = gate['x'], gate['y']  # 分解坐标为x和y
        gate_width = gate['gate_width']  # 计算门的宽度，取最大值
        v_margin = 0.1 # 对矩阵进行高度减小的操作。
        # 创建门的矩形框
        # 创建渐变填充
        import matplotlib.patches as patches
        
        # 计算矩形高度
        rect_height = gate['qmax'] - gate['qmin'] + 1 - 2*v_margin

        # 创建矩形
        # -------- 纯色圆角矩形 --------
        box = patches.FancyBboxPatch(
            (xpos, ypos + v_margin),
            gate_width,
            rect_height,
            boxstyle="round,pad=0,rounding_size=0.11",
            linewidth=0,                 # 🚀 去掉边框
            edgecolor="none",
            facecolor="#1F52F0",          # 🚀 纯蓝
            zorder=PORDER_GATE,
        )


        self._ax.add_patch(box)

        # 如果门有文本，则绘制文本
        if gate.get('name', ''):
            gate_ypos = ypos + 0.5 * (gate['qmax'] - gate['qmin'] + 1)  # 门文本的y位置
            # 如果门有参数文本，则调整门文本的位置并绘制参数文本
            if gate.get('parameter', ''):
                gate_ypos += 0.1 * self._style['gatewidth']  # 调整参数文本的y位置
                # 绘制参数文本
                self._ax.text(
                    xpos + 0.5 * gate_width,  # x坐标
                    gate_ypos - 0.4 * self._style['gatewidth'],  # y坐标
                    self._str_parameter(gate['parameter']),  # 参数文本
                    ha="center",  # 水平对齐方式
                    va="center",  # 垂直对齐方式
                    fontsize= 0.6 * self._style["subfontsize"] * self._style['scale_char'],  # 字体大小
                    color=self._style["subtextcolor"],  # 文本颜色
                    clip_on=True,  # 是否裁剪
                    zorder=PORDER_TEXT,  # 绘制顺序
                )
            # 绘制门文本
            self._ax.text(
                xpos + 0.5 * gate_width,  # x坐标
                gate_ypos,  # y坐标
                self._style["displaytext"].get(gate['name'].lower(), gate['name']),  # 门文本
                ha="center",  # 水平对齐方式
                va="center",  # 垂直对齐方式
                fontsize=self._style["fontsize"] * self._style['scale_char'],  # 字体大小
                color=self._style["gatetextcolor"],  # 文本颜色
                clip_on=True,  # 是否裁剪
                zorder=PORDER_TEXT,  # 绘制顺序
            )

    # 绘制多量子比特门的方法
    def _multiqubit_gate(self, gate):
        """Drawing gates covering multiple qubits"""
        xpos, ypos = gate['x'], gate['y']  # 分解坐标为x和y
        gate_width = gate['gate_width']  # 计算门的宽度，取最大值
        qmax = gate['qmax']  # 计算最大量子比特索引
        qmin = gate['qmin']  # 计算最小量子比特索引

        # 处理Swap门
        if gate['id'] in ['swap', 'sw']:
            xy = [(xpos + 0.5 * gate_width, ypos + self._style['y_offset']), (xpos + 0.5 * gate_width, ypos + self._style['y_offset'] + qmax - qmin)]
            self._swap(xy, self._style['gatefacecolor'])  # 绘制Swap门
            return

        v_margin = 0.1 # 对矩阵进行高度减小的操作。
        # 创建门的矩形框
        height = qmax - qmin + 1 - 2*v_margin

        self._draw_gradient_box(
            xpos,
            ypos + v_margin,
            gate_width,
            height
        )
        # 标注量子比特输入
        for bit in range(len(gate['target'])):  # 遍历每个量子比特的y坐标
            y = ypos + self._style['y_offset'] + qmax - gate['target'][bit]
            self._ax.text(
                xpos + 0.07,  # x坐标
                y,  # y坐标
                str(bit),  # 文本
                ha="left",  # 水平对齐方式
                va="center",  # 垂直对齐方式
                fontsize=self._style["subfontsize"] * self._style['scale_char'],  # 字体大小
                color=self._style["textcolor"],  # 文本颜色
                clip_on=True,  # 是否裁剪
                zorder=PORDER_TEXT,  # 绘制顺序
            )

        # 标注控制量子比特
        for i, control_bit in enumerate(gate['control']):
            if control_bit < min(gate['target']):
                continue
            if control_bit > max(gate['target']):
                continue
            y = ypos + self._style['y_offset'] + qmax - control_bit
            self._ctrl_qubit(xpos+0.13, y, ctrl_state=gate['control_sequence'][i], in_gate=True)
        
        
        # 如果门有文本，则绘制文本
        if gate.get('name', ''):
            gate_ypos = ypos + 0.5 * (qmax - qmin + 1)  # 门文本的y位置
            # 如果门有参数文本，则调整门文本的位置并绘制参数文本
            if gate.get('parameter', ''):
                gate_ypos += 0.1 * self._style['gatewidth']  # 调整参数文本的y位置
                # 绘制参数文本
                self._ax.text(
                    xpos + 0.5 * gate_width + 0.1,  # x坐标
                    gate_ypos - 0.4 * self._style['gatewidth'],  # y坐标
                    self._str_parameter(gate['parameter']),  # 参数文本
                    ha="center",  # 水平对齐方式
                    va="center",  # 垂直对齐方式
                    fontsize= 0.6 * self._style["subfontsize"] * self._style['scale_char'],  # 字体大小
                    color=self._style["subtextcolor"],  # 文本颜色
                    clip_on=True,  # 是否裁剪
                    zorder=PORDER_TEXT,  # 绘制顺序
                )
            # 绘制门文本
            self._ax.text(
                xpos + 0.5 * gate_width + 0.1,  # x坐标
                gate_ypos,  # y坐标
                self._style["displaytext"].get(gate['name'].lower(), gate['name']),  # 门文本
                ha="center",  # 水平对齐方式
                va="center",  # 垂直对齐方式
                fontsize=self._style["fontsize"] * self._style['scale_char'],  # 字体大小
                color=self._style["gatetextcolor"],  # 文本颜色
                clip_on=True,  # 是否裁剪
                zorder=PORDER_TEXT,  # 绘制顺序
            )

    # 绘制受控门的方法
    def _control_gate(self, gate):
        """Draw controlled gate"""
        xpos, ypos = gate['x'], gate['y']  # 分解坐标为x和y
        gate_width = gate['gate_width']
        cqmin = min(gate['target'] + gate['control'])
        cqmax = max(gate['target'] + gate['control'])
        qmin = gate['qmin']
        qmax = gate['qmax']

        y_qmin = ypos + self._style['y_offset'] + qmax - cqmin
        y_qmax = ypos + self._style['y_offset'] + qmax - cqmax

        for i, control_bit in enumerate(gate['control']):
            y = ypos + self._style['y_offset'] + qmax - control_bit
            if qmin <= control_bit <= qmax:
                continue
            self._ctrl_qubit(xpos + 0.5 * gate_width, y, ctrl_state=gate['control_sequence'][i])

        # 绘制连接控制位和目标位的线
        # 计算竖线 x
        line_x = xpos + 0.5 * gate_width

        # 计算 gate box 顶部和底部
        v_margin = 0.1
        box_top = ypos + v_margin + (qmax - qmin + 1 - 2*v_margin)
        box_bottom = ypos + v_margin

        # 竖线完整范围
        line_top = y_qmin
        line_bottom = y_qmax

        # 上半段
        if line_top > box_top:
            self._line(
                (line_x, line_top),
                (line_x, box_top),
                lc=self._style['gatefacecolor']
            )

        # 下半段
        if line_bottom < box_bottom:
            self._line(
                (line_x, box_bottom),
                (line_x, line_bottom),
                lc=self._style['gatefacecolor']
            )

        # 处理受控X门
        if gate['id'] == 'x':
            # tgt_color = self._style["dispcol"]["target"]  # 获取目标颜色
            # tgt = tgt_color if isinstance(tgt_color, str) else tgt_color[0]  # 提取目标颜色
            # 绘制X门的目标量子比特
            gate_color = self._style['displaycolor']['target']
            xpos = xpos + 0.5 * gate_width
            ypos = ypos + self._style['y_offset']
            self._x_tgt_qubit(xpos, ypos, ec=gate_color[0], ac=gate_color[1])

        # elif gate['id'] == 'z':
        #     self._ctrl_qubit(xpos + 0.5 * gate_width, ypos + self._style['y_offset'])

        # 处理其他单目标量子比特门
        elif len(gate['target']) == 1:
            self._gate(gate)  # 绘制单量子比特门

        # 处理其他多目标量子比特门
        else:
            self._multiqubit_gate(gate)  # 绘制多量子比特门

    # 绘制控制量子比特的方法
    def _ctrl_qubit(self, xpos, ypos, ctrl_state='1', in_gate=False):
        """
        Draws a control circle; if it's a top or bottom control, a control label is also drawn.

        Parameters:
        xy: The coordinates of the control circle, a (x, y) tuple.

        This method is used to draw the control qubits of a controlled gate, represented as a circle. If it's a top or bottom control qubit,

        a control label is also drawn above or below the circle. The fill color is determined by the control state:

        - Fill color indicates control state 1

        - Hollow indicates control state 0
        """
        # 创建控制圆圈
        ctrl_state = str(ctrl_state)
        if in_gate:
            radius = 0.07
            ec = self._style['gatetextcolor']
            fc = ec if ctrl_state == '1' else self._style['gatefacecolor']
        else:
            radius = 0.1
            ec = self._style['gatefacecolor']
            fc = ec if ctrl_state == '1' else 'white'
        box = self._patches_mod.Circle(
            xy=(xpos, ypos),  # 圆心坐标
            radius=self._style['gatewidth'] * radius,  # 半径
            fc=fc,  # 填充颜色
            ec=ec,  # 边缘颜色
            linewidth=self._style['lwidth15'],  # 线宽
            zorder=PORDER_GATE,  # 绘制顺序
        )
        self._ax.add_patch(box)  # 将圆圈添加到轴上

    # 绘制CNOT门目标符号的方法
    def _x_tgt_qubit(self, xpos, ypos, ec=None, ac=None):
        """
        Drawing a gradient CNOT target symbol with a technological theme
        """

        import matplotlib.patches as patches
        
        
       

        linewidth = self._style['lwidth2']
        radius = self._style['gatewidth'] * 0.35

        

        # ---------- 创建圆形边框 ----------
        circle = patches.Circle(
            (xpos, ypos),
            radius=radius,
            facecolor="#1F52F0",   # 纯色填充
            edgecolor="none",     # 无边框
            linewidth=0,
            zorder=PORDER_GATE,
        )

        self._ax.add_patch(circle)

    
        # ---------- 绘制白色 '+' ----------
        plus_color = "white"

        self._ax.plot(
            [xpos, xpos],
            [ypos - 0.2 * self._style['gatewidth'],
            ypos + 0.2 * self._style['gatewidth']],
            color=plus_color,
            linewidth=linewidth,
            zorder=PORDER_GATE_PLUS,
        )

        self._ax.plot(
            [xpos - 0.2 * self._style['gatewidth'],
            xpos + 0.2 * self._style['gatewidth']],
            [ypos, ypos],
            color=plus_color,
            linewidth=linewidth,
            zorder=PORDER_GATE_PLUS,
        )

    # # 绘制Swap门的方法
    def _swap(self, xy, color=None):
        """
        Drawing a Swap Gate

        Parameters:

        xy: A list containing the coordinates of two qubits, each coordinate being a (x, y) tuple

        color: The color of the line (optional)

        A Swap gate is used to exchange the states of two qubits, represented in the circuit as a line connecting the two qubits

        and a crossover symbol at the positions of the two qubits.
        """
        self._swap_cross(xy[0], color=color)  # 在第一个量子比特位置绘制交叉符号
        self._swap_cross(xy[1], color=color)  # 在第二个量子比特位置绘制交叉符号
        self._line(xy[0], xy[1], lc=color)  # 绘制连接两个量子比特的线

    # 绘制Swap交叉符号的方法
    def _swap_cross(self, xy, color=None):
        """
        Draw the Swap Cross Symbol

        Parameters:
        xy: The coordinates of the cross symbol, a (x, y) tuple

        color: The color of the cross symbol (optional)

        The Swap cross symbol is two intersecting diagonal lines used to identify the location of the qubits involved in the Swap gate.
        """
        xpos, ypos = xy  # 获取交叉符号的坐标

        # 绘制交叉符号的第一条线
        self._ax.plot(
            [xpos - 0.20 * self._style['gatewidth'], xpos + 0.20 * self._style['gatewidth']],  # x坐标列表
            [ypos - 0.20 * self._style['gatewidth'], ypos + 0.20 * self._style['gatewidth']],  # y坐标列表
            color=color,  # 颜色
            linewidth=self._style['lwidth2'],  # 线宽
            zorder=PORDER_LINE_PLUS,  # 绘制顺序
        )
        # 绘制交叉符号的第二条线
        self._ax.plot(
            [xpos - 0.20 * self._style['gatewidth'], xpos + 0.20 * self._style['gatewidth']],  # x坐标列表
            [ypos + 0.20 * self._style['gatewidth'], ypos - 0.20 * self._style['gatewidth']],  # y坐标列表
            color=color,  # 颜色
            linewidth=self._style['lwidth2'],  # 线宽
            zorder=PORDER_LINE_PLUS,  # 绘制顺序
        )

    # 绘制线的方法
    def _line(self, xy0, xy1, lc=None, ls=None, zorder=PORDER_LINE):
        """
        Draws a line from xy0 to xy1

        Parameters:
        xy0: The starting coordinates of the line, a (x, y) tuple

        xy1: The ending coordinates of the line, a (x, y) tuple

        lc: The line color (optional, defaults to the default color defined in the style)

        ls: The line style (optional, defaults to "solid")

        zorder: The drawing order (optional, defaults to PORDER_LINE)

        This method is a basic drawing method used to draw various lines in circuits, including qubit circuits,

        control gate connections, etc. It supports multiple line styles, including solid lines and double lines.
        """
        x0, y0 = xy0  # 获取起点坐标
        x1, y1 = xy1  # 获取终点坐标
        # 确定线的颜色
        linecolor = self._style["linecolor"] if lc is None else lc
        # 确定线的样式
        linestyle = "solid" if ls is None else ls

        # 处理双线样式
        if linestyle == "doublet":
            # 计算角度和偏移量
            theta = np.arctan2(np.abs(x1 - x0), np.abs(y1 - y0))
            dx = 0.05 * self._style['gatewidth'] * np.cos(theta)
            dy = 0.05 * self._style['gatewidth'] * np.sin(theta)
            # 绘制第一条线
            self._ax.plot(
                [x0 + dx, x1 + dx],  # x坐标列表
                [y0 + dy, y1 + dy],  # y坐标列表
                color=linecolor,  # 颜色
                linewidth=self._style['lwidth2'],  # 线宽
                linestyle="solid",  # 线的样式
                zorder=zorder,  # 绘制顺序
            )
            # 绘制第二条线
            self._ax.plot(
                [x0 - dx, x1 - dx],  # x坐标列表
                [y0 - dy, y1 - dy],  # y坐标列表
                color=linecolor,  # 颜色
                linewidth=self._style['lwidth2'],  # 线宽
                linestyle="solid",  # 线的样式
                zorder=zorder,  # 绘制顺序
            )
        else:
            # 绘制单线
            self._ax.plot(
                [x0, x1],  # x坐标列表
                [y0, y1],  # y坐标列表
                color=linecolor,  # 颜色
                linewidth=self._style['lwidth2'],  # 线宽
                linestyle=linestyle,  # 线的样式
                zorder=zorder,  # 绘制顺序
            )

    #将参数转换为字符串，保留两位小数 方便在图中显示。
    def _str_parameter(self, parameter):
        """
        Converts the parameter to a string, rounded to two decimal places.

        Parameter:
        parameter: The value of the parameter to be converted

        Return:

        The converted parameter string, rounded to two decimal places
        """
        if hasattr(parameter, 'tolist'):
            parameter = parameter.tolist()

        if isinstance(parameter, (float, int)):
            return str(round(parameter, 2))
        
        if isinstance(parameter, str):
            return parameter

        if isinstance(parameter, list):
            return "(" + ", ".join(self._str_parameter(p) for p in parameter) + ")"
