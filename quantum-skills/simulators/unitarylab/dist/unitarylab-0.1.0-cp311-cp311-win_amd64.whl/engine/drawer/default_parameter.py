from matplotlib.colors import LinearSegmentedColormap
blue_unitarylab = LinearSegmentedColormap.from_list('UnitaryLabBlue',
                                             [(0,    "#75A9E7"),
                                              (1,    "#1D49A8")], N=256)

# 常量定义（注意：这些常量在原始代码中未定义，需要在实际使用前定义）
WID = 1.0  # 门的宽度（默认值）
HIG = 1.0  # 门的高度（默认值）
# 不同绘制元素的Z轴绘制顺序（数值越大，绘制层级越高）
PORDER_REGLINE = 1      # 寄存器线
PORDER_FLOW = 3         # 控制流元素
PORDER_MASK = 4         # 遮罩
PORDER_LINE = 6         # 普通线
PORDER_LINE_PLUS = 7    # 加粗线
PORDER_BARRIER = 8      # 屏障
PORDER_GATE = 10        # 普通门
PORDER_GATE_PLUS = 11   # 特殊门
PORDER_TEXT = 13        # 文本

CHAR_WIDTHS = {
    " ": (0.0958, 0.0583),
    "!": (0.1208, 0.0729),
    '"': (0.1396, 0.0875),
    "#": (0.2521, 0.1562),
    "$": (0.1917, 0.1167),
    "%": (0.2854, 0.1771),
    "&": (0.2333, 0.1458),
    "'": (0.0833, 0.0521),
    "(": (0.1167, 0.0729),
    ")": (0.1167, 0.0729),
    "*": (0.15, 0.0938),
    "+": (0.25, 0.1562),
    ",": (0.0958, 0.0583),
    "-": (0.1083, 0.0667),
    ".": (0.0958, 0.0604),
    "/": (0.1021, 0.0625),
    "0": (0.1875, 0.1167),
    "1": (0.1896, 0.1167),
    "2": (0.1917, 0.1188),
    "3": (0.1917, 0.1167),
    "4": (0.1917, 0.1188),
    "5": (0.1917, 0.1167),
    "6": (0.1896, 0.1167),
    "7": (0.1917, 0.1188),
    "8": (0.1896, 0.1188),
    "9": (0.1917, 0.1188),
    ":": (0.1021, 0.0604),
    ";": (0.1021, 0.0604),
    "<": (0.25, 0.1542),
    "=": (0.25, 0.1562),
    ">": (0.25, 0.1542),
    "?": (0.1583, 0.0979),
    "@": (0.2979, 0.1854),
    "A": (0.2062, 0.1271),
    "B": (0.2042, 0.1271),
    "C": (0.2083, 0.1292),
    "D": (0.2312, 0.1417),
    "E": (0.1875, 0.1167),
    "F": (0.1708, 0.1062),
    "G": (0.2312, 0.1438),
    "H": (0.225, 0.1396),
    "I": (0.0875, 0.0542),
    "J": (0.0875, 0.0542),
    "K": (0.1958, 0.1208),
    "L": (0.1667, 0.1042),
    "M": (0.2583, 0.1604),
    "N": (0.225, 0.1396),
    "O": (0.2354, 0.1458),
    "P": (0.1812, 0.1125),
    "Q": (0.2354, 0.1458),
    "R": (0.2083, 0.1292),
    "S": (0.1896, 0.1188),
    "T": (0.1854, 0.1125),
    "U": (0.2208, 0.1354),
    "V": (0.2062, 0.1271),
    "W": (0.2958, 0.1833),
    "X": (0.2062, 0.1271),
    "Y": (0.1833, 0.1125),
    "Z": (0.2042, 0.1271),
    "[": (0.1167, 0.075),
    "\\": (0.1021, 0.0625),
    "]": (0.1167, 0.0729),
    "^": (0.2521, 0.1562),
    "_": (0.1521, 0.0938),
    "`": (0.15, 0.0938),
    "a": (0.1854, 0.1146),
    "b": (0.1917, 0.1167),
    "c": (0.1646, 0.1021),
    "d": (0.1896, 0.1188),
    "e": (0.1854, 0.1146),
    "f": (0.1042, 0.0667),
    "g": (0.1896, 0.1188),
    "h": (0.1896, 0.1188),
    "i": (0.0854, 0.0521),
    "j": (0.0854, 0.0521),
    "k": (0.1729, 0.1083),
    "l": (0.0854, 0.0521),
    "m": (0.2917, 0.1812),
    "n": (0.1896, 0.1188),
    "o": (0.1833, 0.1125),
    "p": (0.1917, 0.1167),
    "q": (0.1896, 0.1188),
    "r": (0.125, 0.0771),
    "s": (0.1562, 0.0958),
    "t": (0.1167, 0.0729),
    "u": (0.1896, 0.1188),
    "v": (0.1771, 0.1104),
    "w": (0.2458, 0.1521),
    "x": (0.1771, 0.1104),
    "y": (0.1771, 0.1104),
    "z": (0.1562, 0.0979),
    "{": (0.1917, 0.1188),
    "|": (0.1, 0.0604),
    "}": (0.1896, 0.1188),
}

def matplotlib_close_if_inline(figure):
    """Close the given matplotlib figure if the backend in use draws figures inline.

    If the backend does not draw figures inline, this does nothing.  This function is to prevent
    duplicate images appearing; the inline backends will capture the figure in preparation and
    display it as well, whereas the drawers want to return the figure to be displayed."""
    # This can only called if figure has already been created, so matplotlib must exist.
    import matplotlib.pyplot

    MATPLOTLIB_INLINE_BACKENDS = {
        "module://ipykernel.pylab.backend_inline",
        "module://matplotlib_inline.backend_inline",
        "nbAgg",
    }

    if matplotlib.get_backend() in MATPLOTLIB_INLINE_BACKENDS:
        matplotlib.pyplot.close(figure)

dark_style = {
    "x_offset": 0.5,
    "y_offset": 0.5,
    "scale_char": 2.0,
    "gatewidth": 1,
    "lwidth1": 1.0,
    "lwidth15": 1.5,
    "lwidth2": 2.0,
    "lwidth3": 3.0,
    "lwidth4": 4.0,
    "registercolor": "#0057FF",
    "textcolor": "#FFFFFF",
    "gatetextcolor": "#FFFFFF",
    "subtextcolor": "#FFFFFF",
    "linecolor": "#686868",
    "gatefacecolor": "#0057FF",
    "barrierfacecolor": "#686868",
    "backgroundcolor": "#00272727",
    "edgecolor": None,
    "fontsize": 13,
    "subfontsize": 8,
    "showindex": False,
    "figwidth": -1,
    "dpi": 150,
    "margin": [
        0.1,
        0.1,
        0.1,
        0.3
    ],
    "creglinestyle": "doublet",
    "displaytext": {
        "u1": "$U_1$",
        "u2": "$U_2$",
        "u3": "$U_3$",
        "id": "$I$",
        "sdg": "$S^\\dagger$",
        "sx": "$\\sqrt{X}$",
        "sxdg": "$\\sqrt{X}^\\dagger$",
        "tdg": "$T^\\dagger$",
        "ms": "$MS$",
        "x": "$X$",
        "y": "$Y$",
        "z": "$Z$",
        "rx": "$R_X$",
        "ry": "$R_Y$",
        "rz": "$R_Z$",
        "rxx": "$R_{XX}$",
        "ryy": "$R_{YY}$",
        "rzx": "$R_{ZX}$",
        "rzz": "$ZZ$",
        "reset": "$\\left|0\\right\\rangle$",
        "initialize": "$|\\psi\\rangle$",
        "zoom_in": "$U$",
        "phase_gate": "$P$",
        "swap": "",
        "sw": ""
    },
    "displaycolor": {
        "u1": [
            "#4589FF",
            "#FFFFFF"
        ],
        "u2": [
            "#0057FF",
            "#FFFFFF"
        ],
        "u3": [
            "#0057FF",
            "#FFFFFF"
        ],
        "u": [
            "#0057FF",
            "#FFFFFF"
        ],
        "p": [
            "#4589FF",
            "#FFFFFF"
        ],
        "id": [
            "#4589FF",
            "#FFFFFF"
        ],
        "x": [
            "#4589FF",
            "#FFFFFF"
        ],
        "y": [
            "#0057FF",
            "#FFFFFF"
        ],
        "z": [
            "#4589FF",
            "#FFFFFF"
        ],
        "h": [
            "#4589FF",
            "#FFFFFF"
        ],
        "cx": [
            "#935AF6",
            "#FFFFFF"
        ],
        "ccx": [
            "#935AF6",
            "#FFFFFF"
        ],
        "mcx": [
            "#935AF6",
            "#FFFFFF"
        ],
        "mcx_gray": [
            "#935AF6",
            "#FFFFFF"
        ],
        "cy": [
            "#935AF6",
            "#FFFFFF"
        ],
        "cz": [
            "#935AF6",
            "#FFFFFF"
        ],
        "cp": [
            "#935AF6",
            "#FFFFFF"
        ],
        "mcphase": [
            "#4589FF",
            "#FFFFFF"
        ],
        "swap": [
            "#4589FF",
            "#FFFFFF"
        ],
        "cswap": [
            "#4589FF",
            "#FFFFFF"
        ],
        "ccswap": [
            "#4589FF",
            "#FFFFFF"
        ],
        "dcx": [
            "#4589FF",
            "#FFFFFF"
        ],
        "cdcx": [
            "#4589FF",
            "#FFFFFF"
        ],
        "ccdcx": [
            "#4589FF",
            "#FFFFFF"
        ],
        "iswap": [
            "#0057FF",
            "#FFFFFF"
        ],
        "s": [
            "#4589FF",
            "#FFFFFF"
        ],
        "sdg": [
            "#4589FF",
            "#FFFFFF"
        ],
        "t": [
            "#4589FF",
            "#FFFFFF"
        ],
        "tdg": [
            "#4589FF",
            "#FFFFFF"
        ],
        "sx": [
            "#0057FF",
            "#FFFFFF"
        ],
        "sxdg": [
            "#0057FF",
            "#FFFFFF"
        ],
        "r": [
            "#0057FF",
            "#FFFFFF"
        ],
        "rx": [
            "#0057FF",
            "#FFFFFF"
        ],
        "ry": [
            "#0057FF",
            "#FFFFFF"
        ],
        "rz": [
             "#0057FF",
            "#FFFFFF"
        ],
        "rxx": [
            "#0057FF",
            "#FFFFFF"
        ],
        "ryy": [
            "#0057FF",
            "#FFFFFF"
        ],
        "rzx": [
            "#0057FF",
            "#FFFFFF"
        ],
        "rzz": [
            "#4589FF",
            "#FFFFFF"
        ],
        "reset": [
            "#FFA53D",
            "#FFFFFF"
        ],
        "target": [
            "#0057FF",
            "#FFFFFF"
        ],
        "measure": [
            "#FFA53D",
            "#FFFFFF"
        ]
    }
}

light_style = {
    "x_offset": 0.5,
    "y_offset": 0.5,
    "scale_char": 2.0,
    "gatewidth": 1,
    "lwidth1": 1.0,
    "lwidth15": 1.5,
    "lwidth2": 2.0,
    "lwidth3": 3.0,
    "lwidth4": 4.0,
    "registercolor": "#000000",
    "textcolor": "#000000",
    "gatetextcolor": "#000000",
    "subtextcolor": "#000000",
    "linecolor": "#CCCCCC",
    "gatefacecolor": "#E0E0E0",
    "barrierfacecolor": "#CCCCCC",
    "backgroundcolor": "#FFFFFF",
    "edgecolor": None,
    "fontsize": 13,
    "subfontsize": 8,
    "showindex": False,
    "figwidth": -1,
    "dpi": 150,
    "margin": [
        0.1,
        0.1,
        0.1,
        0.3
    ],
    "creglinestyle": "doublet",
    "displaytext": {
        "u1": "$U_1$",
        "u2": "$U_2$",
        "u3": "$U_3$",
        "id": "$I$",
        "sdg": "$S^\\dagger$",
        "sx": "$\\sqrt{X}$",
        "sxdg": "$\\sqrt{X}^\\dagger$",
        "tdg": "$T^\\dagger$",
        "ms": "$MS$",
        "x": "$X$",
        "y": "$Y$",
        "z": "$Z$",
        "rx": "$R_X$",
        "ry": "$R_Y$",
        "rz": "$R_Z$",
        "rxx": "$R_{XX}$",
        "ryy": "$R_{YY}$",
        "rzx": "$R_{ZX}$",
        "rzz": "$ZZ$",
        "reset": "$\\left|0\\right\\rangle$",
        "initialize": "$|\\psi\\rangle$",
        "zoom_in": "$U$",
        "phase_gate": "$P$",
        "swap": "",
        "sw": ""
    },
    "displaycolor": {
        "u1": [
            "#F0F0F0",
            "#000000"
        ],
        "u2": [
            "#E0E0E0",
            "#000000"
        ],
        "u3": [
            "#E0E0E0",
            "#000000"
        ],
        "u": [
            "#E0E0E0",
            "#000000"
        ],
        "p": [
            "#F0F0F0",
            "#000000"
        ],
        "id": [
            "#F0F0F0",
            "#000000"
        ],
        "x": [
            "#F0F0F0",
            "#000000"
        ],
        "y": [
            "#E0E0E0",
            "#000000"
        ],
        "z": [
            "#F0F0F0",
            "#000000"
        ],
        "h": [
            "#F0F0F0",
            "#000000"
        ],
        "cx": [
            "#D0D0D0",
            "#000000"
        ],
        "ccx": [
            "#D0D0D0",
            "#000000"
        ],
        "mcx": [
            "#D0D0D0",
            "#000000"
        ],
        "mcx_gray": [
            "#D0D0D0",
            "#000000"
        ],
        "cy": [
            "#D0D0D0",
            "#000000"
        ],
        "cz": [
            "#D0D0D0",
            "#000000"
        ],
        "cp": [
            "#D0D0D0",
            "#000000"
        ],
        "mcphase": [
            "#F0F0F0",
            "#000000"
        ],
        "swap": [
            "#F0F0F0",
            "#000000"
        ],
        "cswap": [
            "#F0F0F0",
            "#000000"
        ],
        "ccswap": [
            "#F0F0F0",
            "#000000"
        ],
        "dcx": [
            "#F0F0F0",
            "#000000"
        ],
        "cdcx": [
            "#F0F0F0",
            "#000000"
        ],
        "ccdcx": [
            "#F0F0F0",
            "#000000"
        ],
        "iswap": [
            "#E0E0E0",
            "#000000"
        ],
        "s": [
            "#F0F0F0",
            "#000000"
        ],
        "sdg": [
            "#F0F0F0",
            "#000000"
        ],
        "t": [
            "#F0F0F0",
            "#000000"
        ],
        "tdg": [
            "#F0F0F0",
            "#000000"
        ],
        "sx": [
            "#E0E0E0",
            "#000000"
        ],
        "sxdg": [
            "#E0E0E0",
            "#000000"
        ],
        "r": [
            "#E0E0E0",
            "#000000"
        ],
        "rx": [
            "#E0E0E0",
            "#000000"
        ],
        "ry": [
            "#E0E0E0",
            "#000000"
        ],
        "rz": [
             "#E0E0E0",
            "#000000"
        ],
        "rxx": [
            "#E0E0E0",
            "#000000"
        ],
        "ryy": [
            "#E0E0E0",
            "#000000"
        ],
        "rzx": [
            "#E0E0E0",
            "#000000"
        ],
        "rzz": [
            "#F0F0F0",
            "#000000"
        ],
        "reset": [
            "#FFF0E0",
            "#000000"
        ],
        "target": [
            "#E0E0E0",
            "#000000"
        ],
        "measure": [
            "#FFF0E0",
            "#000000"
        ]
    }
}