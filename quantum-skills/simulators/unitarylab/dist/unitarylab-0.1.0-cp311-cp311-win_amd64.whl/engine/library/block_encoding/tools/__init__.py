"""
Block-Encoding Tools Module
=======================

Utility functions for matrix manipulation and transformations.
"""

from .utils import (
    normalize_matrix,
    pad_to_power_of_two,
    matrix_norm,
)

__all__ = [
    # Matrix Utilities
    'normalize_matrix',
    'pad_to_power_of_two',
    'matrix_norm',
    'get_matrix',
]
