"""
Block-Encoding Library Module
=============================

This module provides quantum algorithms for block-encoding matrices:
- encode: Unified interface for block encoding (supports fable and nagy methods)
- fable: Fast Approximate BLock-Encodings implementation
- utils: Helper functions for matrix manipulation
- circuit: Circuit conversion and building utilities
"""

from .block_encoder import (
    block_encode,
    BlockEncodingResult,
)

from .fable import (
    FABLE,
)

from .nagy import (
    Nagy,
)


__all__ = [
    # Unified Interface
    "block_encode",
    "BlockEncodingResult",
    
    # Core
    "FABLE",
    "Nagy",
]