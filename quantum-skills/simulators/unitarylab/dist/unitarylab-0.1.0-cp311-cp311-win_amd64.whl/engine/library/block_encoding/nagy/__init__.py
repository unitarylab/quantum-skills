"""
Nagy Block Encoding Module
========================

Implementation of Nagy's method for block encoding matrices.
"""

from .nagy import Nagy

__all__ = [
    'Nagy',
]
