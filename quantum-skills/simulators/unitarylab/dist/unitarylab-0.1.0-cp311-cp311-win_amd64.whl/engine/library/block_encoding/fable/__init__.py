"""
Block-Encoding Library Module
=============================

This module provides quantum algorithms for block-encoding matrices:
- fable: Fast Approximate BLock-Encodings implementation
- utils: Helper functions for matrix manipulation
- circuit: Circuit conversion and building utilities
"""

from .fable import (
    FABLE,
)

__all__ = [
    # Core
    "FABLE",
]