"""
Library Module
==============

This module provides various libraries for quantum computing:
- differential_operator: Differential operator implementations
- QFT: Quantum Fourier Transform implementation
- schrodingerization: Schrödingerization algorithms
"""

from .differential_operator import (
    CDiff,
    TDiff,
    ClassicalOperator,
    TrotterOperator,
)

from .QFT import (
    QFT,
    IQFT,
)

from .schrodingerization import (
    schro_trotter,
    initial_schro_fp,
    schro_classical,
)

from .equation_parser import (
    parse_equation,
)

from .block_encoding import (
    block_encode,
)

__all__ = [
    "CDiff",
    "TDiff",
    "ClassicalOperator",
    "TrotterOperator",
    "QFT",
    "IQFT",
    "schro_trotter",
    "initial_schro_fp",
    "schro_classical",
    "parse_equation",
    "block_encode",
]
