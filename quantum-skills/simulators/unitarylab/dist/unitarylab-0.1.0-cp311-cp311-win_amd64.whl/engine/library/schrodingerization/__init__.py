"""
Schrödingerization Library Module
=================================

This module provides quantum algorithms for Schrödingerization:
- schro: General Schrödingerization solver
- control_H_b: Control operator with boundary
- initial_schro_fp: Initial Schrödingerization phase factor
"""

from .trotter import (
    schro_trotter,
    initial_schro_fp,
)

from .classical import (
    schro_classical,
)

__all__ = [
    "schro_trotter",
    "initial_schro_fp",
    "schro_classical",
]