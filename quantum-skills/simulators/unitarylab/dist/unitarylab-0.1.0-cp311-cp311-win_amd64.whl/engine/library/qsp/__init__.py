"""
QSP Module
==========

This module provides Quantum Signal Processing (QSP) implementations:
- QSP_Hamiltonian_Simulation: Hamiltonian simulation using QSP
- QSP_Phase_factor_Solver: Phase factor solver for QSP
- QSP_matrix_function_block_encoding: Matrix function block encoding using QSP
"""

from .QSP_Hamiltonian_Simulation import QSP_hamiltonian_simulation
from .QSP_Phase_factor_Solver import QSP_solver
from .QSP_matrix_function_block_encoding import QSP_block_encoding

__all__ = [
    "QSP_hamiltonian_simulation",
    "QSP_solver",
    "QSP_block_encoding",
]