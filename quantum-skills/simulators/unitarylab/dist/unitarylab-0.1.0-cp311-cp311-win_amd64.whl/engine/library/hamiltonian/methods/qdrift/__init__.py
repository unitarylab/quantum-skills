
# -*- coding: utf-8 -*-

"""
QDrift random product formula for Hamiltonian simulation.
"""

from .qdrift import QDrift

__all__ = [
    'QDrift',
]