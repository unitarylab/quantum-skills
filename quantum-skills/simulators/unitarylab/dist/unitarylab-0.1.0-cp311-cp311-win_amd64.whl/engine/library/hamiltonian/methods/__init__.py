# -*- coding: utf-8 -*-

import numpy as np
from dataclasses import dataclass, field
from typing import Optional, List, Tuple
from ....core import GateSequence, Register
from scipy.linalg import expm
from ..utils.pauli_string_decomposition import pauli_string_decomposition, pauli_string_band_matrix


@dataclass
class HamiltonianSimulationResult:
    """
    Result container for Hamiltonian simulation with lazy evaluation.

    This class encapsulates the parameters and results of a Hamiltonian
    simulation. The actual circuit and error are computed on demand using
    the `_run()` method, which should be implemented to perform the
    specific simulation algorithm.

    Attributes:
        method (str): Simulation method used (e.g., 'trotter', 'qdrift', 'qsvt', 'cartan-lax').
        H (np.ndarray): Input Hamiltonian matrix (after potential padding).
        t (float): Evolution time.
        target_error (float): Desired simulation error tolerance.
        target_qubits (int): Number of qubits derived from the Hamiltonian dimension.
        _circuit (Optional[GateSequence]): Cached circuit (internal use).
        _total_error (Optional[float]): Cached total error (internal use).
        _evolution_result (Optional[np.ndarray]): Cached evolution matrix (internal use).
    """
    method: str
    H: np.ndarray
    t: float
    target_error: float
    tol: float = 1e-12
    original_H: np.array = field(init=False)
    target_qubits: int = field(init=False)
    _circuit: Optional[GateSequence] = field(init=False, repr=False, default=None)
    _total_error: Optional[float] = field(init=False, repr=False, default=None)
    _evolution_result: Optional[np.ndarray] = field(init=False, repr=False, default=None)

    def __post_init__(self) -> None:
        """Post-initialization: compute target_qubits from Hamiltonian dimension."""
        # Store the original Hamiltonian and convert to matrix object
        H = self.original_H = np.matrix(self.H)
        
        # Check that the matrix is square
        if H.shape[0] != H.shape[1]:
            raise ValueError("Matrix must be square.")
        
        # Verify Hermiticity (within numerical tolerance)
        if not np.allclose(H, H.conj().T, atol=self.tol, rtol=self.tol):
            raise ValueError("Matrix must be Hermitian.")
        
        # If the dimension is not a power of 2, pad with zeros to the next power of 2
        new_dim = 0
        dim = self.dim = H.shape[0]
        if (dim & (dim - 1)) != 0:   # Bitwise check for power of two
            new_dim = 1 << (dim - 1).bit_length()   # Compute next power of two
            new_H = np.zeros((new_dim, new_dim), dtype=complex)
            new_H[:dim, :dim] = H
            H = np.matrix(new_H)
            print(f"Warning: Hamiltonian dimension {dim} is not a power of 2. "
                  f"Padded to {new_dim} with zeros.")
        else:
            new_dim = dim
        self.H = np.matrix(H)
        # Number of qubits needed = log2(padded dimension)
        self.target_qubits = int(np.log2(new_dim))
        
        # Check if the Hamiltonian is real (zero imaginary part)
        self.real = False
        if np.linalg.norm(H.imag) < self.tol:
            self.real = True
            # Compute bandwidth for real banded matrices (enables optimized Pauli decomposition)
            self.bandwidth = self._get_bandwidth(self.H, tol=self.tol)
    
    def __repr__(self) -> str:
        """User-friendly representation of the result object."""
        return (f"HamiltonianSimulationResult(method={self.method}, "
                f"target_error={self.target_error})")

    def _run(self) -> None:
        """
        Perform the actual simulation and store the results.

        This method should be overridden or implemented to compute:
            - self._circuit: the quantum circuit (GateSequence)
            - self._total_error: the approximation error (float)
            - self._evolution_result: the matrix representation of the circuit (np.ndarray)
        Currently, it returns an empty circuit as a placeholder.
        """
        reg = Register('K', self.target_qubits)
        self._circuit = GateSequence(reg, name='Quantum circuit for Hamiltonian Simulation')
        self._total_error = -1.0
        self._evolution_result = self._circuit.get_matrix()
    
    def _pauli_decompose(self, H: np.ndarray, t: float) -> List[Tuple[str, complex]]:
        """
        Decompose the Hamiltonian into a list of Pauli strings with coefficients.

        For real banded Hamiltonians, a specialized basis of Pauli strings is used
        to reduce the number of terms. Otherwise, a full general decomposition is applied.
        """
        decomposition: List[Tuple[str, complex]] = []
        if self.real:
            # Use banded structure to generate Pauli strings (reverse order for compatibility)
            all_strings = pauli_string_band_matrix(self.target_qubits, self.bandwidth)
            decomposition = pauli_string_decomposition(
                H * t,
                all_strings,
                partition_commuting=False,
                real_symmetric_hint=True,
            )
        else:    
            decomposition = pauli_string_decomposition(H * t, partition_commuting=False)
        return decomposition
    
    def _get_bandwidth(self, H, tol=1e-10):
        """
        Compute the bandwidth of a matrix.

        Bandwidth definition: the smallest integer k such that for all |i-j| > k,
        H[i,j] ≈ 0 (within tolerance).

        Parameters:
            H: input matrix
            tol: numerical tolerance

        Returns:
            bandwidth: the half-bandwidth of the matrix
        """
        n = H.shape[0]
        
        # Iteratively test k = 0,1,2,... until all outside positions are zero
        for k in range(n):
            # Build a mask marking positions where |i-j| > k
            mask = np.abs(np.subtract.outer(np.arange(n), np.arange(n))) > k
            # Check whether those positions are close to zero
            if np.allclose(H[mask], 0, atol=tol, rtol=tol):
                bandwidth = k
                break
        else:
            bandwidth = n - 1  # Full matrix (no zero outside any band)
        
        return bandwidth

    @property
    def circuit(self) -> GateSequence:
        """Lazily compute and return the quantum circuit."""
        # If the circuit hasn't been built yet, run the construction routine
        if self._circuit is None:
            self._run()
        # Return the cached circuit
        return self._circuit
    
    @property
    def total_error(self) -> float:
        """Lazily compute and return the total simulation error."""
        # Compute the error only if it hasn't been computed before
        if self._total_error is None:
            # Exact time evolution operator: exp(-i H t)
            U_exact = expm(-1j * self.original_H * self.t)
            # Ensure the approximate evolution matrix is available
            if self._evolution_result is None:
                self._run()
            # Extract the relevant part (original dimension) from the padded result
            U_approx = self._evolution_result[:self.dim, :self.dim]
            # Compute spectral norm (largest singular value) of the difference
            self._total_error = np.linalg.norm(U_exact - U_approx, 2)
        return self._total_error
    
    @property
    def evolution_result(self) -> np.ndarray:
        """Lazily compute and return the approximated evolution matrix."""
        # Build the circuit if the evolution result hasn't been computed yet
        if self._evolution_result is None:
            self._run()
        # Return only the part corresponding to the original Hilbert space dimension
        return self._evolution_result[:self.dim, :self.dim]