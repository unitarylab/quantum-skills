
# -*- coding: utf-8 -*-

"""
Trotter-Suzuki decomposition for Hamiltonian simulation.
"""

from .trotter import Trotter

__all__ = [
    'Trotter',
]