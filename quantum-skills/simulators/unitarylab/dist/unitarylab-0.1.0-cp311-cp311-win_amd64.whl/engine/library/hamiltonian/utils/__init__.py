"""Hamiltonian utility package public API.

This module re-exports commonly used helpers for:
- Pauli-string decomposition and algebra
- Linear combination of unitaries (LCU)
- QSP phase-factor solving
- Example Hamiltonian builders for quick tests
"""

from .example import build_dirichlet, build_pauli_string, build_symmetric_banded_matrix
from .linear_combination_unitary import LCU
from .pauli_string_decomposition import (
	pauli_string_band_matrix,
	pauli_string_circuit,
	pauli_string_commutator,
	pauli_string_decomposition,
	pauli_string_evolution,
	pauli_string_multiply,
	pauli_string_power,
	pauli_string_product,
	pauli_string_to_matrix,
)
from .qsp_phase_factor_solver import qsp_solver

__all__ = [
	"LCU",
	"qsp_solver",
	"pauli_string_decomposition",
	"pauli_string_to_matrix",
	"pauli_string_circuit",
	"pauli_string_evolution",
	"pauli_string_multiply",
	"pauli_string_product",
	"pauli_string_power",
	"pauli_string_commutator",
	"pauli_string_band_matrix",
	"build_dirichlet",
	"build_pauli_string",
	"build_symmetric_banded_matrix",
]
