"""
Differential Operator Library
============================

This module provides differential operators for quantum computing:
- DifferentialOperator: Base class for differential operators
- ClassicalOperator: Classical matrix-based differential operator
- TrotterOperator: Trotter decomposition based quantum differential operator
- CDiff: Classical differential operator implementation
- TDiff: Trotter differential operator implementation
- Various derivative operators (zero to fourth order)
"""

from .base import (
    DifferentialOperator,
)

from .differential_operators import (
    ClassicalOperator,
    TrotterOperator,
    CDiff,
    TDiff,
)

from .trotter_circuits import (
    Wj,
    B0j,
    Bnj,
    single_diagonal_element,
    single_element,
    zero_diagonal,
    first_diagonal,
    second_diagonal,
    zero_order_derivative,
    first_order_derivative,
    second_order_derivative,
    third_order_derivative,
    fourth_order_derivative,
    fnMatrix,
    fnElement,
)

__all__ = [
    "DifferentialOperator",
    "ClassicalOperator",
    "TrotterOperator",
    "CDiff",
    "TDiff",
    "Wj",
    "B0j",
    "Bnj",
    "single_diagonal_element",
    "single_element",
    "zero_diagonal",
    "first_diagonal",
    "second_diagonal",
    "zero_order_derivative",
    "first_order_derivative",
    "second_order_derivative",
    "third_order_derivative",
    "fourth_order_derivative",
    "fnMatrix",
    "fnElement",
]
