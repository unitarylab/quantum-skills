from .fundamental_gates_functions import *
# from .fundamental_gates_functions import control_one_qubit_rotation, create_qubit, kill_qubit, zoom_in_permutation, zoom_out_permutation, kill_nonzero_qubit, swap,measure

# from tqdm import tqdm
import torch
import numpy as np
from .config_manager import device, datatype
from .fundamental_gates_unitary import gate_set
from .fundamental_digital_functions import binary_form_of_integer

def EXECUTE(gate_sequence, quantum_state):
    """
    This function executes the gate sequence and returns the resulting quantum state.
    :param gate_sequence: The gate circuit information
    :param quantum_state: The initial quantum state (torch.Tensor on CUDA)
    :return: The resulting quantum state (torch.Tensor on CUDA)
            classical_results_map:{(全局的经典寄存器索引,记录测量比特相位)}
    """
    if not isinstance(quantum_state, torch.Tensor):
        quantum_state = torch.tensor(quantum_state, dtype=datatype, device=device)

    n = int(np.log2(len(quantum_state.reshape(-1, 1)))) # The number of the qubits
    pure_ancilla_list = [] #This is the list of the name of the existing pure_ancilla
    classical_results_map = {}
    for gate in gate_sequence:
        n_all = n + len(pure_ancilla_list) #The total number of the qubits, including pure_ancilla

        
        name = gate.get('id')
        parameter = gate.get('parameter', None)
        matrix = gate.get('matrix', None)
        target = gate.get('target', [])
        control_indices = gate.get('control', [])
        control_sequence = gate.get('control_sequence', [])
        if isinstance(control_sequence, int):
            control_sequence = list(map(int, binary_form_of_integer(control_sequence, len(control_indices))))
        if isinstance(target, int):
            target = [target]
        block_gate_sequence = gate.get('block_gate_sequence', None)

        #Translate target index and control index
        target, control_indices = target_and_control_index_translater(target, control_indices, n, pure_ancilla_list)
        if name == 'i':
            pass
        elif name == 'h':
            quantum_state = control_one_qubit_H_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 'x':
            quantum_state = control_one_qubit_X_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 'y':
            quantum_state = control_one_qubit_Y_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 'z':
            quantum_state = control_one_qubit_Z_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 's':
            quantum_state = control_one_qubit_S_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 'sdag':
            quantum_state = control_one_qubit_S_dag_special(n_all, quantum_state, control_indices, control_sequence, target[0])
        elif name == 't':
            quantum_state = control_one_qubit_phase(n_all, quantum_state, control_indices, control_sequence, target[0], parameter=torch.pi/4)
        elif name == 'tdag':
            quantum_state = control_one_qubit_phase(n_all, quantum_state, control_indices, control_sequence, target[0], parameter=-torch.pi/4)
        elif name == 'phase_gate':
            quantum_state = control_one_qubit_phase(n_all, quantum_state, control_indices, control_sequence, target[0], parameter=parameter)

        elif name == 'create_ancilla':
            quantum_state = create_qubit(quantum_state)
            pure_ancilla_list.append(parameter)
        elif name == 'kill_ancilla':
            quantum_state = kill_qubit(n_all, quantum_state, translate_qubit_index(parameter, n, pure_ancilla_list))
            #quantum_state = kill_nonzero_qubit(quantum_state, translate_qubit_index(parameter, n, pure_ancilla_list))
            pure_ancilla_list.remove(parameter)
        elif name == 'kill_qubit':
            quantum_state =  kill_qubit(n_all, quantum_state, translate_qubit_index(parameter, n, pure_ancilla_list))
            n -= 1
        elif name == 'kill_nonzero_ancilla':
            quantum_state = kill_nonzero_qubit(n_all, quantum_state, translate_qubit_index(parameter, n, pure_ancilla_list))
            pure_ancilla_list.remove(parameter)
        elif name == 'zoom_in':
            quantum_state = zoom_in_permutation(n_all, quantum_state, target, control_indices).reshape([2]*n_all)
            control_extraction = tuple(control_sequence) + (slice(None),) * (n_all - len(control_sequence))
            quantum_state_inside = quantum_state[control_extraction].reshape(-1,1)
            # quantum_state_inside = EXECUTE(block_gate_sequence, quantum_state_inside)[0]
            quantum_state_inside, sub_classical_map = EXECUTE(block_gate_sequence, quantum_state_inside)
            classical_results_map.update(sub_classical_map)
            quantum_state[control_extraction]=quantum_state_inside.reshape([2]*(n_all-len(control_sequence)))
            quantum_state = zoom_out_permutation(n_all, quantum_state, target, control_indices)
            # quantum_state = quantum_state.reshape([2 for i in range(n_all)])
            # quantum_state = quantum_state.permute(zoom_in_permutation(n_all, quantum_state, target, control_indices))
            # control_extraction = tuple(control_sequence) + (slice(None),) * (n_all - len(control_sequence))
            # EXECUTE(block_gate_sequence, quantum_state[control_extraction].reshape(-1,1))
            # quantum_state = quantum_state.reshape([2 for i in range(n_all)])
            # quantum_state = quantum_state.permute(zoom_out_permutation(n_all, quantum_state, target, control_indices))
        elif name == 'unitary':
            # 首先对量子态做 permutation，使得目标比特排在前面
            quantum_state = zoom_in_permutation(n_all, quantum_state, target, control_indices).reshape([2]*n_all)
            # 构造切片，提取目标比特对应的子空间
            control_extraction = tuple(control_sequence) + (slice(None),) * (n_all - len(control_sequence))
            quantum_state_inside = quantum_state[control_extraction].reshape(2**len(target), -1)
            # 对子空间应用传入的任意多比特 Unitary
            quantum_state_inside = torch.tensor(matrix, dtype=datatype, device=device) @ quantum_state_inside
            # 将结果写回
            quantum_state[control_extraction] = quantum_state_inside.reshape([2]*(n_all-len(control_sequence)))
            # 最后做逆 permutation 还原比特顺序
            quantum_state = zoom_out_permutation(n_all, quantum_state, target, control_indices)
        elif name == 'swap':
            quantum_state = swap(n_all, quantum_state, target[0], target[1])
        elif name == 'measure':
            # print(f"DEBUG: 测量指令物理目标 -> 量子位:{target}, 经典位:{parameter}")
            quantum_state,sample=measure(n_all,quantum_state, target,'big')
            # parameter 是经典寄存器列表。
            if isinstance(parameter, int):
                parameter = [parameter]
            for i, bit_val in enumerate(sample):
                c_idx = parameter[i]
                classical_results_map[c_idx] = int(bit_val)
            # print(f"进行了一次测量: {target} 的测量结果(二进制状态)为：{sample}.")
        else:
            gate_unitary = gate_set[name.lower()] if parameter is None else gate_set[name.lower()](parameter)
            quantum_state = control_one_qubit_rotation(n_all, quantum_state, gate_unitary, control_indices, control_sequence, target[0])
            # control_one_qubit_rotation(n_all, quantum_state, gate_unitary, control_indices, control_sequence, target[0])
    return quantum_state.flatten(),classical_results_map

def execute_result(gate_sequence, initial_state):
    # 统一转换为 numpy array
    if isinstance(initial_state, torch.Tensor):
        initial_state = initial_state.cpu().numpy()
    
    # 现在可以安全地使用 .copy()
    initial_state = initial_state.copy()
    result,map = EXECUTE(gate_sequence, initial_state)
    if device == 'cuda':
        result = result.cpu()

    return result.numpy().flatten(),map

def translate_qubit_index(qubit, n_register, pure_ancilla_list):
    """
    Converts the qubit to the corresponding integer index. Depending on the type of qubit (integer or string)
    and its specific type identifier, it is mapped to the appropriate index. The qubits ordering: register_qubit, pure_ancilla
    """
    if isinstance(qubit, str):
        return pure_ancilla_list.index(qubit) + n_register
    else:
        return qubit


def target_and_control_index_translater(target, control, n_register, pure_ancilla_list):
    """
    Converts the quantum bit indices in the target and control lists such as pure_ancilla
    to their corresponding integer indices.
    """
    target = [translate_qubit_index(q, n_register, pure_ancilla_list)
              for q in target]
    control = [
        translate_qubit_index(q, n_register, pure_ancilla_list) for q
        in control]
    return target, control



if __name__ == '__main__':
    gate_sequence_small = [
        {"name": "ry", "id": "ry", "control_sequence": [0], "control": [1], "target": [0], "parameter": np.pi / 2}]
    gate_sequence = [{"name": "h", "id": "h", 'control_sequence': [], "control": [], "target": [0]}]
    gate_sequence += [{"name": "h", "id": "h", 'control_sequence': [], "control": [], "target": [2]}]
    gate_sequence += [{"name": "x", "id": "x", 'control_sequence': [], "control": [], "target": [3]}]
    gate_sequence += [{"name": "zoom_in", "id": "zoom_in", "block_gate_sequence": gate_sequence_small, "target": [1, 0], "control": [2],
                       "control_sequence": [0]}]
    gate_sequence += [{"name": "x", "id": "x", 'control_sequence': [], "control": [], "target": [1]}]
    quantum_state = torch.zeros(2 ** 4, dtype=torch.complex64)
    quantum_state[0] = 1
    print(EXECUTE(gate_sequence, quantum_state))

