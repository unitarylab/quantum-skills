"""
OpenQASM 3.0 to gate_sequence converter.
"""



from __future__ import annotations

import ast
import math
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

Gate = Dict[str, Any]

"""
Safe expression evaluator for gate parameters.

This evaluator parses simple arithmetic expressions using AST and
only allows a restricted set of operations for safety.

"""
# ---------- safe expression evaluator for parameters (supports pi, + - * /, parentheses) ----------

class _SafeEval(ast.NodeVisitor):
    """
    Allowed binary operators.
    """
    ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div)
    
    """
    Allowed unary operators.
    """
    ALLOWED_UNARYOPS = (ast.UAdd, ast.USub)

    def __init__(self, names: Optional[dict] = None):
        """
        Initialize evaluator with allowed constant names.
        """
        self.names = names or {"pi": math.pi}

    def visit(self, node):
        """
        Visit AST node.
        """
        return super().visit(node)

    def generic_visit(self, node):
        """
        Reject unsupported AST nodes.
        """
        raise ValueError(f"Unsupported expression node: {type(node).__name__}")

    def visit_Expression(self, node: ast.Expression):
        """
        Evaluate expression node.
        """
        return self.visit(node.body)

    def visit_BinOp(self, node: ast.BinOp):
        """
        Evaluate binary operations.
        """
        if not isinstance(node.op, self.ALLOWED_BINOPS):
            raise ValueError(f"Unsupported binary operator: {type(node.op).__name__}")
        left = self.visit(node.left)
        right = self.visit(node.right)
        if isinstance(node.op, ast.Add):
            return left + right
        if isinstance(node.op, ast.Sub):
            return left - right
        if isinstance(node.op, ast.Mult):
            return left * right
        if isinstance(node.op, ast.Div):
            return left / right
        raise ValueError("Unreachable")

    def visit_UnaryOp(self, node: ast.UnaryOp):
        """
        Evaluate unary operations.
        """
        if not isinstance(node.op, self.ALLOWED_UNARYOPS):
            raise ValueError(f"Unsupported unary operator: {type(node.op).__name__}")
        val = self.visit(node.operand)
        if isinstance(node.op, ast.UAdd):
            return +val
        if isinstance(node.op, ast.USub):
            return -val
        raise ValueError("Unreachable")

    def visit_Name(self, node: ast.Name):
        """
        Resolve named constants such as 'pi'.
        """
        if node.id not in self.names:
            raise ValueError(f"Unknown name in expression: {node.id}")
        return float(self.names[node.id])

    def visit_Constant(self, node: ast.Constant):
        """
        Allow numeric constants only.
        """
        if isinstance(node.value, (int, float)):
            return float(node.value)
        raise ValueError(f"Unsupported constant: {node.value!r}")


def _eval_param(expr: str) -> float:
    """
    Evaluate parameter expression safely.

    Supports numeric constants, 'pi', and basic arithmetic operations.
    """
    expr = expr.strip()
    """
    Fast path for numeric constants.
    """
    try:
        return float(expr)
    except Exception:
        pass
    """
    Evaluate expression via safe AST evaluation.
    """
    tree = ast.parse(expr, mode="eval")
    return float(_SafeEval().visit(tree))


# ---------- utilities ----------
"""
Utility functions for parsing QASM code.
"""
def _strip_comments(code: str) -> str:
    """
    Remove line and block comments from QASM code.
    """
    code = re.sub(r"//.*?$", "", code, flags=re.MULTILINE)
    code = re.sub(r"/\*.*?\*/", "", code, flags=re.DOTALL)
    return code


def _split_statements(body: str) -> List[str]:
    """
    Split QASM body into statements separated by ';'.
    Statements inside parentheses are preserved.
    """
    stmts = []
    buf = []
    depth = 0
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
            if depth < 0:
                raise ValueError("Unbalanced parentheses")
        if ch == ";" and depth == 0:
            s = "".join(buf).strip()
            if s:
                stmts.append(s)
            buf = []
        else:
            buf.append(ch)
    tail = "".join(buf).strip()
    if tail:
        # usually last one should end with ';' but tolerate missing
        stmts.append(tail)
    return stmts


def _parse_ident_list(s: str) -> List[str]:
    # split by commas
    parts = [p.strip() for p in s.split(",") if p.strip()]
    for p in parts:
        if not re.match(r"^[A-Za-z_]\w*$", p):
            raise ValueError(f"Invalid identifier: {p!r}")
    return parts


def _parse_operands_list(s: str) -> List[str]:
    # operands are separated by commas
    return [p.strip() for p in s.split(",") if p.strip()]


def _parse_modifiers_prefix(s: str) -> Tuple[List[str], str]:
    mods = []
    rest = s.strip()
    while True:
        m = re.match(r"^(ctrl|negctrl)\s*@\s*(.*)$", rest, flags=re.DOTALL)
        if not m:
            break
        mods.append(m.group(1))
        rest = m.group(2).lstrip()
    return mods, rest


def _parse_op_and_args(s: str) -> Tuple[str, Optional[List[float]], List[str]]:
    """
    Parse: OP[(params)] [operands]
    Returns: (op, params_list_or_None, operands_as_strings)
    """
    s = s.strip()
    m = re.match(r"^([A-Za-z_]\w*)\s*(.*)$", s, flags=re.DOTALL)
    if not m:
        raise ValueError(f"Cannot parse op name from: {s!r}")
    op = m.group(1)
    rest = m.group(2).lstrip()

    params = None
    if rest.startswith("("):
        # find matching ')'
        depth = 0
        end = None
        for i, ch in enumerate(rest):
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        if end is None:
            raise ValueError(f"Unclosed parameter list in: {s!r}")
        inside = rest[1:end].strip()
        rest2 = rest[end + 1 :].strip()
        if inside == "":
            params = []
        else:
            raw_params = [p.strip() for p in inside.split(",")]
            params = [_eval_param(p) for p in raw_params]
        rest = rest2

    operands = _parse_operands_list(rest) if rest else []
    return op, params, operands


def _operand_to_index(operand: str, qreg_name: str, local_map: Optional[dict]) -> int:
    operand = operand.strip()
    # q[12]
    m = re.match(r"^([A-Za-z_]\w*)\s*\[\s*(\d+)\s*\]$", operand)
    if m:
        reg = m.group(1)
        idx = int(m.group(2))
        if reg != qreg_name:
            raise ValueError(f"Unexpected qreg name {reg!r}, expected {qreg_name!r}")
        return idx
    # local identifier (e.g., a0)
    if local_map is not None:
        if operand not in local_map:
            raise ValueError(f"Unknown local qubit name in gate body: {operand!r}")
        return int(local_map[operand])
    raise ValueError(f"Unsupported operand form: {operand!r}")


def _bits_list_to_int(bits: List[int]) -> int:
    return int("".join(str(b) for b in bits), 2) if bits else 0


def _int_to_bits_list(j: int, k: int) -> List[int]:
    b = format(j, f"0{k}b")
    return [1 if ch == "1" else 0 for ch in b]

"""
Data structure describing a custom gate definition.
"""
@dataclass
class _GateDef:
    """
    Gate name.
    """
    name: str
    """
    Gate name.
    """
    args: List[str]
    """
    Statements inside gate body.
    """
    body_stmts: List[str]  # raw statements inside { ... } without trailing ';'


# ---------- main converter ----------
"""
Main converter function.

Convert an OpenQASM 3.0 program into a gate_sequence representation.

"""
def openqasm3_to_gate_sequence(
    qasm_code: str,
    *,
    prefer_int_target: bool = True,
    prefer_int_control_sequence: bool = True,
    merge_minus_z: bool = True,
    pi_tol: float = 1e-10,
) -> List[Gate]:
    """
    Convert a restricted OpenQASM 3.0 program (only features covered by your gate_sequence)
    back into gate_sequence.

    Supported ops: x,y,z,h,s,sdg,rx,ry,rz,p,U,swap,gphase and custom gate defs/calls.
    Controlled forms via 'ctrl @' / 'negctrl @'.

    Output conventions:
      - target: int (if single and prefer_int_target) else list[int]
      - control_sequence: int (if prefer_int_control_sequence) else list[0/1]
    """
    code = _strip_comments(qasm_code)

    """
    Extract qreg name and size.
    """
    qreg_name = None
    m = re.search(r"\bqubit\s*\[\s*\d+\s*\]\s*([A-Za-z_]\w*)\s*;", code)
    if m:
        qreg_name = m.group(1)
    else:
        # tolerate "qubit q0;" style, but then we cannot support q[...]
        m2 = re.search(r"\bqubit\s+([A-Za-z_]\w*)\s*;", code)
        if m2:
            qreg_name = m2.group(1)
        else:
            # if program has only gate defs we still parse, but need qreg_name for q[...] operands
            qreg_name = "q"

    # --- parse all gate definitions at top-level ---
    gate_defs: Dict[str, _GateDef] = {}

    # We do a simple brace-matching scan for "gate NAME ... { ... }"
    i = 0
    n = len(code)
    consumed_spans: List[Tuple[int, int]] = []

    while True:
        m = re.search(r"\bgate\b", code[i:])
        if not m:
            break
        start = i + m.start()
        # ensure it's top-level (not inside another gate body)
        # We'll approximate by counting braces before start.
        prefix = code[:start]
        if prefix.count("{") != prefix.count("}"):
            i = start + 4
            continue

        # parse header: gate NAME arglist {
        header_m = re.match(r"\bgate\s+([A-Za-z_]\w*)\s+([^{}]*?)\s*\{", code[start:], flags=re.DOTALL)
        if not header_m:
            raise ValueError(f"Malformed gate definition near: {code[start:start+80]!r}")
        gname = header_m.group(1)
        arglist_str = header_m.group(2).strip()
        args = _parse_ident_list(arglist_str)

        brace_open_pos = start + header_m.end() - 1  # points at '{'
        depth = 0
        end_pos = None
        for j in range(brace_open_pos, n):
            if code[j] == "{":
                depth += 1
            elif code[j] == "}":
                depth -= 1
                if depth == 0:
                    end_pos = j
                    break
        if end_pos is None:
            raise ValueError(f"Unclosed gate body for {gname}")

        body = code[brace_open_pos + 1 : end_pos]
        body_stmts = _split_statements(body)

        gate_defs[gname] = _GateDef(name=gname, args=args, body_stmts=body_stmts)
        consumed_spans.append((start, end_pos + 1))
        i = end_pos + 1

    # remove gate def blocks from code to get main program statements
    main_code_parts = []
    last = 0
    for a, b in sorted(consumed_spans):
        main_code_parts.append(code[last:a])
        last = b
    main_code_parts.append(code[last:])
    main_code = "".join(main_code_parts)

    # split main statements by ';'
    main_stmts = _split_statements(main_code)

    # helper: convert raw statement to gate dict(s)
    def stmt_to_gate(stmt: str, local_map: Optional[dict] = None) -> Gate:
        mods, rest = _parse_modifiers_prefix(stmt)
        op, params, operands = _parse_op_and_args(rest)

        # ignore meta-statements
        if op in ("OPENQASM", "include", "qubit", "bit"):
            raise ValueError(f"Unexpected statement in gate region: {stmt!r}")

        # turn operands into indices
        operand_idx = [_operand_to_index(o, qreg_name=qreg_name, local_map=local_map) for o in operands]

        # arity lookup
        if op in ("x", "y", "z", "h", "s", "sdg", "rx", "ry", "rz", "p", "U"):
            arity = 1
        elif op == "swap":
            arity = 2
        elif op == "gphase":
            arity = 0
        elif op in gate_defs:
            arity = len(gate_defs[op].args)
        else:
            raise NotImplementedError(f"Unsupported op in input QASM: {op!r}")

        # infer controls count and validate with modifiers
        if arity == 0:
            # gphase: if controlled, operands are control qubits
            ctrl_cnt = len(operand_idx)
            if len(mods) != ctrl_cnt:
                # uncontrolled gphase: mods==0 and operands==0 is ok
                if not (len(mods) == 0 and ctrl_cnt == 0):
                    raise ValueError(f"gphase controls mismatch: mods={mods}, operands={operands}")
            controls = operand_idx[:]  # may be []
            targets = []
        else:
            if len(operand_idx) < arity:
                raise ValueError(f"Not enough operands for {op}: {operands}")
            ctrl_cnt = len(operand_idx) - arity
            if ctrl_cnt != len(mods):
                raise ValueError(f"Control count mismatch for {stmt!r}: ctrl_cnt={ctrl_cnt}, mods={mods}")
            controls = operand_idx[:ctrl_cnt]
            targets = operand_idx[ctrl_cnt:]

        # modifiers -> control_sequence bits (MSB-first aligned with controls)
        control_bits = []
        for mmm in mods:
            if mmm == "ctrl":
                control_bits.append(1)
            elif mmm == "negctrl":
                control_bits.append(0)
            else:
                raise ValueError(f"Unknown modifier: {mmm}")

        # build gate dict
        def pack_target(tlist: List[int]) -> Any:
            if prefer_int_target and len(tlist) == 1:
                return tlist[0]
            return tlist

        def pack_control_sequence(bits: List[int]) -> Any:
            if not bits:
                return None
            if prefer_int_control_sequence:
                return _bits_list_to_int(bits)
            return bits

        # custom gate call -> zoom_in
        if op in gate_defs:
            block_seq = gate_def_to_gate_sequence(op)

            gdict: Gate = {"name": "zoom_in", "id": "zoom_in", "target": pack_target(targets), "block_gate_sequence": block_seq}
            if controls:
                gdict["control"] = controls if len(controls) > 1 else controls[0]
                cs = pack_control_sequence(control_bits)
                if cs is not None:
                    gdict["control_sequence"] = cs
            return gdict

        # standard ops mapping
        name_map = {
            "sdg": "s_dagger",
            "p": "phase_gate",
            "gphase": "global_phase",
            "U": "u",
        }
        gname = name_map.get(op, op)

        gdict: Gate = {"name": gname, "id": gname}



        if arity == 2:
            gdict["target"] = pack_target(targets)  # will stay list because len==2
        else:
            if op != "gphase":
                gdict["target"] = pack_target(targets)

        # parameters
        if op in ("rx", "ry", "rz", "p", "gphase"):
            if not params or len(params) != 1:
                raise ValueError(f"{op} expects 1 parameter, got {params}")
            gdict["parameter"] = float(params[0])
        elif op == "U":
            if not params or len(params) != 3:
                raise ValueError(f"U expects 3 parameters, got {params}")
            gdict["parameter"] = [float(params[0]), float(params[1]), float(params[2])]

        # controls
        if controls:
            gdict["control"] = controls if len(controls) > 1 else controls[0]
            cs = pack_control_sequence(control_bits)
            if cs is not None:
                gdict["control_sequence"] = cs

        return gdict

    # convert gate definitions into gate_sequence (with nested zoom_in if used)
    _gate_def_cache: Dict[str, List[Gate]] = {}

    def gate_def_to_gate_sequence(def_name: str) -> List[Gate]:
        if def_name in _gate_def_cache:
            return _gate_def_cache[def_name]

        gd = gate_defs[def_name]
        local_map = {arg: idx for idx, arg in enumerate(gd.args)}
        seq: List[Gate] = []
        for st in gd.body_stmts:
            st = st.strip()
            if not st:
                continue
            seq.append(stmt_to_gate(st, local_map=local_map))

        # optionally merge "-z" inside block as well
        if merge_minus_z:
            seq = _merge_minus_z(seq, prefer_int_target, prefer_int_control_sequence, pi_tol)

        _gate_def_cache[def_name] = seq
        return seq

    # parse main statements into gate_sequence
    seq_main: List[Gate] = []
    for st in main_stmts:
        st = st.strip()
        if not st:
            continue
        # skip declarations / includes / version lines
        if re.match(r"^OPENQASM\b", st) or re.match(r'^include\s+"', st) or re.match(r"^(qubit|bit)\b", st):
            continue
        seq_main.append(stmt_to_gate(st, local_map=None))

    # merge "-z" patterns in main
    if merge_minus_z:
        seq_main = _merge_minus_z(seq_main, prefer_int_target, prefer_int_control_sequence, pi_tol)

    return seq_main


def _same_controls(a: Gate, b: Gate) -> bool:
    def norm_ctrl(g: Gate) -> Tuple[Tuple[int, ...], Any]:
        if "control" not in g:
            return ((), None)
        ctrl = g["control"]
        if isinstance(ctrl, int):
            ctrl_t = (ctrl,)
        else:
            ctrl_t = tuple(ctrl)
        cs = g.get("control_sequence", None)
        return (ctrl_t, cs)
    return norm_ctrl(a) == norm_ctrl(b)


def _merge_minus_z(
    seq: List[Gate],
    prefer_int_target: bool,
    prefer_int_control_sequence: bool,
    pi_tol: float,
) -> List[Gate]:
    """
    Detect pattern: global_phase(pi) immediately followed by z on same controls and one target,
    and merge into a single '-z' gate on that target with same controls.
    """
    out: List[Gate] = []
    i = 0
    while i < len(seq):
        g = seq[i]
        if (
            g.get("id") == "global_phase"
            and isinstance(g.get("parameter", None), (int, float))
            and abs(float(g["parameter"]) - math.pi) <= pi_tol
            and i + 1 < len(seq)
        ):
            g2 = seq[i + 1]
            if g2.get("id") == "z" and _same_controls(g, g2) and "target" in g2:
                # merge
                mg: Gate = {"name": "-z", "id": "-z", "target": g2["target"]}
                if "control" in g2:
                    mg["control"] = g2["control"]
                    if "control_sequence" in g2:
                        mg["control_sequence"] = g2["control_sequence"]
                out.append(mg)
                i += 2
                continue
        out.append(g)
        i += 1
    return out
