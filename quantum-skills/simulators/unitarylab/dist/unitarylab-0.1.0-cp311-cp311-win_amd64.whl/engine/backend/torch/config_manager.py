"""
Device and datatype management utilities for the quantum simulation backend.
"""

import torch


class DeviceManager:
    """
    Singleton class for managing the computing device.

    Automatically selects GPU (CUDA) if available, otherwise CPU.

    """

    _instance = None

    def __new__(cls):
        """
        Create or return the singleton instance.
        """
        if cls._instance is None:
            cls._instance = super(DeviceManager, cls).__new__(cls)

            """
            Detect available device
            """
            if torch.cuda.is_available():
                cls._instance.device = 'cuda'
            else:
                cls._instance.device = 'cpu'

        return cls._instance

    def set_device(self, device_name):
        """
        Set the computing device.

        Parameters
        ----------
        device_name : str
            Device name (e.g., 'cpu', 'cuda').
        """
        self.device = device_name

    def get_device(self):
        """
        Get the current computing device.
       

        Returns 
        -------
        str
            Current device name.
            
        """
        return self.device


class DatetypeManager:
    """
    Singleton class for managing the default tensor datatype.
    

    Default datatype is torch.complex128.
    
    """

    _instance = None

    def __new__(cls):
        """
        Create or return the singleton instance.
        
        """
        if cls._instance is None:
            cls._instance = super(DatetypeManager, cls).__new__(cls)

            """
            Initialize default datatype
            
            """
            cls._instance.datetype = torch.complex128

        return cls._instance

    def set_datetype(self, date_type):
        """
        Set the default tensor datatype.
        

        Parameters 
        ----------
        date_type : torch.dtype
            Desired tensor datatype.
            
        """
        self.datetype = date_type

    def get_datetype(self):
        """
        Get the current tensor datatype.
        

        Returns 
        -------
        torch.dtype
            Current datatype.
            
        """
        return self.datetype


"""
Initialize global device and datatype variables

"""
datatype = DatetypeManager().get_datetype()
device = DeviceManager().get_device()