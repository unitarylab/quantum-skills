from .fundamental_gates_functions import dagger
from .qasm_exporter import gate_sequence_to_openqasm3
from .qasm_importer import openqasm3_to_gate_sequence

class GateSequence:
    def __init__(self, n, name='qc'):            
        self._data = []
        self._num_qubits = n
        self.name = name

    def get_num_qubits(self):
        return self._num_qubits

    def update_name(self, name):
        self.name = name

    def get_name(self):
        return self.name

    def format_qubit_list(self, item):
        if isinstance(item, int):
            return [item]
        if isinstance(item, range):
            return list(item)
        if isinstance(item, list):
            item = [int(x) for x in item]
            return item
        if hasattr(item, 'tolist'):
            return item.tolist()
        else:
            raise ValueError(f"Unsupported type for qubit list: {type(item)}")

    def format_control_sequence_list(self, item, n):
        if isinstance(item, int):
            item = bin(item)[2:].zfill(n)
        if not item:
            item = [1] * n
        if isinstance(item, (str, list)):
            item = [int(x) for x in item]
        if len(item) != n:
            raise ValueError(f"control_sequence length must be equal to number of control qubits!")
        return item

    def update(self, id, target, control_sequence=[], control=[], parameter=None, block_gate_sequence=None, prepend=False, matrix=None, name=None):
        target = self.format_qubit_list(target)
        control = self.format_qubit_list(control)
        if max(target + control) >= self._num_qubits:
            raise ValueError("qubit index out of range!")
        if min(target + control) < 0:
            raise ValueError("qubit index must be non-negative!")
        if set(target) & set(control):
            raise ValueError("target and control qubits must be disjoint!")
        if len(set(target + control)) != len(target + control):
            raise ValueError("target and control qubits must be distinct!")

        if len(control) > 0:
            control_sequence = self.format_control_sequence_list(control_sequence, len(control))
        else:
            control_sequence = []
            
        if name is None:
            name = id.upper()

        new_gate = {"id": id, "control_sequence": control_sequence, "control": control, "target": target, "name": name}
        if parameter is not None:
            new_gate["parameter"] = parameter
        if block_gate_sequence is not None:
            new_gate["block_gate_sequence"] = block_gate_sequence
        if matrix is not None:
            new_gate["matrix"] = matrix
        self.add(new_gate, prepend=prepend)

    def multiTargetUpdate(self, id, target, control_sequence=[], control=[], parameter=None, name=None):
        if isinstance(target, int):
            target = [target]
        for tar in target:
            self.update(id, tar, control_sequence, control, parameter, name=name)

    def add(self, item, prepend=False):
        if not isinstance(item, dict):
            raise TypeError("item must be a dict")
        if prepend:
            self._data.insert(0, item)
        else:
            self._data.append(item)

    def prepend(self, block_gate_sequence, target, control=[], control_sequence=[]):
        name = 'qc'
        if isinstance(block_gate_sequence, GateSequence):
            if len(target) < block_gate_sequence.get_num_qubits():
                raise ValueError("target length must be equal to block_gate_sequence qubits length")
            name = block_gate_sequence.name
            block_gate_sequence = block_gate_sequence.data()
        self.update("zoom_in", target, control_sequence, control, block_gate_sequence=block_gate_sequence, prepend=True, name=name)

    def append(self, block_gate_sequence, target, control=[], control_sequence=[], prepend=False):
        name = 'qc'
        target = self.format_qubit_list(target)
        if isinstance(block_gate_sequence, GateSequence):
            if len(target) < block_gate_sequence.get_num_qubits():
                raise ValueError("target length must be equal to block_gate_sequence qubits length")
            name = block_gate_sequence.name
            block_gate_sequence = block_gate_sequence.data()
        self.update("zoom_in", target, control_sequence, control, block_gate_sequence=block_gate_sequence, prepend=prepend, name=name)

    def repeat(self, cnt):
        new = GateSequence(self._num_qubits, name=self.name + '**' + str(cnt))
        for i in range(cnt):
            new._data += self._data
        return new
    
    def reverse(self):
        n = self._num_qubits
        new = GateSequence(n, name='rev_' + self.name)
        new.append(self._data, range(n-1, -1, -1))
        return new

    def x(self, target):
        self.multiTargetUpdate("x", target)

    def y(self, target):
        self.multiTargetUpdate("y", target)
    
    def z(self, target):
        self.multiTargetUpdate("z", target)
    
    def h(self, target):
        self.multiTargetUpdate("h", target)
    
    def s(self, target):
        self.multiTargetUpdate("s", target)

    def sdag(self, target):
        self.multiTargetUpdate("sdag", target)

    def t(self, target):
        self.multiTargetUpdate("t", target)

    def tdag(self, target):
        self.multiTargetUpdate("tdag", target)

    def sqrtx(self, target):
        self.multiTargetUpdate("sqrtx", target)

    def sqrtxdag(self, target):
        self.multiTargetUpdate("sqrtxdag", target)

    def sqrty(self, target):
        self.multiTargetUpdate("sqrty", target)

    def sqrtydag(self, target):
        self.multiTargetUpdate("sqrtydag", target)

    def i(self, target):
        self.multiTargetUpdate("i", target)

    def sw(self, target1, target2):
        self.update("swap", [target1, target2])
    
    def swap(self, target1, target2):
        """SWAP门的别名方法"""
        return self.sw(target1, target2)

    def p(self, parameter, target):
        self.multiTargetUpdate("phase_gate", target, parameter=parameter, name='P')

    def gp(self, parameter):
        self.multiTargetUpdate("global_phase", 0, parameter=parameter, name='GP')

    def t(self, target):
        self.multiTargetUpdate("t", target)

    def rx(self, parameter, target):
        self.multiTargetUpdate("rx", target, parameter=parameter)
    
    def ry(self, parameter, target):
        self.multiTargetUpdate("ry", target, parameter=parameter)

    def rz(self, parameter, target):
        self.multiTargetUpdate("rz", target, parameter=parameter)

    def u1(self, lambda_, target):
        self.update("u", target, parameter=[0, 0, lambda_])

    def u2(self, phi, lambda_, target):
        self.update("u", target, parameter=[0, phi, lambda_])

    def u3(self, theta, phi, lambda_, target):
        self.update("u", target, parameter=[theta, phi, lambda_])

    def ch(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("h", target, control_sequence=ctrl_state, control=control)

    def cs(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("s", target, control_sequence=ctrl_state, control=control)

    def cnot(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("x", target, control_sequence=ctrl_state, control=control)

    def cx(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("x", target, control_sequence=ctrl_state, control=control)

    def cy(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("y", target, control_sequence=ctrl_state, control=control)

    def cz(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("z", target, control_sequence=ctrl_state, control=control)

    def cp(self, parameter, control, target, ctrl_state=''):
        self.multiTargetUpdate("phase_gate", target, control_sequence=ctrl_state, control=control, parameter=parameter, name='P')

    def crx(self, parameter, control, target, ctrl_state=''):
        self.multiTargetUpdate("rx", target, control_sequence=ctrl_state, control=control, parameter=parameter)

    def cry(self, parameter, control, target, ctrl_state=''):
        self.multiTargetUpdate("ry", target, control_sequence=ctrl_state, control=control, parameter=parameter)
        
    def crz(self, parameter, control, target, ctrl_state=''):
        self.multiTargetUpdate("rz", target, control_sequence=ctrl_state, control=control, parameter=parameter)
        
    def mch(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("h", target, control_sequence=ctrl_state, control=control)

    def mcnot(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("x", target, control_sequence=ctrl_state, control=control)

    def mcx(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("x", target, control_sequence=ctrl_state, control=control)

    def mcy(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("y", target, control_sequence=ctrl_state, control=control)

    def mcz(self, control, target, ctrl_state=''):
        self.multiTargetUpdate("z", target, control_sequence=ctrl_state, control=control)

    def mcrx(self, parameter, control, target, ctrl_state=''):
        self.update("rx", target, control_sequence=ctrl_state, control=control, parameter=parameter)

    def mcry(self, parameter, control, target, ctrl_state=''):
        self.update("ry", target, control_sequence=ctrl_state, control=control, parameter=parameter)

    def mcrz(self, parameter, control, target, ctrl_state=''):
        self.update("rz", target, control_sequence=ctrl_state, control=control, parameter=parameter)

    def mcp(self, parameter, control, target, ctrl_state=''):
        self.update("phase_gate", target, control_sequence=ctrl_state, control=control, parameter=parameter, name='P')
    
    # 测量：在gs 中添加一个id 为measure 的gate
    def measure(self,target,cl_target):
        if isinstance(target, int):
            target=[target]
        if isinstance(cl_target, int):
            cl_target = [cl_target]
        self.update("measure",target,[],[],parameter=cl_target)
        # new_gate = {"id": 'measure', "control_sequence": [], "control": [], "target": target, "name": "measure",}
        # self.add(new_gate)

    # Since the qubit order is reversed in torch backend, we need to reverse the target qubits
    def unitary(self, matrix, target, control=[], ctrl_state='', name='U'):
        if isinstance(target, int):
            target = [target]
        self.update("unitary", target[::-1], matrix=matrix, control=control, control_sequence=ctrl_state, name=name)

    def control(self, num_ctrl_qubits=1, ctrl_state=''):
        new = GateSequence(self._num_qubits+num_ctrl_qubits, name='ctrl_' + self.name)
        new.append(self._data, target=range(self._num_qubits), control=range(self._num_qubits, self._num_qubits + num_ctrl_qubits), control_sequence=ctrl_state)
        return new

    def dagger(self):
        new = GateSequence(self._num_qubits, name='dag_' + self.name)
        new._data = dagger(self._data)
        return new

    def inverse(self):
        new = GateSequence(self._num_qubits, name='inv_' + self.name)
        new._data = dagger(self._data)
        return new

    def data(self):
        return self._data

    def execute(self, initial_state):
        """Execute a quantum circuit

        Parameters:

        initial_state: Initial quantum state (optional)

        Return:

        Final quantum state
        """
        from .EXECUTE import execute_result
        return execute_result(self.reverse().data(), initial_state)
    
    def copy(self):
        """Copy the current GateSequence object

        Returns:

        A new GateSequence object with the same content as the current object.
        """
        new_gs = GateSequence(self._num_qubits, name=self.name)
        new_gs._data = self._data.copy()
        return new_gs

    def decompose_once(self):
        """Decompose the quantum circuit into a sequence of basic gates.

        Returns:

        The decomposed GateSequence object
        """
        new_gs = GateSequence(self._num_qubits, name=self.name)
        for i in self._data:
            if ('block_gate_sequence' in i) and (i['block_gate_sequence']):
                for gate in i['block_gate_sequence']:
                    new_target = [i['target'][t] for t in gate['target']]
                    new_control = i['control'] + [i['target'][c] for c in gate['control']]
                    new_control_sequence = i['control_sequence'] + gate['control_sequence']
                    new_gs.update(gate['id'], new_target, control=new_control, control_sequence=new_control_sequence, parameter=gate.get('parameter', None), block_gate_sequence=gate.get('block_gate_sequence', None), name=gate.get('name', None))
            else:
                new_gs.add(i)
        return new_gs

    def decompose(self, n=1):
        """Decompose the quantum circuit into a sequence of basic gates.

        Returns:

        The decomposed GateSequence object
        """
        new_gs = self.copy()
        for i in range(n):
            new_gs = new_gs.decompose_once()
        return new_gs

    def to_openqasm(self):
        qasm = gate_sequence_to_openqasm3(self._data)
        return qasm

    def from_openqasm(self, qasm):
        self._data = openqasm3_to_gate_sequence(qasm)