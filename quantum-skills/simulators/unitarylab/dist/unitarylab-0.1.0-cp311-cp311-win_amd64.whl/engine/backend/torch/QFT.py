import numpy as np
from .fundamental_gates_functions import dagger
from .transfer_sequence import GateSequence

def QFT(n, reverse=False):
    """
    Quantum Fourier Transform
    :param n: Number of qubits
    :return: gate_sequence of QFT
    """
    gs = GateSequence()
    for i in range(n):
        gs.h(i)
        for j in range(i + 1, n):
            gs.mcp(np.pi/2**(j - i), j, i)

    if n % 2 == 0:
        for i in range(n//2):
            gs.swap([i, n - 1 - i])
    else:
        for i in range(int(n/2)):
            gs.swap([i, n - 1 - i])
    if reverse:
        gs = gs.reverse(n)
    return gs


def IQFT(n, reverse=False):
    """
    Inverse Quantum Fourier Transform
    :param n: Number of qubits
    :return: gate_sequence of IQFT
    """
    return QFT(n, reverse=reverse).dagger()