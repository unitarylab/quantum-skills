# from venv import create
# import copy
import time
import numpy as np
import torch
from .config_manager import DeviceManager, DatetypeManager
from .fundamental_gates_unitary import gate_names

#To make sure the functions is executed in GPU or CPU
device_manager = DeviceManager()
device = device_manager.get_device()
# Set the datetype
datetype_manager = DatetypeManager()
datetype = datetype_manager.get_datetype()
# def control_one_qubit_rotation(n, quantum_state, gate_unitary, control_indices, control_sequence, target_index):
#     """
#     :param n: the number of qubits
#     :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
#     :param gate_unitary: one-qubit gate in unitary matrix form, it should be a 2*2 unitary torch matrix
#     :param control_indices: the indices of the control qubits, it should be a list
#     :param control_sequence: the control state sequence, it should be a list
#     :param target_index: the index of the target qubit, it should be an integer number
#     :return:
#     """
#     n_control = len(control_indices) #The number of the control qubit
#     if n_control > 0:
#         quantum_state = quantum_state.reshape([2 for i in range(n)])

#         #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
#         permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
#         inverse_permutation=tuple(np.argsort(np.array(permutation)))

#         quantum_state = quantum_state.permute(permutation)
#         #apply unitary
#         vec_0=gate_unitary[0,0] * quantum_state[tuple(control_sequence)][0] + gate_unitary[0,1] * quantum_state[tuple(control_sequence)][1]
#         quantum_state[tuple(control_sequence)][1]=(gate_unitary[1,0] * quantum_state[tuple(control_sequence)][0] +
#                                                    gate_unitary[1,1] * quantum_state[tuple(control_sequence)][1])
#         quantum_state[tuple(control_sequence)][0]=vec_0
#         quantum_state = quantum_state.permute(inverse_permutation)
#         return quantum_state
#     return one_qubit_rotation(n, quantum_state, gate_unitary, target_index)
# def one_qubit_rotation(n, quantum_state, gate_unitary, target_index):
#     """
#     :param n: the number of qubits
#     :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
#     :param gate_unitary: one-qubit gate in unitary matrix form, it should be a 2*2 unitary torch matrix
#     :param target_index: the index of the target qubit, it should be an int number
#     :return: output quantum state
#     """
#     if n > 1:
#         t1 = quantum_state.reshape([2 for i in range(n)])
#         transposed_tensor = t1.transpose(0, target_index)
#         target_tensor0 = gate_unitary[0,0] * transposed_tensor[0,:] + gate_unitary[0,1] * transposed_tensor[1,:]
#         target_tensor1 = gate_unitary[1,0] * transposed_tensor[0,:] + gate_unitary[1,1] * transposed_tensor[1,:]
#         aux_tensor = torch.stack([target_tensor0, target_tensor1], dim=0)
#         result_tensor = aux_tensor.transpose(0, target_index)
#     else:
#         result_tensor = gate_unitary @ quantum_state
#     return result_tensor
def control_one_qubit_rotation(n, quantum_state, gate_unitary, control_indices, control_sequence, target_index):
    """
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param gate_unitary: one-qubit gate in unitary matrix form, it should be a 2*2 unitary torch matrix
    :param control_indices: the indices of the control qubits, it should be a list
    :param control_sequence: the control state sequence, it should be a list
    :param target_index: the index of the target qubit, it should be an integer number
    :return:
    """
    # reshape state by qubit sequence
    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    # inverse_permutation=tuple(np.argsort(np.array(permutation)))
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    # permute quantum state based on qubit sequence
    quantum_state = quantum_state.permute(permutation)

    # choose quantum state by control_sequence
    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    # apply gate to sub-state
    mid_result = gate_unitary @ sub_quantum_state.reshape(2,-1)
    sub_quantum_state.copy_(mid_result.reshape(sub_quantum_state.shape))

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def measure(n, quantum_state, target_indices,endian='big'):
    """
    The measurement function has the same logic as the measurement function in qiskit.
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param target_indices: the target qubit, it can be a integer number or a list
    return: new_state,sample_bin(Binary representation of the measurement result)
    """
    if isinstance(target_indices, int):
        target_indices = [target_indices]

    target_number = len(target_indices)
    if endian=='big':
        target_axes = target_indices.copy()
    elif endian=='little' or endian =='small':
        target_axes = [(n - 1) - i for i in target_indices]
    
    all_axes = list(range(n))
    remaining_axes = [ax for ax in all_axes if ax not in target_axes]
    permutation = tuple(target_axes + remaining_axes)

    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i
    inverse_permutation = tuple(inverse_permutation)

    quantum_state = quantum_state.view([2] * n)
    quantum_state = quantum_state.permute(permutation)
    quantum_state = quantum_state.reshape(2 ** target_number, -1)

    measure_probability = torch.norm(quantum_state, dim=1) ** 2
    probs_np = measure_probability.cpu().detach().numpy()
    
    probs_sum = probs_np.sum()
    if probs_sum == 0:
        raise ValueError("State vector has zero norm.")
    probs_np = probs_np / probs_sum

    rng = np.random.default_rng()
    sample = int(rng.choice(len(probs_np), size=1, p=probs_np)[0])

    collapsed_slice = quantum_state[sample]
    norm_factor = torch.linalg.norm(collapsed_slice)
    normalized_slice = collapsed_slice / norm_factor

    new_state = torch.zeros_like(quantum_state)
    new_state[sample] = normalized_slice

    new_state = new_state.view([2] * n)
    new_state = new_state.permute(inverse_permutation)
    new_state = new_state.reshape(-1)

    sample_bin = f"{sample:0{target_number}b}"
    sample_bin=sample_bin[::-1]
    return new_state, sample_bin


def one_qubit_rotation_broadcast(n, quantum_state, gate_unitary, target_index):
    """
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param gate_unitary: one-qubit gate in unitary matrix form, it should be a 2*2 unitary torch matrix
    :param target_index: the index of the target qubit, it should be an int number
    :return: output quantum state
    """
    quantum_state = quantum_state.reshape([2 for i in range(n)])
    quantum_state = quantum_state.transpose(n - 2, target_index)
    quantum_state = gate_unitary @ quantum_state
    quantum_state = quantum_state.transpose(n - 2, target_index)
    return quantum_state


def control_one_qubit_H_special(n, quantum_state, control_indices: list, control_sequence, target_index):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    
    a0 = sub_quantum_state[0]
    a1 = sub_quantum_state[1]

    INV_SQRT2 = 0.7071067811865476
    old_a0 = a0.clone()
    a0.add_(a1).mul_(INV_SQRT2)
    a1.neg_().add_(old_a0).mul_(INV_SQRT2)


    # v0 = sub_quantum_state[0].clone()
    # v1 = sub_quantum_state[1].clone()

    # sub_quantum_state[0] = (v0 + v1) * 2**-0.5
    # sub_quantum_state[1] = (v0 - v1) * 2**-0.5

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_X_special(n, quantum_state, control_indices: list, control_sequence, target_index):
    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    v0 = sub_quantum_state[0].clone()
    sub_quantum_state[0].copy_(sub_quantum_state[1])
    sub_quantum_state[1].copy_(v0)
    
    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_Y_special(n, quantum_state, control_indices: list, control_sequence, target_index):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    v0 = sub_quantum_state[0].clone()
    sub_quantum_state[0].copy_((-1j) * sub_quantum_state[1])
    sub_quantum_state[1].copy_(1j * v0)
    
    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_Z_special(n, quantum_state, control_indices: list, control_sequence, target_index):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    sub_quantum_state[1].mul_(-1)

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_S_special(n, quantum_state, control_indices: list, control_sequence, target_index):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    sub_quantum_state[1].mul_(1j)

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_S_dag_special(n, quantum_state, control_indices: list, control_sequence, target_index):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    sub_quantum_state[1].mul_(-1j)

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state

def control_one_qubit_phase(n, quantum_state, control_indices: list, control_sequence, target_index, parameter):

    quantum_state = quantum_state.reshape([2]*n)

    #permute the order of the quantum qubits, it will become: control qubits, target qubit, the rest of the qubits
    permutation=tuple(control_indices + [target_index] + [i for i in range(n) if i not in control_indices + [target_index]])
    
    inverse_permutation = [0] * n
    for i, p in enumerate(permutation):
        inverse_permutation[p] = i

    quantum_state = quantum_state.permute(permutation)

    sub_quantum_state = quantum_state
    for i in control_sequence:
        sub_quantum_state = sub_quantum_state.select(0, int(i))
    
    sub_quantum_state[1].mul_(torch.exp(torch.tensor(1j * parameter)))

    #permute back
    quantum_state = quantum_state.permute(inverse_permutation).reshape(-1)

    return quantum_state




def swap(n, quantum_state, target_index1, target_index2):
    """
    This function swap two quantum qubits
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param target_index1: target index 1
    :param target_index2: target index 2
    :return: out put quantum state
    """
    #n = int(np.log2(len(quantum_state.reshape(-1, 1))))
    return quantum_state.reshape([2 for i in range(n)]).transpose(target_index1,target_index2)

def create_qubit(quantum_state):
    """
    This function create a new qubit with state |0> and put it at the end of all the qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :return: output quantum state
    """
    return torch.kron(quantum_state,torch.tensor([1,0], dtype=datetype, device=device))

def create_name_for_ancilla():
    """
    This function create names for the pure ancilla
    :return: A list containing the names of the pure ancilla
    """
    name=str(time.time())
    time.sleep(0.000001)#wait 1 mcs
    return name

def kill_qubit(n, quantum_state, index):
    """
    This function kill the qubit whose index is 'index', note that The qubit is only allowed to be killed when it is in the |0> state
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param index: the index of the qubit which should be killed.
    :return: output quantum state
    """
    #n = int(np.log2(len(quantum_state.reshape(-1,1))))
    tens = quantum_state.reshape([2 for i in range(n)])
    #if  sum(tens.permute(tuple([index] + list(range(index)) + list(range(index + 1, n))))[1].reshape(-1)) != 0:
        #raise ValueError("The qubit is not in the |0> state, the kill_qubit operation cannot be performed.")
    return tens.permute(tuple([index] + list(range(index)) + list(range(index + 1, n))))[0]

def kill_nonzero_qubit(n, quantum_state, indices):
    """
    This function kill the qubit whose index is 'index', note that this function can kill qubits the state of which is not |0>
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param indices: the indices of the qubits which should be killed.
    :return: output quantum state
    """
    if isinstance(indices, int):
        indices = [indices]
    #n = int(np.log2(len(quantum_state.reshape(-1,1))))
    if len(indices) == n:
        raise ValueError("The number of the qubits been killed should be less than the total number of qubits.")
    tens = quantum_state.reshape([2 for _ in range(n)])
    temp = tens.permute(tuple(indices + [x for x in range(n) if x not in indices]))[tuple([0] * len(indices))]
    return temp/torch.sqrt(torch.sum(temp ** 2))



def zoom_in_permutation(n, quantum_state, target_indices, control_indices):
    """
    This function acts zoom_in operation on gate_sequence
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param target_indices:
    :param control_indices:
    :return: output quantum state
    """
    permutation = tuple(control_indices + target_indices + [i for i in range(n) if i not in control_indices + target_indices])
    return quantum_state.reshape([2 for i in range(n)]).permute(permutation).reshape(-1,1)
    # return permutation

def zoom_out_permutation(n, quantum_state, target_indices, control_indices):
    """
    This function acts zoom_out operation on gate_sequence
    :param n: the number of qubits
    :param quantum_state: input quantum state, it should be a 2**n normalized torch vector
    :param target_indices:
    :param control_indices:
    :return: output quantum state
    """
    permutation = control_indices + target_indices + [i for i in range(n) if i not in control_indices + target_indices]
    inverse_permutation = tuple(np.argsort(np.array(permutation)))
    return quantum_state.reshape([2 for i in range(n)]).permute(inverse_permutation).reshape(-1,1)
    # return inverse_permutation


def ancilla_expand(initial, n, k, num):#k is position index
    tens = initial.reshape([2 for i in range(n)])
    new_dim = [2 for i in range(n + num)]
    expanded = torch.zeros(new_dim)
    expanded[(slice(None),) * k + (0,) *  num + (slice(None),) * (n-k)] = tens.clone()
    return expanded


def ancilla_kill_old_version(initial, n, k, num):
    tens = initial.reshape([2 for i in range(n)])
    return tens[(slice(None),) * k + (0,) * num + (slice(None),) * (n-k-num)]


def dagger(gate_sequence):
    gate_sequence_dagger = []
    for gate in reversed(gate_sequence):
        name = gate.get('id')
        parameter = gate.get('parameter', None)
        target = gate.get('target', [])
        control_indices = gate.get('control', [])
        control_sequence = gate.get('control_sequence', [])
        block_gate_sequence = gate.get('block_gate_sequence', None)
        matrix = gate.get('matrix', None)

        dagger_gate = {}
        # renew name
        if name == 'create_ancilla':
            dagger_gate['id'] = 'kill_ancilla'
        elif name == 'kill_ancilla':
            dagger_gate['id'] = 'create_ancilla'
        elif name == 's':
            dagger_gate['id'] = 's_dagger'
        elif name == 's_dagger':
            dagger_gate['id'] = 's'
        else:
            dagger_gate['id'] = name
        # renew parameter
        if parameter is not None:
            if name.lower() == 'ry' or name.lower() == 'rz' or name.lower() == 'rx' or name.lower() == 'phase_gate' or name.lower() == 'global_phase':
                dagger_gate['parameter'] = -parameter
            elif name.lower() == 'u':
                dagger_gate['parameter'] = [-parameter[0], -parameter[2], -parameter[1]]
            else:
                dagger_gate['parameter'] = parameter
        if matrix is not None:
            dagger_gate['matrix'] = np.matrix(matrix).getH()

        # renew target
        if target is not []:
            dagger_gate['target'] = target
        # renew control
        if control_indices is not []:
            dagger_gate['control'] = control_indices
        # renew control_sequence
        if control_sequence is not []:
            dagger_gate['control_sequence'] = control_sequence
        # renew block_gate_sequence
        if block_gate_sequence is not None:
            dagger_gate['block_gate_sequence'] = dagger(block_gate_sequence)

        gate_sequence_dagger.append(dagger_gate)
    return gate_sequence_dagger

def create_quantum_state(n, i):
    """
    This function creates a quantum state with n qubits in state |i>
    :param n: The number of qubits
    :param i: The quantum state |i>
    :return: output quantum state
    """
    quantum_state = torch.zeros(2 ** n, dtype=datetype, device=device)
    quantum_state[i] = torch.tensor(1, dtype=datetype, device=device)
    return quantum_state

def gate_number_counting(gate_sequence):
    one_qubit_gate = 0
    control_one_qubit_gate = 0
    for gate in gate_sequence:
        name = gate.get('id')
        control_indices = gate.get('control', [])
        block_gate_sequence = gate.get('block_gate_sequence', None)
        if name == 'zoom_in':
            one_qubit_gate_inside, control_one_qubit_gate_inside = gate_number_counting(block_gate_sequence)
            if len(control_indices) != 0:
                control_one_qubit_gate += one_qubit_gate_inside
                control_one_qubit_gate += control_one_qubit_gate_inside
            else:
                one_qubit_gate += one_qubit_gate_inside
                control_one_qubit_gate += control_one_qubit_gate_inside
        elif name.lower() in gate_names:
            if len(control_indices) != 0:
                control_one_qubit_gate += 1
            else:
                one_qubit_gate += 1
    return one_qubit_gate, control_one_qubit_gate
