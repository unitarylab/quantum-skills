"""
Quantum gate definitions for the simulation backend.

"""

import torch
import numpy as np
from .config_manager import DeviceManager, DatetypeManager


"""
Ensure gates are created on the correct computing device (GPU or CPU).

"""
device_manager = DeviceManager()
device = device_manager.get_device()
device = 'cpu'

"""
Set the default tensor datatype used for quantum gates.

"""
datetype_manager = DatetypeManager()
datetype = datetype_manager.get_datetype()

def rx(parameter):
    """
    Generate the RX rotation gate matrix.
    """
    theta = torch.as_tensor(parameter, dtype=torch.float64, device=device) / 2
    return torch.stack([
        torch.stack([torch.cos(theta), -1j * torch.sin(theta)]),
        torch.stack([-1j * torch.sin(theta), torch.cos(theta)])
    ]).to(datetype)

def ry(parameter):
    """
    Generate the RY rotation gate matrix.
    """
    theta = torch.as_tensor(parameter, dtype=torch.float64, device=device) / 2
    return torch.stack([
        torch.stack([torch.cos(theta), -torch.sin(theta)]),
        torch.stack([torch.sin(theta),  torch.cos(theta)])
    ]).to(datetype)

def rz(parameter):
    """
    Generate the RZ rotation gate matrix.
    """
    theta = torch.as_tensor(parameter, dtype=torch.float64, device=device) / 2
    vals = torch.stack([
        torch.exp(-1j * theta),
        torch.exp( 1j * theta)
    ])
    return torch.diag(vals).to(datetype)

def phase_gate(parameter):
    """
    Generate the phase gate matrix.
    """
    phi = torch.as_tensor(parameter, dtype=torch.float64, device=device)

    vals = torch.stack([
        torch.ones((), dtype=torch.complex128, device=device),
        torch.exp(1j * phi)
    ])

    return torch.diag(vals).to(dtype=datetype, device=device)


def global_phase(parameter):
    """
    Generate a global phase gate.
    """
    phi = torch.as_tensor(parameter, dtype=torch.float64, device=device)
    phase = torch.exp(1j * phi)

    return (phase * torch.eye(2, dtype=datetype, device=device)).to(
        dtype=datetype, device=device
    )

def u(parameters):
    """
    Generate the general U gate matrix.
    """
    params = torch.as_tensor(parameters, dtype=torch.float64, device=device)

    m00 = torch.cos(params[0] / 2)
    m01 = -torch.exp(1j * params[2]) * torch.sin(params[0] / 2)
    m10 =  torch.exp(1j * params[1]) * torch.sin(params[0] / 2)
    m11 =  torch.exp(1j * (params[1] + params[2])) * torch.cos(params[0] / 2)

    return torch.stack([
        torch.stack([m00, m01]),
        torch.stack([m10, m11])
    ]).to(dtype=datetype, device=device)



"""
Predefined single-qubit quantum gate set.

All gates are represented as 2×2 unitary matrices (torch.Tensor).

Gate categories:
    - Pauli gates: X, Y, Z
    - Clifford gates: H, S, S†
    - Phase gates: T, T†
    - Identity: I
    - Square-root gates: √X, √Y
    - Parameterized gates: Rx, Ry, Rz, U, Phase

Notes:
    - dtype: complex tensor (datetype)
    - device: CPU / GPU
"""
gate_set = {
    # ===== Pauli Gates =====
    "x": torch.tensor([[0, 1], [1, 0]], dtype=datetype, device=device),
    "y": torch.tensor([[0, -1j], [1j, 0]], dtype=datetype, device=device),
    "z": torch.tensor([[1, 0], [0, -1]], dtype=datetype, device=device),
    "-z": torch.tensor([[-1, 0], [0, 1]], dtype=datetype, device=device),

     # ===== Clifford Gates =====
    "h": torch.tensor([[1, 1], [1, -1]], dtype=datetype, device=device) / (2 ** 0.5),

    "s": torch.tensor([[1, 0], [0, 1j]], dtype=datetype, device=device),
    "sdag": torch.tensor([[1, 0], [0, -1j]], dtype=datetype, device=device),
    "s_dagger": torch.tensor([[1, 0], [0, -1j]], dtype=datetype, device=device),

    # ===== Phase Gates =====
    "t": torch.tensor([[1, 0], [0, torch.exp(1j * torch.as_tensor(torch.pi / 4, dtype=torch.float64, device=device))]], dtype=datetype, device=device),
    "tdag": torch.tensor([[1, 0], [0, torch.exp(-1j * torch.as_tensor(torch.pi / 4, dtype=torch.float64, device=device))]], dtype=datetype, device=device),
     
    # ===== Identity =====
    "i": torch.tensor([[1, 0], [0, 1]], dtype=datetype, device=device),

    # ===== Square-root Gates =====
    "sqrtx": 0.5 * torch.tensor([[1+1j, 1-1j], [1-1j, 1+1j]], dtype=datetype, device=device),
    "sqrtxdag": 0.5 * torch.tensor([[1-1j, 1+1j], [1+1j, 1-1j]], dtype=datetype, device=device),

    "sqrty": 0.5 * torch.tensor([[1+1j, -1-1j], [1+1j, 1+1j]], dtype=datetype, device=device),
    "sqrtydag": 0.5 * torch.tensor([[1-1j, 1-1j], [-1+1j, 1-1j]], dtype=datetype, device=device),

    # ===== Parameterized Gates =====
    "rx": rx,
    "ry": ry,
    "rz": rz,
    "phase_gate": phase_gate,
    "global_phase": global_phase,
    "u": u
}


"""
List of supported gate names.

"""
gate_names = [
    'x', 'y', 'z', '-z', 'h',
    's', 'sdag', 's_dagger',
    't', 'tdag', 'i',
    'sqrtx', 'sqrtxdag', 'sqrty', 'sqrtydag',
    'rx', 'ry', 'rz', 'phase_gate', 'global_phase', 'u'
]