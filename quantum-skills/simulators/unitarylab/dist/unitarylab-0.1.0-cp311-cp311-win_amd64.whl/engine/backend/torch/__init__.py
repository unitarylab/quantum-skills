"""
Torch Backend Module
====================

This module contains the torch-based implementation of quantum algorithms and utilities.

Modules:
- transfer_sequence: Gate sequence manipulation tools
- fundamental_gates_functions: Fundamental quantum gate operations
- fundamental_gates_unitary: Unitary gate implementations
- fundamental_digital_functions: Basic digital function implementations
- QFT: Quantum Fourier Transform implementation
- EXECUTE: Main execution module
- config_manager: Configuration management utilities
"""

from .transfer_sequence import GateSequence as OriginalGateSequence

__all__ = [
    "OriginalGateSequence",
]