from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple
import math
import numbers

Gate = Dict[str, Any]


def gate_sequence_to_openqasm3(gate_sequence: List[Gate], qreg_name: str = "q") -> str:
    """
    Convert a gate_sequence (list of dict gates) to OpenQASM 3.0 code.

    Updates per your conventions:
      1) 'parameter' is a single scalar (e.g., np.pi/7). (Lists/tuples still accepted where needed.)
      2) 'target' can be int OR list[int].
      3) 'control_sequence' can be list[int{0,1}] OR an int j representing |j> over len(control) bits.
         (We interpret j in MSB-first order: format(j, f"0{k}b") gives bits aligned with 'control' order.)
    """
    ctx = _QasmCtx()
    n_qubits = _max_index(gate_sequence) + 1
    if n_qubits <= 0:
        n_qubits = 1

    body_lines = _emit_sequence(
        gate_sequence,
        ctx=ctx,
        qsym=lambda i: f"{qreg_name}[{i}]",
        prefix_controls=[],
        prefix_control_seq=[],
        allow_gate_defs=True,
    )

    out: List[str] = []
    out.append("OPENQASM 3.0;")
    out.append('include "stdgates.inc";')
    out.append("")

    # gate definitions must appear before first use
    if ctx.gate_defs:
        out.extend(ctx.gate_defs)
        out.append("")

    out.append(f"qubit[{n_qubits}] {qreg_name};")
    out.append("")
    out.extend(body_lines)
    out.append("")

    return "\n".join(out)


# ------------------------ helpers ------------------------

@dataclass
class _QasmCtx:
    gate_defs: List[str] = field(default_factory=list)
    _counter: int = 0

    def new_gate_name(self, base: str = "block") -> str:
        name = f"{base}_{self._counter}"
        self._counter += 1
        return name


def _is_int(x: Any) -> bool:
    return isinstance(x, int) and not isinstance(x, bool)


def _as_int_list(x: Any) -> List[int]:
    """Accept int or list/tuple of ints; None -> []"""
    if x is None:
        return []
    if _is_int(x):
        return [x]
    if isinstance(x, (list, tuple)):
        out = []
        for v in x:
            if not _is_int(v):
                raise TypeError(f"Expected int in list, got {type(v)}: {v!r}")
            out.append(v)
        return out
    raise TypeError(f"Expected int or list[int], got {type(x)}: {x!r}")


def _iter_indices_from_sequence(seq: List[Gate]):
    for g in seq:
        for k in ("target", "control"):
            v = g.get(k, None)
            if _is_int(v):
                yield v
            elif isinstance(v, list):
                for item in v:
                    if _is_int(item):
                        yield item
        if g.get("id") == "zoom_in" and isinstance(g.get("block_gate_sequence"), list):
            yield from _iter_indices_from_sequence(g["block_gate_sequence"])


def _max_index(seq: List[Gate]) -> int:
    mx = -1
    for i in _iter_indices_from_sequence(seq):
        mx = max(mx, i)
    return mx


def _format_param(x: Any) -> str:
    # allow strings like "pi/2" if you ever want them
    if isinstance(x, str):
        return x

    # accept numpy scalars and other numeric types
    if isinstance(x, numbers.Real) and not isinstance(x, bool):
        xf = float(x)
        if math.isfinite(xf):
            return format(xf, ".15g")
        return str(x)

    # last resort: something float-castable (e.g., numpy scalar)
    try:
        xf = float(x)
        if math.isfinite(xf):
            return format(xf, ".15g")
        return str(x)
    except Exception as e:
        raise TypeError(f"Unsupported parameter type: {type(x)}: {x!r}") from e


def _format_param_list(params: Any, expected_len: Optional[int] = None) -> str:
    """
    - For expected_len == 1: accept scalar OR [scalar].
    - For expected_len > 1: accept list/tuple of that length, or dict (for 'u').
    """
    if params is None:
        if expected_len is None:
            return ""
        raise ValueError("Missing parameters")

    # dict-style parameters for 'u'
    if isinstance(params, dict):
        keys = ["theta", "phi", "lambda", "lam"]
        ordered = [params[k] for k in keys if k in params]
        if expected_len is not None and len(ordered) != expected_len:
            raise ValueError(f"Expected {expected_len} parameters, got {len(ordered)}: {ordered}")
        return ", ".join(_format_param(p) for p in ordered)

    if isinstance(params, (list, tuple)):
        if expected_len is not None and len(params) != expected_len:
            raise ValueError(f"Expected {expected_len} parameters, got {len(params)}: {params}")
        return ", ".join(_format_param(p) for p in params)

    # scalar
    if expected_len is not None and expected_len != 1:
        raise ValueError(f"Expected {expected_len} parameters, got scalar: {params}")
    return _format_param(params)


def _normalize_control_sequence(control_sequence: Any, k: int) -> List[int]:
    """
    control_sequence can be:
      - None: defaults to all-ones (standard control)
      - list/tuple of 0/1 with length k
      - int j representing |j> on k bits, MSB-first (aligned with 'control' list order)
    """
    if k == 0:
        return []
    if control_sequence is None:
        return [1] * k

    if _is_int(control_sequence):
        j = int(control_sequence)
        if j < 0 or j >= (1 << k):
            raise ValueError(f"control_sequence int {j} out of range for {k} controls (0..{(1<<k)-1})")
        bits = format(j, f"0{k}b")  # MSB-first
        return [0 if ch == "0" else 1 for ch in bits]

    if isinstance(control_sequence, (list, tuple)):
        if len(control_sequence) != k:
            raise ValueError(f"control_sequence length {len(control_sequence)} != number of controls {k}")
        out: List[int] = []
        for b in control_sequence:
            if b not in (0, 1):
                raise ValueError(f"control_sequence must contain only 0/1, got {b!r}")
            out.append(int(b))
        return out

    raise TypeError(f"Unsupported control_sequence type: {type(control_sequence)}")


def _merge_controls(
    prefix_controls: List[int],
    prefix_seq: List[int],
    inner_controls: List[int],
    inner_seq_raw: Any,
) -> Tuple[List[int], List[int]]:
    inner_seq = _normalize_control_sequence(inner_seq_raw, len(inner_controls)) if inner_controls else []
    return prefix_controls + inner_controls, prefix_seq + inner_seq


def _modifiers_from_controls(controls: List[int], control_seq: List[int]) -> List[str]:
    if len(controls) != len(control_seq):
        raise ValueError(f"control and control_sequence length mismatch: {len(controls)} vs {len(control_seq)}")
    return ["ctrl" if b == 1 else "negctrl" for b in control_seq]


def _emit_gate_line(gate_name: str, params: Optional[str], qubit_args: List[str], modifiers: List[str]) -> str:
    mod = "".join(f"{m} @ " for m in modifiers)
    if params:
        return f"{mod}{gate_name}({params}) {', '.join(qubit_args)};"
    return f"{mod}{gate_name} {', '.join(qubit_args)};"


def _emit_gphase_line(params: str, modifiers: List[str], qubit_args: List[str]) -> str:
    mod = "".join(f"{m} @ " for m in modifiers)
    if not modifiers:
        return f"gphase({params});"
    if not qubit_args:
        raise ValueError("Controlled gphase requires at least one qubit operand (the control qubit(s)).")
    return f"{mod}gphase({params}) {', '.join(qubit_args)};"


def _sequence_is_local(block_seq: List[Gate], arity: int) -> bool:
    for idx in _iter_indices_from_sequence(block_seq):
        if idx < 0 or idx >= arity:
            return False
    return True


def _emit_sequence(
    seq: List[Gate],
    ctx: _QasmCtx,
    qsym: Callable[[int], str],
    prefix_controls: List[int],
    prefix_control_seq: List[int],
    allow_gate_defs: bool,
) -> List[str]:
    lines: List[str] = []

    for g in seq:
        name = g.get("id")

        targets: List[int] = _as_int_list(g.get("target"))
        inner_controls: List[int] = _as_int_list(g.get("control"))
        inner_seq_raw = g.get("control_sequence", None)

        controls, cseq = _merge_controls(prefix_controls, prefix_control_seq, inner_controls, inner_seq_raw)
        mods = _modifiers_from_controls(controls, cseq) if controls else []

        # ---------- zoom_in ----------
        if name == "zoom_in":
            block_seq = g.get("block_gate_sequence")
            if not isinstance(block_seq, list):
                raise ValueError("zoom_in gate requires 'block_gate_sequence' as a list")
            arity = len(targets)
            if arity == 0:
                raise ValueError("zoom_in gate requires non-empty 'target' (int or list[int])")

            if allow_gate_defs and _sequence_is_local(block_seq, arity):
                gate_id = ctx.new_gate_name("block")
                local_names = [f"a{i}" for i in range(arity)]
                def_qsym = lambda i, ln=local_names: ln[i]

                body_lines = _emit_sequence(
                    block_seq, ctx, def_qsym,
                    prefix_controls=[], prefix_control_seq=[],
                    allow_gate_defs=True,
                )

                gate_def_lines = [f"gate {gate_id} " + ", ".join(local_names) + " {"]
                gate_def_lines += [f"  {ln}" for ln in body_lines]
                gate_def_lines.append("}")
                ctx.gate_defs.append("\n".join(gate_def_lines))

                qubits = [qsym(i) for i in controls + targets]
                lines.append(_emit_gate_line(gate_id, None, qubits, mods))
            else:
                # inline: propagate outer controls to each inner gate
                lines += _emit_sequence(
                    block_seq, ctx, qsym,
                    prefix_controls=controls, prefix_control_seq=cseq,
                    allow_gate_defs=allow_gate_defs,
                )
            continue

        # ---------- helpers ----------
        def apply_single_qubit(op_name: str, param_str: Optional[str] = None) -> List[str]:
            if not targets:
                raise ValueError(f"Gate '{name}' requires a target")
            out: List[str] = []
            for t in targets:
                qubits = [qsym(i) for i in controls + [t]]
                out.append(_emit_gate_line(op_name, param_str, qubits, mods))
            return out

        def apply_two_qubit(op_name: str) -> List[str]:
            if len(targets) < 2 or (len(targets) % 2 != 0):
                raise ValueError(f"Gate '{name}' expects an even-length target list (pairs), got {targets}")
            out: List[str] = []
            for a, b in zip(targets[0::2], targets[1::2]):
                qubits = [qsym(i) for i in controls + [a, b]]
                out.append(_emit_gate_line(op_name, None, qubits, mods))
            return out

        # ---------- primitive gates ----------
        if name in ("x", "y", "z", "h", "s"):
            lines += apply_single_qubit(name)

        elif name == "s_dagger":
            lines += apply_single_qubit("sdg")

        elif name == "rx":
            p = _format_param_list(g.get("parameter"), expected_len=1)  # scalar ok
            lines += apply_single_qubit("rx", p)

        elif name == "ry":
            p = _format_param_list(g.get("parameter"), expected_len=1)  # scalar ok
            lines += apply_single_qubit("ry", p)

        elif name == "rz":
            p = _format_param_list(g.get("parameter"), expected_len=1)  # scalar ok
            lines += apply_single_qubit("rz", p)

        elif name == "phase_gate":
            p = _format_param_list(g.get("parameter"), expected_len=1)  # scalar ok
            lines += apply_single_qubit("p", p)

        elif name == "u":
            # U(theta, phi, lambda)
            p = _format_param_list(g.get("parameter"), expected_len=3)
            lines += apply_single_qubit("U", p)

        elif name == "swap":
            lines += apply_two_qubit("swap")

        elif name == "global_phase":
            p = _format_param_list(g.get("parameter"), expected_len=1)  # scalar ok
            qubits = [qsym(i) for i in controls]  # only controls are operands when controlled
            lines.append(_emit_gphase_line(p, mods, qubits))

        elif name == "-z":
            # Implement (-Z) as gphase(pi) then z (per target)
            if not targets:
                raise ValueError("Gate '-z' requires target")
            for t in targets:
                qubits_phase = [qsym(i) for i in controls]
                lines.append(_emit_gphase_line(_format_param(math.pi), mods, qubits_phase))
                qubits_z = [qsym(i) for i in controls + [t]]
                lines.append(_emit_gate_line("z", None, qubits_z, mods))

        else:
            raise NotImplementedError(f"Unsupported gate name: {name!r}")

    return lines
