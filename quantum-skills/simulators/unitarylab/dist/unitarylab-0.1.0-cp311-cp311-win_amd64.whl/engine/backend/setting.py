import importlib

BACKEND = 'torch'
FALLBACK_FLAG = False
_DEFAULT_BACKENDS = ['unitarylab', 'torch']

def set_backend(backend: str = 'torch'):
    if backend not in _DEFAULT_BACKENDS:
        raise ValueError(f"Invalid backend '{backend}'. Supported backends are: {_DEFAULT_BACKENDS}")

    global BACKEND
    BACKEND = backend

def get_backend():
    return BACKEND

def get_backend_gate_sequence():
    """
    The corresponding GateSequence class is dynamically loaded based on the backend name.

    If no backend_name is provided, it will attempt to determine it from environment variables and the default list.

    When this function is called, OriginalGateSequence is globally imported.
    """
    # 如果未提供 backend_name，则从全局变量中获取
    backend_name = BACKEND
        
    try:
        _backend_module = importlib.import_module(f'engine.backend.{backend_name}')
        OriginalGateSequence = getattr(_backend_module, 'OriginalGateSequence')
    except (ImportError, AttributeError):
        if backend_name == 'torch':
            raise ImportError(f"Failed to import backend '{backend_name}'")

        global FALLBACK_FLAG
        if not FALLBACK_FLAG:
            print(f"Warning: Failed to import backend '{backend_name}'. Falling back to 'torch' backend.")
            set_backend('torch')
            FALLBACK_FLAG = True
        OriginalGateSequence = get_backend_gate_sequence()
    
    return OriginalGateSequence
