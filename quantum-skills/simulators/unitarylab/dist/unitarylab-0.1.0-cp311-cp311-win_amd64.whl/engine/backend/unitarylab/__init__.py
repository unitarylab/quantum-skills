"""
UnitaryLab Backend Module
==========================

This module contains the unitarylab-based implementation of quantum algorithms and utilities.
"""

from unitarylab import GateSequence as OriginalGateSequence

__all__ = [
    "OriginalGateSequence"
]