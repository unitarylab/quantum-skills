"""
Backend Module
==============

This module provides backend implementations for quantum computing:
- torch: PyTorch-based backend implementation
- unitarylab: UnitaryLab-based backend implementation
"""

from .setting import get_backend, set_backend, get_backend_gate_sequence

__all__ = [
    "set_backend",
    "get_backend_gate_sequence",
    "get_backend",
]