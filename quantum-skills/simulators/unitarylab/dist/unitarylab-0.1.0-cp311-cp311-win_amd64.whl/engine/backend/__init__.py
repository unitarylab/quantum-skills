"""
Backend Module
==============

This module provides backend implementations for quantum computing:
- torch: PyTorch-based backend implementation
- unitarylab: UnitaryLab-based backend implementation
"""
