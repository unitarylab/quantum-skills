# 终端输出的计算信息

def info_run_time(start_time, end_time):
    print(TIME_CIRCUIT_EXECUATION)
    run_time = end_time - start_time
    # print in hour-min-second format
    hours, rem = divmod(run_time, 3600)
    minutes, seconds = divmod(rem, 60)
    print(f"{int(hours)}h {int(minutes)}m {seconds:.2f}s")

START_CALCULATION = "Start calculation ..."
START_CALCULATION_FULLTIME = "Start calculation with each time step. This may take a while ..."
START_PLOT_ANIMATION = "Start creating the animation ..."

START_PARSE_PARAMETERS = "Start parsing parameters ..."

START_QSP_PHASE_FACTOR_SOLVER = "Start calculating QSP phase-factors ..."

START_CONSTRUCT_CIRCUIT = "Start constructing the quantum circuit of the differential operator ..."
START_CONSTRUCT_MATRIX = "Start constructing the matrix ..."

START_PLOT_SOLUTION = "Start plotting the solution ..."
START_PLOT_CIRCUIT = "Start plotting the quantum circuit ..."

COMPLETE = "Complete"

INFO_DEVICE_GPU = "Using GPU device for calculation."
INFO_DEVICE_CPU = "Using CPU device for calculation."
INFO_NO_SCHRODINGERIZATION = "No need to apply Schrödingerization with the current parameters."
TIME_CIRCUIT_EXECUATION = "Time for quantum circuit execution: "
INFO_SUGGESTED_RECOVER_POINT = "Suggested recover point: "

WARNING_NX_NA_TOO_LARGE = "Warning: The number of qubits is large! Reduce qubit usage to avoid prolonged computation time or out of memory!"
WARNING_CUSTOM_ALGORITHM = "Warning: Loading default algorithms failed! Trying to load custom algorithms!"

ERROR_STOPPED = "Computation stopped by user"
ERROR_MATRIX_ZERO = "ERROR: The matrix is zero! Please check the input parameters."
ERROR_MATRIX_NOT_SQUARE = "ERROR: The matrix is not square! Please check the construction of matrices."
ERROR_DIMENSION_MISMATCH = "ERROR: The dimension of the vector does not match the matrix! Please check the construction of vectors and matrices."

ERROR_NX_NA_TOO_LARGE = "ERROR: The number of qubits is too large! Please use fewer qubits!"
ERROR_BLOCK_NOTSUPPORT = "ERROR: Block-encoding will be supported soon! Please select another method!"
ERROR_CUSTOM_ALGORITHM = "ERROR: Loading custom algorithm failed, please contact the administrator!"
ERROR_GENERAL_ALGORITHM = "ERROR: Running default algorithm failed, please contact the administrator!"
ERROR_BLOCK_SOURCE_SUPPORT = "ERROR: Invalid source term or non-zero boundaries detected! The block-encoding method will support these features soon!"
ERROR_CUSTOM_EQUATION_BLOCK_BOUNDARY = "ERROR: The points parameter must be one of 'periodic', or 'Dirichlet', or 'Neumann', or 'Robin'."
ERROR_CUSTOM_EQUATION_BLOCK_SCHEME = "ERROR: The scheme parameter must be one of 'central', 'forward Euler', or 'backward Euler'."
ERROR_CUSTOM_EQUATION_BLOCK_POINTS = "ERROR: The points parameter must be either 'two points' or 'four points'."

ERROR_PARAMETER_TYPE = "Invalid parameter type! Expected an int or a list of ints:"
ERROR_PARAMETER_TYPE_FLOAT = "Invalid parameter type! Expected a float or an int:"

ERROR_PARSE_FUNCTION = "ERROR: Invalid function expression! Please check if there is any missing parameters."

ERROR_PARSE_DERIVATIVE = "ERROR: Invalid derivative expression! Please check $.hamiltonian.derivative in custom JSON."
ERROR_CONSTANT_DERIVATIVE = "ERROR: Invalid derivative expression! Only support constant derivative now!"
ERROR_PARSE_DERIVATIVE_SOURCE = "ERROR: Invalid source term! For a functional source term, please define it as a custom function in the 'Equation parameter' section, and cite the function name in the derivative."
ERROR_PARSE_DERIVATIVE_INDEX = "ERROR: Invalid derivative index! Only 1-dimensional variables are supported. For such variables, the index must be 0, 1, or a string of 'x' (e.g., the string 'xx' denotes 'd_\{xx\}')."
ERROR_DERIVATIVE_ORDER = "ERROR: The high-order derivative is not supported. Specifically, the classical method and Lie-Trotter method support derivatives up to the 4th order, while the Block-encoding method supports derivatives up to the 2nd order."

ERROR_INITIAL_NOT_PROCESSED = "ERROR: Unable to process the initial condition automatically. Kindly check the setup."
ERROR_INITIAL_CONDITION = "ERROR: Invalid initial condition expression!"
ERROR_BOUNDARY_CONDITION = "ERROR: Unsupported boundary condition type!"
ERROR_SCHEME = "ERROR: Unsupported scheme type!"

INFO_RECOVER_FIXED = "For this equation, the recover point p and the length R are chosen automatically and the input values are ignored!"

INFO_EPSILON_SMALL = "ERROR: The small-scale ε should be smaller than the grid size dx!"

INFO_RECOVER_FAILED = "The recover point p is too large! Please contact the administrator!"