import time
import os
import numpy as np
from typing import Dict, Any, List, Tuple, Optional

# 导入项目核心组件
from engine.core import GateSequence, State
from engine.backend import set_backend

# 导入我们刚刚封装好的独立 QPE 模块
try:
    from engine.algorithms.fundamental_algorithm.qpe.algorithm import QPEAlgorithm
except ImportError:
    print("Warning: QPEAlgorithm 模块未找到，请确保路径正确 (engine.algorithms.fundamental_algorithm.qpe.algorithm)。")

# ==========================================================
# HHL Algorithm (Harrow-Hassidim-Lloyd) 算法类实现
# ==========================================================

class HHLAlgorithm:
    r"""
    HHL Algorithm Module (Standard Engineering Version)

    This module implements the Harrow–Hassidim–Lloyd (HHL) algorithm for solving
    a linear system of equations :math:`A x = b`.

    Core Steps:

    1. Encode the vector :math:`b` into a quantum state :math:`|b\rangle` in the system register.

    2. Perform quantum phase estimation (QPE) on the unitary operator
    :math:`U = e^{iAt}` to extract the eigenvalue phases of :math:`A`
    into an auxiliary register.

    3. Apply a controlled rotation on an ancilla qubit such that the
    amplitude is proportional to the inverse of the eigenvalue,
    i.e., :math:`1 / \lambda`.

    4. Perform inverse quantum phase estimation (iQPE) to uncompute
    the auxiliary register and remove entanglement.

    5. Measure the ancilla qubit and post-select on the outcome :math:`|1\rangle`,
    at which point the system register collapses to a state proportional to
    :math:`A^{-1} |b\rangle`.
    """
    def __init__(self):
        self.log_prefix = "INFO: [HHL] "
        self.last_result = None

    def run(self, A: np.ndarray, b: np.ndarray, d: int, t: Optional[float] = None,
            backend: str = 'torch', algo_dir: str = './hhl_results') -> Dict[str, Any]:
        r"""
        Execute the main flow of the HHL algorithm.

        Args:
            A (np.ndarray): Hermitian matrix to be solved. The dimension :math:`N`
                must be a power of 2.
            b (np.ndarray): Classical input vector.
            d (int): Number of qubits in the phase register, which determines
                the estimation accuracy.
            t (Optional[float]): Evolution time. If not provided, it will be
                automatically selected based on the eigenvalues of :math:`A`
                to avoid phase wraparound.
            backend (str): Simulation backend.
            algo_dir (str): Directory for saving quantum circuit diagrams.

        Returns:
            Dict[str, Any]: A dictionary containing the quantum solution state,
            classical solution, post-selection probability, circuit diagram,
            and ASCII panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 HHL 线性方程组求解器 (相位精度 d={d}, 后端={backend.upper()})")
        print("=" * 70)

        set_backend(backend)
        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 矩阵预处理与参数自适应解析...")
        
        A = np.asarray(A, dtype=complex)
        b = np.asarray(b, dtype=complex).reshape(-1)
        N = A.shape[0]
        
        if A.shape != (N, N): raise ValueError("A 必须是方阵。")
        if not np.allclose(A, A.conj().T): raise ValueError("当前版本要求 A 必须是 Hermitian 矩阵。")
        if (N & (N - 1)) != 0: raise ValueError("维度 N 必须是 2 的幂。")
        if b.size != N: raise ValueError("b 的维度与 A 不匹配。")
        
        n_sys = int(np.log2(N))
        norm_b = np.linalg.norm(b)
        if norm_b == 0: raise ValueError("向量 b 不能全为零。")
        b_state = b / norm_b
        
        # 提取特征值以动态确定演化时间 t 和缩放系数
        lam = np.real(np.linalg.eigvalsh(A)).astype(float)
        lam_abs = np.abs(lam)
        nonzero = lam_abs[lam_abs > 1e-12]
        if nonzero.size == 0: raise ValueError("A 的特征值近似为零，无法求逆。")

        lam_min, lam_max = float(np.min(nonzero)), float(np.max(nonzero))

        # 若谱中含负特征值，采用带符号相位模式:
        # 通过限制 |lambda|*t < 1/2 将正负相位分离到 [0,1/2) 与 (1/2,1)。
        has_negative = bool(np.any(lam < -1e-12))
        signed_phase_mode = has_negative
        if signed_phase_mode:
            target_phi_max = 0.5 - 1.0 / (2 ** d)
            if target_phi_max <= 0:
                raise ValueError(f"相位比特数 d={d} 太小，无法启用带符号相位模式。")
        else:
            target_phi_max = 1.0 - 1.0 / (2 ** d)
        
        if t is None:
            t = target_phi_max / lam_max
        else:
            phi_max = lam_max * t
            if phi_max >= 1.0 or phi_max > target_phi_max:
                t = target_phi_max / lam_max
                print(f"  * 警告: 用户提供的 t 导致相位溢出，已自动修正为 {t:.4f}")

        grid = 2 ** d
        phi_min = lam_min * t 
        k_start = int(np.floor(phi_min * grid)) - 10
        if int(np.floor(phi_min * grid)) < 1:
            raise ValueError(f"相位比特数 d={d} 不足以解析最小相位，请增大 d。")
        if signed_phase_mode:
            signed_cap = max(1, grid // 2 - 1)
            k_start = max(1, min(k_start, signed_cap))
        else:
            k_start = max(1, min(k_start, grid - 1))
        
        # 物理缩放系数 (还原量子态到真实向量所需)
        scale_factor = norm_b * t * grid / k_start
        
        print(f"  - 方程组维度 (N): {N} ({n_sys} System Qubits)")
        print(f"  - 自动演化时间 (t): {t:.6f}")
        print(f"  - 相位网格起始点 (k_start): {k_start}")
        print(f"  - 相位解码模式: {'signed (保留特征值符号)' if signed_phase_mode else 'unsigned'}")
        print(f"{self.log_prefix}阶段 1/5: 预处理完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始搭积木构建 HHL 量子电路...")
        
        total_qubits = 1 + d + n_sys
        anc = 0
        phase_qubits = list(range(1, d + 1))
        system_qubits = list(range(d + 1, total_qubits))
        
        gs = GateSequence(total_qubits, name="HHL_Algorithm",backend=backend)
        
        # [步骤 A]: 制备初态 |b>
        gs.initialize(b_state, system_qubits)
        print("  - 已挂载态制备模块: 初始化 |b>")
        
        # [步骤 B]: 构建 U 并调用独立的 QPE 模块
        U_mat, _ = self._expi_hermitian(A, t)
        U_circ = self._unitary_circuit_from_matrix(U_mat,backend=backend)
        
        qpe_engine = QPEAlgorithm()
        qpe_circ = qpe_engine.build_qpe_circuit(U_circ, d,backend=backend)
        gs.append(qpe_circ, phase_qubits + system_qubits)
        print("  - 已挂载 QPE 模块: 提取特征相位")
        
        # [步骤 C]: 受控倒数旋转
        rot_circ = self._controlled_reciprocal_rotation(
            d, t, k_start, signed_phase=signed_phase_mode, backend=backend
        )
        gs.append(rot_circ, [anc] + phase_qubits)
        print("  - 已挂载倒数受控旋转模块: 非线性映射 1/lambda")
        
        # [步骤 D]: iQPE 解缠结
        gs.append(qpe_circ.dagger(), phase_qubits + system_qubits)
        print("  - 已挂载逆 QPE (iQPE) 模块: 系统解缠结")
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        sim_start = time.time()
        final_state = gs.execute()
        state_arr = np.asarray(final_state, dtype=complex).reshape(-1)
        sim_time = time.time() - sim_start
        
        print(f"  - 底层模拟计算耗时: {sim_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行经典后处理 (后选择提取解向量)...")
        
        # 获取后选择结果和量子态
        psi_sys, p_succ, x_q = self._postselect_solution_state(state_arr, scale_factor, d, n_sys)
        
        # 计算经典精确解进行对比
        x_classical = np.linalg.solve(A, b)
        diff_norm = np.linalg.norm(x_q - x_classical)
        
        print(f"  - 后选择成功概率 P(anc=1, phase=|0>): {p_succ:.6f}")
        print(f"  - 量子近似解与经典精确解误差 (L2 Norm): {diff_norm:.6e}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"HHL_d{d}_N{N}_circuit.svg")
        gs.draw(filename=circuit_path, title=f"HHL Algorithm (N={N}, d={d})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        msg = f"HHL 求解完成，系统坍缩成功率 {p_succ:.4f}，经典量子解误差 {diff_norm:.4e}"
        
        self._update_last_result(
            N=N, d=d, n_sys=n_sys, total_qubits=total_qubits, backend=backend,
            comp_time=comp_time, p_succ=p_succ, diff_norm=diff_norm,
            scale_factor=scale_factor, circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(x_q, x_classical, psi_sys, p_succ, gs, circuit_path, msg)

    # ==========================================================
    # 内部量子组件与数学子程序
    # ==========================================================
    
    def _decode_signed_phase_index(self, k: int, d: int) -> int:
        """
        Convert the QPE phase index k (0..2^d-1) into a signed index:
        k in [0, 2^(d-1)] stays unchanged, while k in (2^(d-1), 2^d) is mapped to negative values.
        """
        grid = 2 ** d
        half = grid // 2
        return k if k <= half else k - grid

    def _controlled_reciprocal_rotation(self, d: int, t: float, k_start: int,
                                        signed_phase: bool = False, backend='torch') -> GateSequence:
        """Eigenvalue reciprocal controlled rotation (extracted from user code)"""
        grid = 2 ** d
        gs = GateSequence(d + 1, name=f"cond_Recip_Rot",backend=backend)
        controls = list(range(1, d + 1))
        target = 0 
        C = k_start

        if signed_phase:
            k_iter = range(1, grid)  # k=0 对应零特征值分量，跳过避免除零
        else:
            k_iter = range(k_start, grid)

        for k in k_iter:
            if signed_phase:
                signed_k = self._decode_signed_phase_index(k, d)
                if signed_k == 0 or abs(signed_k) < k_start:
                    continue
                # 保留符号: C / signed_k，可得到正负旋转角。
                val = float(np.clip(C / signed_k, -1.0, 1.0))
            else:
                val = float(np.clip(C / k, -1.0, 1.0))
            
            flipped = []
            for i in range(d):
                if ((k >> i) & 1) == 0:
                    gs.x(i + 1)
                    flipped.append(i + 1)

            theta = 2.0 * np.arcsin(val)
            gs.mcry(theta, controls, target)

            for q in flipped:
                gs.x(q)

        return gs

    def _expi_hermitian(self, A: np.ndarray, t: float) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate U = exp(i A t)"""
        w, V = np.linalg.eigh(A)
        phases = np.exp(1j * 2.0 * np.pi * w * t)
        U = V @ np.diag(phases) @ V.conj().T
        return U, w

    def _unitary_circuit_from_matrix(self, U: np.ndarray,backend='torch') -> GateSequence:
        """Pack the unitary matrix into a GateSequence"""
        n = int(np.log2(U.shape[0]))
        gs = GateSequence(n, name="U_exp_iAt",backend=backend)
        gs.unitary(U, list(range(n)))
        return gs

    def _postselect_solution_state(self, state: np.ndarray, scale: float, d: int, n: int) -> Tuple[np.ndarray, float, np.ndarray]:
        """Then select ancilla=1 and phase=|0...0> and extract the solution vector."""
        # 1. 提取 ancilla=1 的切片 (qubit 0 是最低位)
        vec_anc1 = state[1::2] 
        
        # 2. 提取 phase=|0...0> 的切片 (步长为 2^d)
        stride = 2 ** d
        vec_sys = vec_anc1[0::stride]
        
        x_q = np.array(vec_sys) * scale
        p = float(np.vdot(vec_sys, vec_sys).real)
        
        if p <= 0:
            raise ValueError("后选择概率为零 (ancilla=1 且 phase=0 状态未出现)。")
            
        psi_sys = vec_sys / np.sqrt(p)
        return psi_sys, p, x_q

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, N, d, n_sys, total_qubits, backend, comp_time, p_succ, diff_norm, scale_factor, circuit_path, msg):
        self.last_result = {
            "N": N, "d": d, "n_sys": n_sys, "total": total_qubits,
            "backend": backend, "comp_time": comp_time, "p_succ": p_succ,
            "diff_norm": diff_norm, "scale": scale_factor,
            "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, x_q, x_classical, psi_sys, p_succ, gs, circuit_path, msg):
        return {
            "status": "success",
            "solution_quantum": x_q,
            "solution_classical": x_classical,
            "state_system": psi_sys,
            "post_selection_prob": p_succ,
            "full_circuit": gs,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        r = self.last_result
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  HHL LINEAR SOLVER 结果 ⚛️
{'='*70}

🎯 求解精度验证 | 量子解 vs 经典精确解 (L2 范数误差): {r['diff_norm']:.6e}

{'─'*70}
🔢 算法参数与矩阵维度
{'─'*70}
  方程组矩阵 (A): {r['N']}x{r['N']} 
  相位寄存器 (d): {r['d']} 位
  物理缩放系数  : {r['scale']:.4f}
{'─'*70}
⚡ 量子状态分析与硬件开销
{'─'*70}
  系统/标志后选择成功率 P(anc=1, phase=0): {r['p_succ']:.6f}
  资源占用: 总计 {r['total']} Qubits (Anc: 1, Phase: {r['d']}, Sys: {r['n_sys']})
  计算耗时: {r['comp_time']:.4f} 秒
  电路图路径: {r['circuit_path']}
{'─'*70}
💡 备注: {r['message']}
{'='*70}
"""
        return ascii_art

# ==========================================================
# Main 测试入口 (复现笔记中的 Tridiagonal 测试案例)
# ==========================================================
if __name__ == "__main__":
    print("\n>>> 开始执行 HHL 算法测试 (大型 16x16 三对角矩阵)...")
    
    # 构造 A (16x16 三对角矩阵) 和 b
    N = 16
    A = np.zeros((N, N), dtype=complex)
    np.fill_diagonal(A, 2.0)
    np.fill_diagonal(A[1:], -1.0) 
    np.fill_diagonal(A[:, 1:], -1.0) 

    b = np.ones(N, dtype=complex)

    # 运行算法 (使用 11 个相位比特)
    algo = HHLAlgorithm()
    backend='unitarylab'
    # backend='torch'
    result = algo.run(A=A, b=b, d=11,backend=backend)
    
    print(result['plot'])
    
    print("\n--- 详细解向量对比 ---")
    print("量子近似解 (x_q):")
    print(result['solution_quantum'])
    print("\n经典精确解 (x_c):")
    print(result['solution_classical'])