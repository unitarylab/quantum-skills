import time
import os
import numpy as np
import mpmath as mp
from typing import Dict, Any, List

# 导入项目核心组件
from engine.core import GateSequence, Register, State
from engine.backend import set_backend

# 导入外部依赖 (假设你的项目中有这个 QSP 模块)
try:
    from xiajie.block_encodings.QSP_matrix_function_block_encoding import QSP_block_encoding
except ImportError:
    print("Warning: QSP_block_encoding module not found. Algorithm will fail if executed.")

# ==========================================================
# QSVT Linear Solver (基于 QSVT 的量子线性求解器) 算法类实现
# ==========================================================

class QSVTLinearSolverAlgorithm:
    r"""
    QSVT Linear Solver Algorithm Module (Standard Engineering Version)

    Solves the linear system :math:`A x = b` using the Quantum Singular Value
    Transform (QSVT) / Quantum Signal Processing (QSP) framework.

    Core Logic:

    1. Approximate the inverse function :math:`f(x) = 1 / x` using a Chebyshev polynomial.

    2. Convert the polynomial coefficients into a QSP phase sequence.

    3. Apply the QSVT procedure using the block-encoding unitary
    :math:`U_A` of :math:`A`, producing a block-encoding proportional
    to :math:`A^{-1}`.

    4. Apply the resulting operator to the input state :math:`|b\rangle`
    and recover the normalized coefficients in post-processing to
    obtain the solution state :math:`|x\rangle`.
    """
    def __init__(self):
        self.log_prefix = "INFO: [QSVT-QLSA] "
        self.last_result = None

    def run(self, gs_be: GateSequence, b: np.ndarray, 
            kappa: float, alpha: float, epsilon: float, 
            n_sys: int, n_anc_be: int,
            backend: str = 'torch', algo_dir: str = './qsvt_results') -> Dict[str, Any]:
        r"""
        Execute the main flow of the QSVT-based linear solver.

        Args:
            gs_be (GateSequence): Block-encoding circuit :math:`U_A`
                corresponding to matrix :math:`A`.
            b (np.ndarray): Classical vector :math:`b`.
            kappa (float): Condition number of matrix :math:`A`.
            alpha (float): Block-encoding scaling factor.
            epsilon (float): Target approximation accuracy.
            n_sys (int): Number of qubits :math:`n` in the system register.
            n_anc_be (int): Number of auxiliary qubits :math:`m`
                required for block-encoding.
            backend (str): Simulation backend.
            algo_dir (str): Directory for saving quantum circuit diagrams.

        Returns:
            Dict[str, Any]: Dictionary containing classical solutions,
            approximation errors, circuit diagram paths, and ASCII panels.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 QSVT 线性求解器 (目标精度={epsilon}, 后端={backend.upper()})")
        print("=" * 70)

        set_backend(backend)
        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 经典预处理 (计算 Chebyshev 逼近系数)...")
        
        # 验证输入
        norm_b = np.linalg.norm(b)
        if norm_b == 0:
            raise ValueError("源向量 b 不能全为零！")
            
        # 计算 f(x) = 1/x 的截断 Chebyshev 展开系数
        c_chebyshev = self._chebyshev_factor(kappa, alpha, epsilon)
        k_degree = len(c_chebyshev) * 2 - 1
        
        # 组装完整的系数数组 (只包含奇数阶)
        c_array = np.asarray(c_chebyshev, dtype=float)
        a_chebyshev = np.zeros(2 * len(c_array), dtype=float)
        a_chebyshev[1::2] = c_array
        
        print(f"  - 矩阵条件数 (kappa): {kappa}")
        print(f"  - Block-Encoding 因子 (alpha): {alpha}")
        print(f"  - 截断多项式最高阶数: {k_degree}")
        print(f"{self.log_prefix}阶段 1/5: 预处理完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建 QSVT 量子电路...")
        
        # QSVT 线路总比特数 = 系统比特 + BE辅助比特 + QSP/QSVT控制比特(1个)
        total_qubits = n_sys + n_anc_be + 1
        gs = GateSequence(total_qubits, name='QSVT_QLSA', backend=backend)
        
        # 1. 初始化 |b> 态 (加载到系统寄存器，这里假设系统在前 n_sys 位)
        b_state = b / norm_b
        sys_qubits = list(range(n_sys))
        gs.initialize(b_state, sys_qubits)
        print(f"  - 已加载归一化的源态 |b>")
        
        # 2. 生成 QSP/QSVT 处理序列
        print(f"  - 正在调用 QSP 引擎生成多项式 Block-Encoding 线路...")
        opts = {
            'maxiter': 400, 'criteria': 1e-13, 
            'useReal': True, 'targetPre': True, 'method': 'FPI'
        }
        
        # 注意：此处传入 gs_be 的逆运算，对应 U_A^\dagger
        # 具体参数要求依赖你的 QSP_block_encoding 实现
        qsp_circ = QSP_block_encoding(
            is_coef_cheby=True, coef=a_chebyshev, parity=1, 
            opts=opts, u=gs_be.dagger(), n=n_sys, m=n_anc_be
        )
        
        gs.append(qsp_circ, list(range(total_qubits)))
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        sim_start = time.time()
        final_state = gs.execute()
        state_arr = np.asarray(final_state, dtype=complex).reshape(-1)
        sim_time = time.time() - sim_start
        
        print(f"  - 底层模拟计算耗时: {sim_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行经典后处理 (恢复缩放系数提取解)...")
        
        # 提取系统寄存器对应的振幅 (前 2^n_sys 个元素)
        # 注意：这依赖于你的 QSP 模块关于辅助比特排列的约定。这里假设辅助态全为 |0> 对应前 2^n 项。
        raw_solution = state_arr[0 : 2**n_sys]
        
        # 恢复物理缩放因子
        # 乘以 2 是因为我们使用的函数 f(x) \approx 1/(2 * kappa * alpha * x) 来保证值域落在 [-1, 1]
        scaling_factor = norm_b * kappa * alpha * 2 
        final_solution = raw_solution * scaling_factor
        
        # 计算验证指标 (如果在外部有精确解，可以做对比，这里计算范数供参考)
        sol_norm = np.linalg.norm(final_solution)
        
        print(f"  - 提取原始量子态振幅并应用缩放因子: {scaling_factor:.4f}")
        print(f"  - 求解所得向量范数: ||x|| = {sol_norm:.4f}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"QSVT_QLSA_k{int(kappa)}_circuit.svg")
        
        gs.draw(filename=circuit_path, title=f"QSVT Linear Solver (kappa={kappa})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        msg = f"基于 QSVT 的线性方程组求解完成，使用了 {k_degree} 阶多项式逼近。"
        
        self._update_last_result(
            n_sys=n_sys, n_anc=n_anc_be + 1, kappa=kappa, alpha=alpha, 
            epsilon=epsilon, degree=k_degree, comp_time=comp_time, 
            sol_norm=sol_norm, circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(final_solution, gs, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, n_sys, n_anc, kappa, alpha, epsilon, degree, comp_time, sol_norm, circuit_path, msg):
        self.last_result = {
            "n_sys": n_sys, "n_anc": n_anc, "total": n_sys + n_anc,
            "kappa": kappa, "alpha": alpha, "epsilon": epsilon, "degree": degree,
            "comp_time": comp_time, "sol_norm": sol_norm,
            "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, solution, qc, circuit_path, msg):
        return {
            "status": "success",
            "solution_vector": solution,
            "full_circuit": qc,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        r = self.last_result
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  QSVT LINEAR SOLVER 结果 ⚛️
{'='*70}

📊 求解完成 | 提取解向量范数 ||x|| = {r['sol_norm']:.6f}

{'─'*70}
🔢 算法参数与数学配置
{'─'*70}
  条件数 (κ): {r['kappa']} | BE 因子 (α): {r['alpha']}
  目标精度 (ε): {r['epsilon']}
  Chebyshev 逼近多项式阶数: {r['degree']}
{'─'*70}
⚡ 量子电路与硬件资源
{'─'*70}
  系统寄存器: {r['n_sys']} Qubits
  辅助寄存器: {r['n_anc']} Qubits (总计 {r['total']} Qubits)
  计算耗时: {r['comp_time']:.4f} 秒
  电路图路径: {r['circuit_path']}
{'─'*70}
💡 备注: {r['message']}
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部数学辅助组件: Chebyshev 系数计算 (重构自用户代码)
    # ==========================================================
    def _b_value(self, kappa: float, alpha: float, epsilon: float) -> float:
        return np.ceil((kappa * alpha)**2 * np.log(kappa * alpha / epsilon))

    def _j_0_value(self, b: float, epsilon: float) -> float:
        return np.ceil(np.sqrt(b * np.log(4 * b / epsilon)))

    def _central_binom_ratio(self, b: float, dps: int = 50) -> float:
        mp.mp.dps = dps
        b_int = int(b)
        logR = mp.loggamma(2*b_int + 1) - 2*mp.loggamma(b_int + 1) - b_int*mp.log(4)
        return float(mp.e**logR)

    def _chebyshev_factor(self, kappa: float, alpha: float, epsilon: float) -> np.ndarray:
        """Calculate the Chebyshev expansion coefficients of f(x) = (1-(1-x^2)^b)/x"""
        b = self._b_value(kappa, alpha, epsilon)
        j = self._j_0_value(b, epsilon)
        
        mid_v = self._central_binom_ratio(b)
        value = (1. - mid_v) / 2.
        j = int(j) + 1
        
        coefficient_list = np.zeros(j, dtype=float)
        for k in range(j):
            coefficient_list[k] = 4 * (-1) ** k * value
            mid_v = mid_v * (b - k) / (b + k + 1)
            value -= mid_v
            
        return coefficient_list / (2. * kappa * alpha)

# ==========================================================
# Main 测试入口 (还原自 Jupyter)
# ==========================================================
if __name__ == "__main__":
    def block_encoding_diag(a0=0.6, a1=0.2):
        theta0 = 2 * np.arccos(a0)
        theta1 = 2 * np.arccos(a1)
        gs = GateSequence(2)
        anc, sys = 1, 0
        gs.cry(theta0, sys, anc, [0])
        gs.cry(theta1, sys, anc, [1])
        return gs

    def block_encoding_nondiag_via_hadamard(a0=0.6, a1=0.2):
        U = block_encoding_diag(a0, a1)
        gs = GateSequence(2)
        sys = 0
        gs.h(sys)
        gs.append(U, [0, 1])
        gs.h(sys)
        return gs

    print("\n>>> 开始执行 QSVT 线性求解器测试...")
    algo = QSVTLinearSolverAlgorithm()
    
    # 构建矩阵 A 的 Block-Encoding
    a0, a1 = 0.8, 0.4
    be2 = block_encoding_nondiag_via_hadamard(a0, a1)
    
    # 设置源向量 b
    b_vec = np.array([1., 0.])
    
    # 运行算法
    result = algo.run(
        gs_be=be2, b=b_vec, 
        kappa=5.0, alpha=1.0, epsilon=0.001, 
        n_sys=1, n_anc_be=1
    )
    
    print(result['plot'])
    print("\n最终解向量 x:")
    print(result['solution_vector'])