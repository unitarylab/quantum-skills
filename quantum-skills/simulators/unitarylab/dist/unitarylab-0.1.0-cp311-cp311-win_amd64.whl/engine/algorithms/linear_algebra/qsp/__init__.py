"""
QSPAlgorithm
"""

from .algorithm import QSPAlgorithm

__all__ = [
    'QSPAlgorithm',
]