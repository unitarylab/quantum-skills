import time
import os
import numpy as np
from scipy.optimize import minimize
from typing import Dict, Any

# 导入项目核心组件
from ....core import Register, GateSequence

class QSPAlgorithm:
    """
    QSP Algorithm Module (Standard Engineering Version)
    实现基于量子信号处理的哈密顿量模拟，采用与 HHL 一致的工程化输出格式。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [QSP] "
        self.last_result = None
        self.last_circuit = None
        np.random.seed(seed)

    def run(self, target_tau: float, degree: int, x_value: float = 0.5, 
            backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        """
        执行 QSP 算法主流程。
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 QSP 演化模拟器 (阶数 d={degree}, 后端={backend.upper()})")
        print("=" * 70)

        start_time = time.time()

        # ================= 阶段 1/5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 目标函数解析与相位序列寻优...")
        
        # 记录数学背景
        print(f"  - 目标演化算子: exp(-i * {target_tau:.4f} * x)")
        print(f"  - 优化算法: L-BFGS-B (采样点数: {2*degree+1})")
        
        phases = self._find_phases(target_tau, degree)
        print(f"{self.log_prefix}阶段 1/5: 相位寻优完成，获取 Φ 序列 ✓")

        # ================= 阶段 2/5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 构建 QSP 量子电路积木...")
        
        reg = Register('q', 1)
        gs = GateSequence(reg, name=f"QSP_Evolution_d{degree}", backend=backend)
        
        # 信号算子参数
        theta = np.arccos(np.clip(x_value, -1, 1))
        
        # 逐步记录电路挂载
        print(f"  - 挂载初始相位旋转: Rz({2*phases[0]:.4f})")
        gs.rz(2 * phases[0], 0) 
        
        print(f"  - 循环挂载 {degree} 组 [信号算子 W(x) + 相位旋转 Rz]")
        for k in range(1, degree + 1):
            gs.rx(2 * theta, 0)
            gs.rz(2 * phases[k], 0)

        self.last_circuit = gs
        print(f"{self.log_prefix}阶段 2/5: 电路构建完成 (总门数: {2*degree+1}) ✓")

        # ================= 阶段 3/5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        sim_start = time.time()
        final_state = gs.execute() 
        sim_time = time.time() - sim_start
        
        print(f"  - 底层模拟计算耗时: {sim_time:.6f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子态演化完成 ✓")

        # ================= 阶段 4/5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 精度对比分析与后处理...")
        
        # 提取模拟值与理想值对比
        qsp_val = complex(final_state[0]) if hasattr(final_state, '__getitem__') else 0.0
        ideal_val = np.exp(-1j * target_tau * x_value)
        abs_error = float(np.abs(qsp_val - ideal_val))
        
        print(f"  - 测试点 x = {x_value}")
        print(f"  - 理论预期实部: {ideal_val.real:.6f}, 模拟实部: {qsp_val.real:.6f}")
        print(f"  - 绝对误差 (L2): {abs_error:.6e}")
        print(f"{self.log_prefix}阶段 4/5: 分析完成 ✓")

        # ================= 阶段 5/5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        # 关键信息记录在文件名中：d 和 tau
        file_name = f"QSP_d{degree}_tau{target_tau:.2f}_circuit.svg"
        circuit_path = os.path.join(algo_dir, file_name)
        
        try:
            gs.draw(filename=circuit_path, title=f"QSP Simulation (d={degree}, tau={target_tau})")
            print(f"  - 电路图已保存至: {circuit_path}")
        except Exception as e:
            print(f"  - [Warning] 绘图失败: {e}")
            circuit_path = "None"
        
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果汇总与备注 =================
        msg = f"QSP 求解完成，演化参数 tau={target_tau}，模拟误差 {abs_error:.4e}"
        
        self.last_result = {
            "degree": degree, "tau": target_tau, "x": x_value,
            "sim_time": sim_time, "comp_time": comp_time,
            "error": abs_error, "qsp_val": qsp_val, "ideal_val": ideal_val,
            "circuit_path": circuit_path, "message": msg, "backend": backend
        }

        return {
            "status": "success",
            "error": abs_error,
            "circuit": gs,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def _find_phases(self, tau, d):
        x_samples = np.linspace(-1, 1, 2*d+1)
        def get_p_val(x, phs):
            theta = np.arccos(np.clip(x, -1, 1))
            W = np.array([[x, 1j*np.sqrt(1-x**2)], [1j*np.sqrt(1-x**2), x]])
            def Rz(p): return np.array([[np.exp(1j*p), 0], [0, np.exp(-1j*p)]])
            U = Rz(phs[0])
            for k in range(1, len(phs)):
                U = U @ W @ Rz(phs[k])
            return U[0, 0]
        loss = lambda phs: np.mean([abs(get_p_val(x, phs) - np.exp(-1j*tau*x))**2 for x in x_samples])
        res = minimize(loss, np.random.randn(d+1)*0.1, method='L-BFGS-B')
        return res.x

    def format_result_ascii(self) -> str:
        """参照 HHL 风格设计的标准化结果面板"""
        if not self.last_result: return "尚未执行算法"
        r = self.last_result
        
        return f"""
{'='*70}
{' '*15}⚛️  QSP HAMILTONIAN SIMULATOR 结果 ⚛️
{'='*70}

🎯 模拟精度验证 | 模拟值 vs 理想演化值 (误差): {r['error']:.6e}

{'─'*70}
🔢 算法参数与数学背景
{'─'*70}
  多项式逼近阶数 (d) : {r['degree']}
  演化时间参数 (tau) : {r['tau']:.4f}
  测试特征值点 (x)   : {r['x']}
  理想复振幅 (Ideal) : {r['ideal_val']:.4f}
{'─'*70}
⚡ 量子计算开销与性能统计
{'─'*70}
  后端执行引擎       : {r['backend'].upper()}
  模拟器纯计算耗时   : {r['sim_time']:.6f} 秒
  任务总计耗时       : {r['comp_time']:.4f} 秒
  量子线路图保存路径 : {r['circuit_path']}
{'─'*70}
💡 备注: {r['message']}
{'='*70}
"""

if __name__ == "__main__":
    # 执行测试
    algo = QSPAlgorithm()
    result = algo.run(target_tau=1.2, degree=14, x_value=0.7)
    print(result['plot'])