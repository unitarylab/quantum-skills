import time
import os
import numpy as np
from typing import Dict, Any, List, Tuple

# 导入项目核心组件
from engine.core import GateSequence, Register, State
from engine.backend import set_backend

# ==========================================================
# Linear Combination of Unitaries (LCU) 算法类实现
# ==========================================================

class LCUAlgorithm:
    r"""
    LCU Algorithm Module (Standard Engineering Version)

    Implements the quantum circuit realization of a non-unitary operator
    :math:`M = \sum_j \alpha_j U_j`.

    By constructing the state preparation operator :math:`V`, the SELECT
    operator (multi-controlled :math:`U_j`), and the inverse operator
    :math:`V^\dagger`, the algorithm probabilistically prepares the state
    :math:`M |\psi\rangle` in the system register, conditioned on measuring
    the ancilla register in the zero state.
    """
    def __init__(self):
        self.log_prefix = "INFO: [LCU] "
        self.last_result = None

    def run(self, alphas: List[float], unitaries: List[GateSequence], 
            n_sys: int, initial_state: GateSequence = None,
            backend: str = 'torch', algo_dir: str = './lcu_results') -> Dict[str, Any]:
        r"""
        Execute the LCU main process.

        Args:
            alphas (List[float]): Non-negative coefficients :math:`\alpha_j`
                associated with each unitary operator.
            unitaries (List[GateSequence]): List of unitary operator circuits
                :math:`U_j`.
            n_sys (int): Number of qubits in the system (data register).
            initial_state (Optional[GateSequence]): State preparation circuit
                for the system register. Defaults to the all-zero state if not provided.
            backend (str): Simulation backend. ``'torch'`` is recommended.
            algo_dir (str): Directory for saving quantum circuit diagrams.

        Returns:
            Dict[str, Any]: Dictionary containing execution results, including
            the LCU success probability, circuit diagram path, and ASCII panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 LCU 算法主程序 (后端={backend.upper()})")
        print("=" * 70)

        set_backend(backend)
        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 解析与验证 LCU 系数与算子...")
        
        if len(alphas) != len(unitaries):
            raise ValueError("系数 alphas 的长度必须与 unitaries 的长度一致。")
            
        m = len(alphas)
        n_anc = int(np.ceil(np.log2(m)))
        total_qubits = n_anc + n_sys
        
        s_norm = float(np.sum(alphas))
        
        print(f"  - LCU 项数 (m): {m}")
        print(f"  - 辅助寄存器 (Ancilla): {n_anc} Qubits")
        print(f"  - 数据寄存器 (System): {n_sys} Qubits (总计 {total_qubits} Qubits)")
        print(f"  - 归一化常数 (s = sum(alpha)): {s_norm:.6f}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建 LCU 核心量子电路...")
        
        # 寄存器定义 (这里使用列表索引方便操作，0~n_anc-1为辅助，其余为系统)
        anc_qubits = list(range(n_anc))
        sys_qubits = list(range(n_anc, total_qubits))
        
        qc = GateSequence(total_qubits, name='LCU_circuit', backend=backend)
        
        # 1. 制备系统初始态 (如果提供)
        if initial_state is not None:
            if initial_state.get_num_qubits() != n_sys:
                raise ValueError("initial_state 的比特数必须等于 n_sys")
            qc.append(initial_state, sys_qubits)
            print(f"  - 已加载用户提供的系统初始态")
            
        # 2. 构建并添加 V 算子
        print(f"  - 正在构建并施加 V 算子 (系数状态制备)...")
        V_circ = self._build_V(alphas, s_norm, m, n_anc,backend=backend)
        qc.append(V_circ, anc_qubits)
        
        # 3. 构建并添加 SELECT(U) 算子
        print(f"  - 正在构建并施加 SELECT 算子 (多受控多路复用)...")
        select_circ = self._build_select(unitaries, m, n_anc, n_sys)
        qc.append(select_circ, range(total_qubits))
        
        # 4. 构建并添加 V_dagger 算子
        print(f"  - 正在构建并施加 V_dagger 算子...")
        V_dag_circ = V_circ.dagger()
        qc.append(V_dag_circ, anc_qubits)
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        sim_start = time.time()
        raw_result = qc.execute()
        state_obj = State(np.asarray(raw_result, dtype=complex).reshape(-1))
        sim_time = time.time() - sim_start
        
        print(f"  - 底层模拟计算耗时: {sim_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行经典后处理 (提取 LCU 成功概率)...")
        
        # LCU 成功的标志是：测量辅助寄存器得到全 0 态 (|0...0>)
        anc_probs = state_obj.probabilities_dict(anc_qubits, endian="little", threshold=0.0)
        
        # 构造全 0 字符串，例如 n_anc=2 时为 "00"
        zero_state_str = "0" * n_anc 
        success_prob = float(anc_probs.get(zero_state_str, 0.0))
        
        # 理论上的成功概率下限 (非常依赖于非酉矩阵的条件数和初始态)
        # 如果是单纯的酉矩阵加和，p_success = || M|psi> ||^2 / s^2
        is_success = success_prob > 1e-6 # 设定一个极其微小的阈值判断是否坍缩失败
        
        print(f"  - 辅助比特全为 |0> 的概率 (LCU 成功率): {success_prob:.6f}")
        print(f"  - 状态评估: {'有效' if is_success else '成功率极低，可能由于系统算子互相抵消'}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"LCU_m{m}_circuit.svg")
        
        qc.draw(filename=circuit_path, title=f"LCU Algorithm (m={m} terms)")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        msg = f"LCU 线路执行完毕，非酉算符作用成功率 p = {success_prob:.4f}。"
        
        self._update_last_result(
            m=m, n_anc=n_anc, n_sys=n_sys, backend=backend, comp_time=comp_time,
            s_norm=s_norm, success_prob=success_prob, circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(success_prob, qc, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, m, n_anc, n_sys, backend, comp_time, s_norm, success_prob, circuit_path, msg):
        self.last_result = {
            "m": m, "n_anc": n_anc, "n_sys": n_sys, "total": n_anc + n_sys,
            "backend": backend, "comp_time": comp_time, "s_norm": s_norm,
            "success_prob": success_prob, "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, success_prob, qc, circuit_path, msg):
        return {
            "status": "success",
            "lcu_success_probability": success_prob,
            "full_circuit": qc,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        r = self.last_result
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  LINEAR COMBINATION OF UNITARIES 结果 ⚛️
{'='*70}

📊 LCU 成功概率 (P_success): {r['success_prob']:.6f}

{'─'*70}
🔢 算法配置
{'─'*70}
  酉算符数量 (m): {r['m']} 项
  归一化常数 (s): {r['s_norm']:.6f}
  模拟后端: {r['backend'].upper()}
{'─'*70}
⚡ 量子电路结构
{'─'*70}
  总量子比特数: {r['total']} (辅助区: {r['n_anc']}, 系统区: {r['n_sys']})
  计算耗时: {r['comp_time']:.4f} 秒
  电路图路径: {r['circuit_path']}
{'─'*70}
💡 物理意义
{'─'*70}
  当辅助比特测量为 |0...0> 时，数据寄存器的态即正比于 M|psi>。
  {r['message']}
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件: V 算子与 SELECT 算子 (重构自用户 LCU_c)
    # ==========================================================
    
    def _build_V(self, alphas: List[float], s_norm: float, m: int, n_anc: int,backend='torch') -> GateSequence:
        """Construct the V operator and prepare a coefficient superposition state."""
        dim = 2 ** n_anc
        state = np.zeros(dim)
        for j in range(m):
            state[j] = np.sqrt(alphas[j] / s_norm)
            
        prep_gates = self._state_preparation_tree(state)
        
        qc = GateSequence(n_anc, name="V_Operator",backend=backend)
        for gate in prep_gates:
            if gate["control_qubit"] is None:
               qc.ry(gate["angle"], gate["target"]) 
            else:
                qc.mcry(gate["angle"], gate["control_qubit"], gate["target"], gate["control_value"])
        return qc

    def _build_select(self, unitaries: List[GateSequence], m: int, n_anc: int, n_sys: int) -> GateSequence:
        """Construct the SELECT operator to achieve multiple controlled multiplexing."""
        qc = GateSequence(n_anc + n_sys, name="SELECT_Operator")
        anc_qubits = list(range(n_anc))
        sys_qubits = list(range(n_anc, n_anc + n_sys))
        
        for j, U in enumerate(unitaries):
            ctrl_state = format(j, f"0{n_anc}b")
            # 调用底层引擎的多比特受控门接口
            qc.append(U, target=sys_qubits, control=anc_qubits, control_sequence=ctrl_state)
            
        return qc

    def _state_preparation_tree(self, alpha: np.ndarray) -> List[Dict]:
        """Recursively generate the gate sequence of the amplitude coding tree (pure classical computation stage)"""
        alpha = np.asarray(alpha, dtype=complex)
        alpha = alpha / np.linalg.norm(alpha)
        N = len(alpha)
        n = int(np.log2(N))
        gates = []

        def build(level, start, length, controls):
            if level == n: return
            half = length // 2
            a = alpha[start:start+half]
            b = alpha[start+half:start+length]
            norm_a = np.linalg.norm(a)
            norm_b = np.linalg.norm(b)

            theta = 0 if (norm_a + norm_b == 0) else 2 * np.arctan2(norm_b, norm_a)
            target = level

            if len(controls) == 0:
                gates.append({"name": "RY", "target": target, "control_qubit": None, "control_value": None, "angle": theta})
            else:
                gates.append({"name": "CRY", "target": target, "control_qubit": range(level), "control_value": controls.copy(), "angle": theta})
                
            build(level+1, start, half, controls+[0])
            build(level+1, start+half, half, controls+[1])

        build(0, 0, N, [])
        return gates

# ==========================================================
# Main 测试入口
# ==========================================================
if __name__ == "__main__":
    algo = LCUAlgorithm()
    
    # backend='unitarylab'
    backend='torch'

    # 构建测试案例: M = 0.6 * I + 0.4 * X 作用在 1 个量子比特上
    # 辅助比特需要 1 个 (因为 m=2)
    alphas_test = [0.6, 0.4]
    
    # 构造 U0 = I
    U0 = GateSequence(1)
    U0.i(0) # 假设引擎支持 identity 门
    
    # 构造 U1 = X
    U1 = GateSequence(1)
    U1.x(0)
    
    unitaries_test = [U0, U1]
    
    # 运行算法
    result = algo.run(alphas=alphas_test, unitaries=unitaries_test, n_sys=1,backend=backend)
    print(result['plot'])