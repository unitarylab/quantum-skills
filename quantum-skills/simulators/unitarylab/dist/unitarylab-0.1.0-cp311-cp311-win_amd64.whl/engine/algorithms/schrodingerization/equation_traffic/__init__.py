"""
Traffic Flow Equation Algorithm Module

Solve the one-dimensional traffic flow equation based on the Schrödingerization method:

∂u/∂t + g'(u)∂u/∂x = ν∂²u/∂x²
"""
from .algorithm import TrafficFlowEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "traffic"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = TrafficFlowEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维交通流方程"

__all__ = ["TrafficFlowEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
