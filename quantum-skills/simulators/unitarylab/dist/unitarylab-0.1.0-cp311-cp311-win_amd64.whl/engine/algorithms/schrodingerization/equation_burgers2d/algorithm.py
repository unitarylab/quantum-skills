"""
2D Burgers Equation Algorithm Module

Solve the 2D Burgers equation based on the Schrödingerization method:

∂u/∂t + u·∇u = ν∇²u
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm



# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


from .... import GateSequence
from ....library import parse_equation


# ==========================================================
# 方程运行函数

class Burgers2DEquationAlgorithm(BaseAlgorithm):
    """2D Burgers Equation Algorithm

    Solve the 2D Burgers equation based on the Schrödingerization method:

    ∂u/∂t + u·∇u = ν∇²u

    Supported boundary conditions:

    - Dirichlet boundary conditions

    - Periodic boundary conditions

    Supported solution methods:

    - Classical: Classical matrix exponentiation method

    - Trotter: Trotter decomposition method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the 2D Burgers equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 2D Burgers 方程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        elif method == 'trotter':
            return self._solve_trotter(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library import schro_classical as schro
        from ....library.differential_operator.classical_matrices import first_order_derivative, second_order_derivative
        from ....library.schrodingerization.classical import circuit_classical
        import scipy.sparse as sp

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        # derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        nu = eq.get_parameter('ν')

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)
        y = np.arange(dx, L, dx)
        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)
            y = np.arange(0, L, dx)
        u0 = f0(x[:,None], y[None,:])
        u0 = u0.flatten()

        self.logger.info(f"  - 扩散系数 ν = {nu}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始设置 level set 方法...")

        nl = eq.get_parameter('nl', 15)
        l_vec = np.linspace(-1,1,nl)
        if eq.initial.type in ['gaussian', 'discontinuous']:
            nl = 20
            l_vec = np.linspace(0.0001, 1, nl)
        dl = 1/(nl-1)
        v=0
        v_norm=0

        self.logger.info("阶段 2/5: level set 方法设置完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()

        nn=0
        for l in l_vec:
            if scheme == 'upwind':
                if l > 0:
                    scheme = 'forward'       
                else:
                    scheme = 'backward'           
            A0, b0 = first_order_derivative(N=Nx, dx=dx, boundary_condition=bd, scheme=scheme)
            A1, b1 = second_order_derivative(N=Nx, dx=dx, boundary_condition=bd)

            A = sp.kron(A0.T, sp.eye(Nx)) * l + sp.kron(A1, sp.eye(Nx)) * nu + sp.kron(sp.eye(Nx), A0.T) * l + sp.kron(sp.eye(Nx), A1) * nu
            b = sp.kron(b0, np.ones(Nx)) * l + sp.kron(b1, np.ones(Nx)) * nu + sp.kron( np.ones(Nx), b0) * l + sp.kron(np.ones(Nx), b1) * nu
            
            dim = u0.shape[0]
            phi=l*np.ones(u0.size)-u0
            w = 0.1
            # the numerical simulation of Delta function,which \beta(x/w)=1/(2w)(1+cos(pi*x/w))
            psi=np.where(abs(phi) > w,0,(1/w/2)*(1+np.cos(np.pi*phi/w)) )
            u_l = schro(A=A, u0=psi, T=T, R=R, na=na, order=order, point=point)
            u_l = u_l[:dim]
            v=v+l*u_l*dl
            v_norm =v_norm+u_l*dl

            if scheme=='backward' or scheme=='forward':
                scheme = 'upwind'
            nn=nn+1
        u=v/v_norm
        u = u.reshape((Nx, Nx))

        qc = circuit_classical(nx, na, dim=2)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"2D Burgers Classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, y, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "2D Burgers equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "y": y.tolist() if hasattr(y, 'tolist') else y,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_trotter(self, eq):
        from ....library import schro_trotter as schro
        from ....library import TDiff

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        nu = eq.get_parameter('ν')
        dt = eq.solver.dt
        Nt = int(T / dt)

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)
        y = np.arange(dx, L, dx)
        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)
            y = np.arange(0, L, dx)
        u0 = f0(x[:,None], y[None,:])
        u0 = u0.flatten()

        self.logger.info(f"  - 扩散系数 ν = {nu}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建level set ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始设置 level set 方法...")

        b = source(x) * T if T > 1 else source(x)
        nl = eq.get_parameter('nl', 15)
        l_vec = np.linspace(-1,1, nl)
        dl = 1/(nl-1)
        if eq.initial.type in ['gaussian']:
            nl = 10
            l_vec = np.linspace(0, 1, nl)
            dl = 1/(nl-1)

        func1 = TDiff(n=nx, dx=dx, order=2, boundary=bd).data()[0]
        func2 = TDiff(n=nx, dx=dx, order=1, boundary=bd).data()[1]

        self.logger.info(f"  - 积分层级数 nl = {nl}")
        self.logger.info("阶段 2/5: level set 方法设置完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始执行量子电路...")
        self.logger.info(f"  - 总时间步数: {Nt}")

        start_time = time.time()
    
        v = 0
        v_norm = 0
        for l in l_vec:
            phi=l*np.ones(u0.size)-u0
            w = 0.1
            # the numerical simulation of Delta function,which \beta(x/w)=1/(2w)(1+cos(pi*x/w))
            psi=np.where(abs(phi) > w,0,(1/w/2)*(1+np.cos(np.pi*phi/w)) )

            D1 = func1((-abs(l) * dx / 2 + nu ) * dt / R)
            H1 = GateSequence(2*nx)
            H1.append(D1, range(nx))
            H1.append(D1, range(nx, 2*nx))

            D2 = func2(-l * dt) # H2
            H2 = GateSequence(2*nx)
            H2.append(D2, range(nx))
            H2.append(D2, range(nx, 2*nx))
            u_l, qc = schro(u0=psi, H1=H1, H2=H2, R=R, na=na, Nt=Nt, order=order, point=point)
            v=v+l*u_l*dl
            v_norm =v_norm+u_l*dl
        u=v/v_norm

        end_time = time.time()

        u = u.reshape((Nx, Nx))

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"2D Burgers Lie-Trotter nx={nx} na={na} T={T} dt={dt}"
        solution_plot_path = self._generate_solution_plot(name, x, y, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc, H1, H2)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "2D Burgers equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dt": dt, "nt": Nt},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "y": y.tolist() if hasattr(y, 'tolist') else y,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        y,
        u,
        format: str = 'svg'
    ) -> str:
        """
        Generate the computational results graph and save it to the algorithm folder.

        :param x: Spatial grid point

        :param y: Spatial grid point

        :param u: Final solution

        :param name: Graph title

        :return: Saved filename (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 8), dpi=100, subplot_kw={'projection': '3d'})

        # 绘制解的等高线图
        X, Y = np.meshgrid(x, y)
        contour = ax.plot_surface(X, Y, u, cmap='viridis')
        plt.colorbar(contour, ax=ax, label='u(x, y, t)')

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("y", fontsize=12)
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
       Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files


if __name__ == "__main__":
    result = Burgers2DEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
