"""
Variable Coefficient Heat Equation Algorithm Module

Solve the one-dimensional variable coefficient heat equation based on the Schrödingerization method:

∂u/∂t = ∂/∂x (a(x) * ∂u/∂x)
"""
from .algorithm import HeatVariableCoefficientEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "heatVariableCoefficient"
# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = HeatVariableCoefficientEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维变系数热方程"

__all__ = ["HeatVariableCoefficientEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]