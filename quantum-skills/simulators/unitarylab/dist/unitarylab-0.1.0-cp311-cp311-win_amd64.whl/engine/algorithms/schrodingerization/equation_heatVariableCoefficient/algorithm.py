"""
Variable Coefficient Heat Equation Algorithm Module

Solve the one-dimensional variable coefficient heat equation based on the Schrödingerization method:

∂u/∂t = ∂/∂x (a(x) * ∂u/∂x)
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys
import numpy as np
from ..algo_base import BaseAlgorithm

# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from engine import GateSequence
from engine.library import parse_equation


# ==========================================================
# 方程运行函数

class HeatVariableCoefficientEquationAlgorithm(BaseAlgorithm):
    """Algorithm for Variable Coefficient Heat Equation

    Solve the one-dimensional variable coefficient heat equation based on the Schrödingerization method:

    ∂u/∂t = ∂/∂x (a(x) * ∂u/∂x)

    Supported boundary conditions:

        - Dirichlet boundary conditions: u(0,t) = 0, u(L,t) = 0

        - Periodic boundary conditions: u(0,t) = u(L,t)

    Supported solution methods:

        - Classical: Classical matrix exponentiation method

        - Block: Block coding method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the algorithm to solve the heat equation

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析变系数热方程参数...")
        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        elif method == 'trotter':
            return ValueError(f'method {method} is not supported yet!')
        elif method == 'block':
            return self._solve_block(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from engine.library import schro_classical as schro
        from engine.library.schrodingerization.classical import generate_compact_p_2_normal
        from engine.library import CDiff
        from engine.library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        # derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)
        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)
        elif bd == "neumann":
            dx = L / (Nx - 1)
            x = np.arange(0, L + dx, dx)
        u0 = f0(x)

        self.logger.info(f"  - 扩散系数 a(x) = 1 + cos(2πx/L)")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")
        p2_matrix = generate_compact_p_2_normal(nx, 0, L)
        ax = 1 + np.cos(2 * np.pi * x / L)
        ax_matrix = np.diag(ax)
        A = ax_matrix @ p2_matrix
        # b = eq.get_rhs_1d(Nx, dx, scheme=scheme) + source(x)
        b = source(x)

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point, b=b)
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Heat Variable Coefficient Classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Heat Variable Coefficient equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,  # 返回多个电路图数组
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    
    def _solve_block(self, eq):
        self.logger.info('Block encoding will be supported soon! Now falling back to classical method!')
        return self._solve_classical(eq)

    def _generate_solution_plot(
        self,
        name: str,
        x,
        u,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param u: Temperature distribution at the final moment

        :param name: Graph title

        :return: Filename to save the graph (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制温度分布曲线
        ax.plot(x, u, "b-", linewidth=2, label=f"u")
        ax.fill_between(x, u, alpha=0.3)

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("u(x, t)", fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files
