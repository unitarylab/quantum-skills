"""
Multiscale Elliptic Equation Algorithm Module

Solve one-dimensional multiscale elliptic equations based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from scipy.integrate import quad
from ..algo_base import BaseAlgorithm

# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from engine import GateSequence
from engine.library import parse_equation


# ==========================================================
# 方程运行函数

class MultiEllipticEquationAlgorithm(BaseAlgorithm):
    """Multi-scale Elliptic Equation Algorithm

    Solving one-dimensional multi-scale elliptic equations based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the multi-scale elliptic equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析多尺度椭圆方程参数...")
        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from engine.library import schro_classical as schro
        from engine.library.schrodingerization.classical import circuit_classical
        import scipy.sparse as sp
        from scipy.integrate import quad


        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        ic = eq.initial.type

        Nx = 2**nx - 1
        dx = L / 2**nx
        x = np.arange(dx, L, step=dx)
        epsilon = eq.get_parameter('ε', 2**-6)

        def A_epsilon(x):
            return 1 / (2 + np.cos(2 * np.pi * x / epsilon / L))

        def A_y(y):
            return 1 / (2 + np.cos(2 * np.pi * y / L))

        # forcing term
        def f(x):
            return np.ones_like(x)

        def sparse_csc(data, row, col, dim):
            if isinstance(data, (int, float)):
                data = data * np.ones_like(row)
            return sp.csc_matrix((data, (row, col)), shape=[dim, dim])

        def triangle_csc(a, b, c, N=None):
            if isinstance(a, (int, float)):
                if N is None:
                    raise ValueError('Please specify the dimension!')
                a = a * np.ones(N)
                b = b * np.ones(N-1)
                c = c * np.ones(N-1)
            N = a.shape[0]
            return sparse_csc(a, range(N), range(N), N) + sparse_csc(b, range(N-1), range(1, N), N) + sparse_csc(c, range(1, N), range(N-1), N)

        # add boundary 0 to extend the solution
        def ext0(u):
            if len(u.shape) > 1:
                v = np.zeros((u.shape[0]+2, u.shape[1]+2))
                v[1:-1, 1:-1] = u[:, :]
            else:
                v = np.zeros(u.shape[0]+2)
                v[1:-1] = u[:]
            return v

        # obtain u_0(x) from u0
        def get_u0(u0, x, L=L):
            # u0(x)
            N = u0.shape[0]
            h = L / (N-1)

            xind = np.int64(x // h)
            ans = u0[xind] + (x - xind * h) * (u0[xind+1] - u0[xind]) / h
            return ans

        # obtain u_1(x) from u1
        def get_u1(u1, x, L):
            # u1(x, x/epsilon)

            N = u1.shape[0]
            h = L / (N-1)
            y = (x / epsilon) % L
            xind = np.int64(x // h)
            yind = np.int64(y // h)

            t1 = u1[xind, yind] + (x - xind * h) * (u1[xind+1, yind] - u1[xind, yind]) / h
            t2 = u1[xind, yind+1] + (x - xind * h) * (u1[xind+1, yind+1] - u1[xind, yind+1]) / h
            ans = t1 + (y - yind * h) * (t2 - t1) / h
            return ans

        # finite element approximation on equi-distant grid
        def fem(k, A=A_epsilon, f=f, L=L):
            # finte element grid
            N = 1 + 2**k # number of grid points
            h = L / (N-1) # mesh size
            x = np.arange(0, L+h, step=h)
            Amean = np.zeros(N-1)
            # stiffness matrix
            for j in range(N-1):
                Amean[j] = quad(A, x[j],x[j+1])[0] / h

            rhs = h * f(x[1:-1])
            S = triangle_csc(Amean[:-1] + Amean[1:], - Amean[1:-1], -Amean[1:-1])
            S = S / h
            return S, rhs

            # uk = solve(S, rhs)
            # uk = ext0(uk)
            # return x, uk

        # homogenized model
        def multiFEM(k, A=A_y, L=L):
            N = 1 + 2**k
            h = L / (N-1)
            x = np.arange(0, L+h, step=h)
            Amean = np.zeros(N-1)
            for j in range(N-1):
                Amean[j] = quad(A, x[j],x[j+1])[0] / h

            # stiffness matrix
            # left top block 
            A0 = triangle_csc(Amean[:-1] + Amean[1:], - Amean[1:-1], -Amean[1:-1])
            A0 = A0 / h
            M = triangle_csc(4, 1, 1, N-2) / 6
            left_top = sp.kron(M, A0)

            # left bottom block
            B0 = sparse_csc(1, range(1, N-2), range(N-3), N-2) - sparse_csc(1, range(N-3), range(1, N-2), N-2)
            B0 = B0 / 2 / np.sqrt(h)
            left_bottom = sp.kron(B0, Amean[:-1] - Amean[1:])

            # right bottom block
            K = triangle_csc(2, -1, -1, N-2) * np.sum(Amean)

            left = sp.vstack([left_top, left_bottom])
            right = sp.vstack([left_bottom.T, K])
            S = sp.hstack([left, right])
            S = sp.csc_matrix(S)
            
            rhs = np.zeros(S.shape[0])
            rhs[-N+2:] = h
            return S, rhs

            # uk = solve(S, rhs)
            # u1 = uk[:-N+2].reshape((N-2, N-2)) / np.sqrt(h)
            # u0 = uk[-N+2:]

            # return u1, u0
        

        self.logger.info(f"  - 小尺度参数 ε = {epsilon}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        hamiltonian_type = eq.preprocessing.type
        if hamiltonian_type == 'homogenization':
            S, rhs = multiFEM(nx, A_y, L)
        else:
            S, rhs = fem(nx, A_epsilon, f, L)

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        print(S)
        start_time = time.time()
        u = schro(-S, np.zeros_like(rhs), na=na, R=R, T=10, order=order, point=point, b=rhs, scale_b=1)
        if hamiltonian_type == 'homogenization':
            u1, u0 = u[:-Nx].reshape(Nx, Nx) * 2**(nx/2), u[-Nx:]
            u0 = ext0(u0)
            u1 = ext0(u1)

            sample_points = 2**(nx+2)
            x = np.linspace(0, 1 - 1/sample_points, sample_points)
            u0 = get_u0(u0, x)
            u1 = get_u1(u1, x, L=L)
            u_list = [u0, u1]
            label = ['$u_0$', '$u_1$']
        else:
            u_list = [u]
            label = ['$u$']
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Multiscale elliptic classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, u_list, label)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Multiscale elliptic equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u_list": [u.tolist() if hasattr(u, 'tolist') else u for u in u_list],
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        u_list,
        label,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation result graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param u_list: Solution list

        :param label: Label list

        :param name: Graph title

        :return: Filename to save the graph (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制解
        colors = ['b', 'r', 'g', 'm', 'c']
        for i, (u, lbl) in enumerate(zip(u_list, label)):
            ax.plot(x, u, colors[i % len(colors)] + "-", linewidth=2, label=f"{lbl}")

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("u(x)", fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files

    def _pre_processing(self, A, u0, b=None, scale_b=None):
        """Preprocessing functions"""
        from scipy.sparse import csc_matrix
        A = csc_matrix(A)
        dim = u0.shape[0]
        if b is not None and scale_b is not None:
            b = b * scale_b
        return dim, A, u0
