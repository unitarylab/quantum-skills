"""
Ornstein-Uhlenbeck Process (OU Process) Algorithm Module

Solve the Ornstein-Uhlenbeck process based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm



# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from .... import GateSequence
from ....library import parse_equation


# ==========================================================
# 方程运行函数

class OUProcessEquationAlgorithm(BaseAlgorithm):
    """Ornstein-Uhlenbeck Procedure Algorithm

    Solve the Ornstein-Uhlenbeck procedure based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the Ornstein-Uhlenbeck process algorithm.

        :param params: JSON string parameters containing equation configuration and solution method configuration.

        :return: Algorithm execution result.
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 OU 过程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        a = eq.get_parameter('a')
        r = eq.get_parameter('r')
        dt = eq.discrete.get_parameter('dt', 0.001)
        x0 = eq.initial.get_parameter('x0', 1.0)

        NT = int(T / dt)
        N = 2**(na - 1)
        L = -R * np.pi
        R = R * np.pi
        M = 2 * N
        dp = (R - L) / M

        eps = 1.0
        p_start = point
        t = np.linspace(0, T, NT + 1)
        x1 = 1 / (np.sqrt(dt) * eps)

        self.logger.info(f"  - 均值回归系数 a = {a}")
        self.logger.info(f"  - 波动率 r = {r}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        p = np.arange(L, R, dp)

        exp_p = np.zeros(M)
        exp_p[:N] = np.exp(-np.abs(p[:N]))
        exp_p[N:] = np.exp(-np.abs(p[N:]))

        v0 = np.ones(2 * M)
        v0[0::2] = exp_p * x0
        v0[1::2] = exp_p * x1

        k_mu = np.arange(M)
        mu = 2 * np.pi * (k_mu - N) / (R - L)
        from scipy.sparse import diags
        Du = diags(mu)

        xi_BM = np.random.randn(NT)
        xi_scale = eps * r * xi_BM
        xi = r * xi_BM / np.sqrt(dt)

        A = np.ones(2 * M)
        A[2::4] = -1
        A[3::4] = -1

        c0 = A * v0
        c0[0::2] = np.fft.fft(c0[0::2])
        c0[1::2] = np.fft.fft(c0[1::2])
        c0 = c0 / M

        c = np.zeros((2 * M, NT + 1), dtype=np.complex128)
        c[:, 0] = c0
        h = dt

        from scipy.sparse import identity
        Id = identity(M, format='csr')
        Id_2M = identity(2 * M, format='csr')

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        for i in range(NT):
            H_1k = np.array([[a, xi_scale[i] / 2.0],
                                [xi_scale[i] / 2.0, 0]])
            H_2k = np.array([[0, -1j * xi_scale[i] / 2.0],
                                [1j * xi_scale[i] / 2.0, 0]])

            H_k = -1j * (np.kron(Du.toarray(), H_1k) - np.kron(Id.toarray(), H_2k))

            LHS_op = Id_2M.toarray() - (h / 2) * H_k
            RHS_vec = (Id_2M.toarray() + (h / 2) * H_k) @ c[:, i]

            c[:, i + 1] = np.linalg.solve(LHS_op, RHS_vec)

        v = np.zeros_like(c, dtype=np.complex128)
        v_odd_rows = M * np.fft.ifft(c[0::2, :], axis=0)
        v_even_rows = M * np.fft.ifft(c[1::2, :], axis=0)
        v[0::2, :] = v_odd_rows
        v[1::2, :] = v_even_rows
        v = A[:, np.newaxis] * v

        v_wave = v[0::2, :]

        np_val = np.floor(p_start / dp)
        n_start = N + int(np_val)
        n_end = M
        pp = np.sum(np.real(v_wave[n_start:n_end, :]), axis=0)
        zz = np.sum(np.exp(-p[n_start:n_end])) * dp
        y_int = (pp * dp) / zz
        y_int = np.real(y_int)

        y_em = np.zeros(NT + 1)
        y_em[0] = x0
        for k in range(NT):
            y_em[k + 1] = (1 + a * dt) * y_em[k] + xi[k] * dt

        y_expli = np.zeros(NT + 1)
        y_expli[0] = x0
        for k in range(NT):
            y_expli[k + 1] = np.exp(a * dt) * y_expli[k] + (np.exp(a * dt) - 1) / a * xi[k]
        y_expli = np.real(y_expli)

        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D OU process classical dt={dt} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, t, y_int, y_expli)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "OU process solved",
            "grid": {"n_points": 2**nx, "dt": dt},
            "t": t.tolist() if hasattr(t, 'tolist') else t,
            "y_int": y_int.tolist() if hasattr(y_int, 'tolist') else y_int,
            "y_expli": y_expli.tolist() if hasattr(y_expli, 'tolist') else y_expli,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        t,
        y_int,
        y_expli,
        format: str = 'svg'
    ) -> str:
        """
        Generate a graph of the computational results and save it to the algorithm folder.

        :param t: Time grid points

        :param y_int: Schrödinger solution

        :param y_expli: Explicit solution

        :param name: Graph title

        :return: Filename to save (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制解
        ax.plot(t, y_int, "b-", linewidth=2, label=f"X_t (Schro)")
        ax.plot(t, y_expli, "r--", linewidth=1.5, label=f"X_t (explicit)")
        ax.fill_between(t, y_int, alpha=0.3)

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("t", fontsize=12)
        ax.set_ylabel("X_t", fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files


if __name__ == "__main__":
    result = OUProcessEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
