"""
Multiscale Transport Equation Algorithm Module

Solve one-dimensional multiscale transport equations based on the Schrödingerization method.
"""
from .algorithm import MultiTransportEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "multiTransport"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = MultiTransportEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维多尺度输运方程"

__all__ = ["MultiTransportEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
