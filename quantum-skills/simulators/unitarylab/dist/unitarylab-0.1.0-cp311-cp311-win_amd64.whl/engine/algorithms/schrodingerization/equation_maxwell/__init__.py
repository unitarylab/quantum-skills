"""
Maxwell Equation Algorithm Module

Solve one-dimensional Maxwell equations based on the Schrödingerization method.
"""
from .algorithm import MaxwellEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "maxwell"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = MaxwellEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维 Maxwell 方程"

__all__ = ["MaxwellEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
