"""
Maxwell Equation Algorithm Module

Solve one-dimensional Maxwell equations based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys
import numpy as np
from ..algo_base import BaseAlgorithm


# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from .... import GateSequence
from ....library import parse_equation


# ==========================================================
# 方程运行函数

class MaxwellEquationAlgorithm(BaseAlgorithm):
    """Maxwell Equation Algorithm

    Solve one-dimensional Maxwell equations based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the Maxwell equations solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 Maxwell 方程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library.schrodingerization.classical import schro_classical_dependent_b as schro
        from ....library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        v = eq.get_parameter('v', 1.0)
        E0fun = eq.initial.get_parameter('E0(x)')
        B0fun = eq.initial.get_parameter('B0(x)')

        Nx = 2**nx
        xM = L / 3
        tEnd = T
        dt = min(L / 2 * Nx / v, 0.005)

        E_exact = lambda t, x: np.cos(2*np.pi*x/xM)/(2*np.pi/xM) - 1/(2*np.pi/xM)
        B_exact = lambda t, x: t * np.sin(2*np.pi*x/xM)
        J_exact = lambda t, x: -(2*np.pi/xM) * t * np.cos(2*np.pi*x/xM)
        Jfun = J_exact

        self.logger.info(f"  - 波速 v = {v}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        from scipy.sparse import lil_matrix, eye, hstack, vstack, csc_matrix

        if bd == 'impedance':
            Mx = Nx - 1
            dx = L / Mx
            xE = np.arange(0, Mx + 1) * dx
            xB = (np.arange(1, Mx + 2) - 0.5) * dx
            alpha = v / dx

            Ne = Mx + 1
            Nb = Mx + 1

            E_block = lil_matrix((Ne, Ne))
            EB_block = lil_matrix((Ne, Nb))
            BE_block = lil_matrix((Nb, Ne))
            B_block = lil_matrix((Nb, Nb))

            i = np.arange(1, Mx)
            EB_block[i, i] = -alpha
            EB_block[i, i - 1] = alpha

            E_block[0, 0] = -2.0 / dx
            EB_block[0, 0] = -2.0 * alpha

            E_block[Ne - 1, Ne - 1] = -2.0 / dx
            EB_block[Ne - 1, Mx - 1] = 2.0 * alpha

            j = np.arange(Mx)
            BE_block[j, j] = alpha
            BE_block[j, j + 1] = -alpha

            A = vstack([
                hstack([E_block, EB_block]),
                hstack([BE_block, B_block])
            ])

            E0 = E0fun(xE)
            B0 = B0fun(xB)
            u = np.concatenate([E0, B0])
            u[-1] = 0.0
        else:
            Mx = Nx
            dx = L / Mx
            xE = np.arange(0, Mx) * dx
            xB = (np.arange(1, Mx + 1) - 0.5) * dx
            alpha = v / dx

            D_B = lil_matrix((Mx, Mx))

            for i in range(1, Mx):
                D_B[i, i - 1] = -1.0
                D_B[i, i] = 1.0

            Dx = -alpha * D_B

            E_block = lil_matrix((Mx, Mx))
            B_block = lil_matrix((Mx, Mx))
            EB_block = Dx
            BE_block = -Dx.T

            A = vstack([
                hstack([E_block, EB_block]),
                hstack([BE_block, B_block])
            ])

            E0 = E0fun(xE)
            B0 = B0fun(xB)
            u = np.concatenate([E0, B0])
            u[0] = 0.0

        n = len(u)
        I = eye(n)
        LHS = I - 0.5 * dt * A
        RHS = I + 0.5 * dt * A

        lu = csc_matrix(LHS)

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        t = 0.0
        Nt = int(np.ceil(tEnd / dt))
        bE = np.zeros((len(xE) + Nx, Nt))
        for n in range(Nt):
            bE[:len(xE), n] = -Jfun(t, xE)
            if bd != 'impedance':
                bE[0, n] = 0.0
            t += dt

        u = schro(A, u, bE, T=T, R=R, na=na, order=order, point=point, scale=1e-3)

        E = u[:len(xE)]
        B = u[len(xE):]

        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Reduced Maxwell classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, xE, E, B)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Maxwell equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": xE.tolist() if hasattr(xE, 'tolist') else xE,
            "E": E.tolist() if hasattr(E, 'tolist') else E,
            "B": B.tolist() if hasattr(B, 'tolist') else B,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        E,
        B,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param E_num: Numerical solution for the electric field

        :param B_num: Numerical solution for the magnetic field

        :param E_shcor: Schrödinger solution for the electric field

        :param B_shcor: Schrödinger solution for the magnetic field

        :param name: Graph title

        :return: Filename to save (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), dpi=100)

        # 绘制电场
        ax1.plot(x, E, "r--", linewidth=1.5, label=f"E (Schro)")
        ax1.fill_between(x, E, alpha=0.3)
        ax1.set_title(f"{name} - Electric Field", fontsize=14)
        ax1.set_xlabel("x", fontsize=12)
        ax1.set_ylabel("E(x)", fontsize=12)
        ax1.legend(loc="upper right")
        ax1.grid(True, alpha=0.3)

        # 绘制磁场
        ax2.plot(x, B, "r--", linewidth=1.5, label=f"B (Schro)")
        ax2.fill_between(x, B, alpha=0.3)
        ax2.set_title(f"{name} - Magnetic Field", fontsize=14)
        ax2.set_xlabel("x", fontsize=12)
        ax2.set_ylabel("B(x)", fontsize=12)
        ax2.legend(loc="upper right")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files


if __name__ == "__main__":
    result = MaxwellEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
