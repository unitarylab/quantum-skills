"""
Schrödinger ABC Equation Algorithm Module

Solves two-dimensional Schrödinger equations with artificial boundaries based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm



# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包

from .... import GateSequence
from ....library import parse_equation


# ==========================================================
# 方程运行函数

class SchrABCEquationAlgorithm(BaseAlgorithm):
    """Schrödinger ABC Equation Algorithm

    Solve 2D Schrödinger equations with artificial boundaries based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the Schrödinger ABC equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 Schrödinger ABC 方程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library import schro_classical as schro
        from ....library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        rcut = eq.boundary.get_parameter('b', 2.2)
        amplitude = eq.boundary.get_parameter('a', 10)

        Nx = 2**nx
        dx = 2 * L / Nx
        x = np.linspace(-L + dx/2, L - dx/2, Nx)
        y = np.linspace(-L + dx/2, L - dx/2, Nx)
        X, Y = np.meshgrid(x, y, indexing='ij')
        r = np.sqrt(X**2 + Y**2)

        psi0 = np.zeros((Nx, Nx), dtype=complex)
        V = np.zeros((Nx, Nx))
        sigma = np.zeros((Nx, Nx))

        r_mask = r <= 1
        x_mask = np.abs(X) > rcut
        y_mask = np.abs(Y) > rcut

        V[r_mask] = np.sin(2 * np.pi * r[r_mask])
        psi0[r_mask] = f0(r[r_mask])

        sigma[x_mask] += amplitude * (np.abs(X[x_mask]) - rcut)**2
        sigma[y_mask] += amplitude * (np.abs(Y[y_mask]) - rcut)**2
        V = V.flatten()
        sigma = sigma.flatten()
        psi0 = psi0.flatten()

        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info(f"  - 人工边界参数 rcut = {rcut}")
        self.logger.info(f"  - 吸收势幅度 amplitude = {amplitude}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        from scipy.sparse import diags, eye, kron
        main_diag = -2 * np.ones(Nx)
        off_diag = np.ones(Nx-1)
        D = diags([off_diag, main_diag, off_diag], [-1, 0, 1], shape=(Nx, Nx), format='csr')
        I = eye(Nx, format='csr')

        Z_mat = kron(D, I) + kron(I, D)

        H0 = Z_mat / (2 * dx**2) - diags(V, 0, format='csr')
        H1 = diags(sigma, 0, format='csr')

        A = H0 * 1j - H1
        u0 = psi0

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point)
        u = u.reshape(Nx, Nx)
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"2D Schrödinger with artificial boundary, classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, y, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Schrödinger ABC equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "y": y.tolist() if hasattr(y, 'tolist') else y,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        y,
        u,
        format: str = 'svg'
    ) -> str:
        """
        Generate the computational results graph and save it to the algorithm folder.

        :param x: Spatial grid point

        :param y: Spatial grid point

        :param u: Final solution

        :param name: Graph title

        :return: Saved filename (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 8), dpi=100, subplot_kw={'projection': '3d'})

        # 绘制解的等高线图
        X, Y = np.meshgrid(x, y)
        contour = ax.plot_surface(X, Y, u, cmap='viridis')
        plt.colorbar(contour, ax=ax, label='|ψ(x, y, t)|')

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("y", fontsize=12)
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files

    def _pre_processing(self, A, u0, b=None):
        """Preprocessing functions"""
        from scipy.sparse import csc_matrix
        A = csc_matrix(A)
        dim = u0.shape[0]
        return dim, A, u0


if __name__ == "__main__":
    result = SchrABCEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
