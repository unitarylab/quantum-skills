"""
Backward Heat Equation Algorithm Module

Solve the one-dimensional backward heat equation based on the Schrödingerization method.
"""
from .algorithm import backHeatEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "backHeat"
# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = backHeatEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维 backward heat 方程"

__all__ = ["backHeatEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]