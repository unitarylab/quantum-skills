"""
2D Burgers Equation Algorithm Module

Solve the 2D Burgers equation based on the Schrödingerization method:

∂u/∂t + u·∇u = ν∇²u
"""
from .algorithm import Burgers2DEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "burgers2d"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = Burgers2DEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解二维 Burgers 方程"

__all__ = ["Burgers2DEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
