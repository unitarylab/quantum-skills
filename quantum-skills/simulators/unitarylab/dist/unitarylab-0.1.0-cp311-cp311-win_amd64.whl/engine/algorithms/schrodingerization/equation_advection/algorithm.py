"""
Advection Equation Algorithm Module

Solve the one-dimensional advection equation based on the Schrödingerization method:

∂u/∂t + a * ∂u/∂x = 0
"""

from typing import Dict, Any, Optional
import time
import os
import sys
import numpy as np

from ..algo_base import BaseAlgorithm
    

# 使用非交互式后端
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from engine import GateSequence
from engine.library import parse_equation

# ==========================
# 主算法类
# ==========================

class AdvectionEquationAlgorithm(BaseAlgorithm):
    """
    Algorithm for Advection Equation

    ∂u/∂t + a ∂u/∂x = 0
    """
    # ==========================================================
    # 主入口
    # ==========================================================

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:

        
        """
        Execute the algorithm to solve the advection equations

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """

        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析平流方程参数...")

        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e
        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type

        if method == 'classical':
            return self._solve_classical(eq)
        elif method == 'trotter':
            return self._solve_trotter(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    # ==========================================================
    # Classical 求解
    # ==========================================================

    def _solve_classical(self, eq):

        from engine.library import schro_classical as schro
        from engine.library.schrodingerization.classical import circuit_classical
        from engine.library.differential_operator.classical_matrices import first_order_derivative
        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        a = eq.get_parameter('a')

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)

        if bd == 'periodic':
            dx = L / Nx
            x = np.arange(0, L, dx)

        u0 = f0(x)

        self.logger.info(f"  - 平流速度 a = {a}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")
        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        if scheme == "upwind":
            scheme = "forward" if a >= 0 else "backward"

        A0, b0 = first_order_derivative(N=Nx, dx=dx, boundary_condition=bd, scheme=scheme, g1=eq.boundary.left_value, g2=eq.boundary.right_value)

        A = A0 * a
        b = b0 * a

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")
        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point, b=b)
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")
        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解图...")

        name = f"1D_Advection_Classical_nx={nx}_na={na}_T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, u)

        self.logger.info("阶段 4/5: 解图生成完成 ✓")
        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)
        
        self.logger.info("阶段 5/5: 电路图生成完成 ✓")
        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")

        return {
            "status": "ok",
            "message": "Advection equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    # ==========================================================
    # Trotter 求解
    # ==========================================================

    def _solve_trotter(self, eq):

        from engine.library import schro_trotter as schro
        from engine.library import TDiff
        from engine.library.differential_operator.classical_matrices import first_order_derivative as first_order_derivative_classical
        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        a = eq.get_parameter('a')

        dt = eq.solver.dt
        Nt = int(T / dt)

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)

        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)

        u0 = f0(x)

        self.logger.info(f"  - 平流速度 a = {a}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")
        # ========== 阶段2: 构建量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建量子电路...")
        A0, b0 = first_order_derivative_classical(N=Nx, dx=dx, boundary_condition=bd, scheme=scheme, g1=eq.boundary.left_value, g2=eq.boundary.right_value)

        b = b0 * a
        b = b * T if T > 1 else b
        theta = 1 / T if T > 1 else 1
        if scheme == 'upwind':
            func1 = (abs(a) * TDiff(nx, dx, 2, boundary=bd)).data()[0]
            H1 = func1(dt / R)
        elif scheme == 'central':
            func1 = None
            H1 = None
        func2 = (a * TDiff(nx, dx, 1, boundary=bd)).data()[1]
        H2 = func2(dt)

        self.logger.info("阶段 2/5: 量子电路构建完成 ✓")
        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始执行量子电路...")
        self.logger.info(f"  - 总时间步数: {Nt}")

        start_time = time.time()
        u, qc = schro(u0=u0, H1=H1, H2=H2, Nt=Nt, na=na, R=R, order=order, point=point, b=b, theta=theta * dt)
        end_time = time.time()
        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        # self.logger.info(f"计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Advection Lie-Trotter nx={nx} na={na} T={T} dt={dt}"
        solution_plot_path = self._generate_solution_plot(name, x, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")
        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")
        circuit_plot_paths = self._generate_circuit_plots(name, qc)
        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")
        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Advection equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dt": dt, "nt": Nt},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    # ==========================================================
    # 生成解图
    # ==========================================================

    def _generate_solution_plot(self,
        name: str,
        x,
        u,
        format: str = 'svg'
    ) -> str:
        """
        Generate the computational results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param u: Final solution

        :param name: Graph title

        :return: Filename to save the graph (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))

        # # 创建图像
        # fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # # 绘制解曲线
        # ax.plot(x, u, "b-", linewidth=2, label=f"u")
        # ax.fill_between(x, u, alpha=0.3)

        # # 设置标题和标签
        # ax.set_title(f"{name}", fontsize=14)
        # ax.set_xlabel("x", fontsize=12)
        # ax.set_ylabel("u(x, t)", fontsize=12)
        # ax.legend(loc="upper right")
        # ax.grid(True, alpha=0.3)

        # # 将图像保存到算法文件夹
        # filename = f'{name.replace(" ", "_")}_solution.{format}'
        # fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # # 清理资源
        # plt.close(fig)
        safe_name = name.replace(" ", "_")
        filename = f"{safe_name}_solution.{format}"
        solution_path = os.path.join(algo_dir, filename)
        self.logger.debug(f"计算结果图已保存到: {solution_path}")
        # 返回文件名（相对路径）    
        return filename

    # ==========================================================
    # 生成电路图
    # ==========================================================

    def _generate_circuit_plots(self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录

        algo_dir = os.path.dirname(os.path.abspath(__file__))
        circuit_files = []
        base_name = name.replace(" ", "_")
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })

        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files