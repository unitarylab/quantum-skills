from abc import ABC, abstractmethod
from typing import Dict, Any, Optional
import json
import os
import numpy as np
import matplotlib.pyplot as plt
from ...core import GateSequence
from matplotlib.colors import LinearSegmentedColormap

class logger:
    def info(self, log):
        print('INFO: ', log)
    def debug(self, log):
        print('DEBUG: ', log)
    def error(self, log):
        print('ERROR: ', log)
        raise ValueError(f"Algorithm error: {log}")

class BaseAlgorithm(ABC):
    """The base class for all algorithm modules"""
    def __init__(self):
        self.logger = logger()
        
    @abstractmethod
    def run(self, params: str) -> Dict[str, Any]:
        """
        Execute the algorithm logic

        :param params: Input parameters, in JSON string format

        :return: Dictionary of the algorithm execution results
        """
        pass

    def parse_params(self, params: str) -> Any:
        """
        Parsing JSON string parameters

        :param params: JSON string

        :return: Parsed Python object

        :raises ValueError: Raised when JSON parsing fails
        """
        try:
            return json.loads(params)
        except json.JSONDecodeError as e:
            raise ValueError(f"Invalid JSON format: {str(e)}")

    def set_plt(self, color='white', font_num=2):
        plt.rcParams.update({
            "font.family": 'Times New Roman',
            # "font.size": 18 * font_num,           # 全局默认字体大小
            # "axes.titlesize": 20 * font_num,      # 标题字体大小
            # "axes.labelsize": 18 * font_num,      # 坐标轴标签字体大小
            # "xtick.labelsize": 16 * font_num,     # x轴刻度标签字体大小
            # "ytick.labelsize": 16 * font_num,     # y轴刻度标签字体大小
            # "legend.fontsize": 16 * font_num,     # 图例字体大小
        })
            
        plt.rcParams.update({
            "text.color": color,       # 标题、坐标轴标签等
            "axes.labelcolor": color,  # 坐标轴标签
            "axes.edgecolor": color,   # 坐标轴边框
            "xtick.color": color,      # x轴刻度标签
            "ytick.color": color,      # y轴刻度标签
        })

    def _plot_1d(
        self,
        ax,
        x,
        u,
        label = 'u'
    ):
        """
        Plot a graph on the input ax array

        :param ax: Matplotlib's axes object

        :param name: Graph title

        :param x: Spatial grid points

        :param u: Temperature distribution at the final time

        :param label: Label
        """

        # ax背景透明
        ax.set_facecolor('none')

        # 绘制结果
        ax.plot(x, u, '#1F52F0', linewidth=2, label=label)
        
        # 创建渐变填充效果
        self._add_gradient_fill(ax, x, u)

        # 设置标题和标签
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel(label, fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

    def _add_gradient_fill(self, ax, x, y, alpha_start=1, alpha_end=0.15):
        """
        Add a vertical gradient fill effect

        :param ax: matplotlib's axes object

        :param x: x-coordinate

        :param y: y-coordinate

        :param alpha_start: Starting opacity (at the curve)

        :param alpha_end: Ending opacity (at the bottom)
        """
        # 创建渐变色映射 - 从蓝色到透明（垂直方向）
        colors = [(0.1216, 0.3216, 0.9412, alpha_start), (0.1216, 0.3216, 0.9412, alpha_end)]
        cmap = LinearSegmentedColormap.from_list('gradient_fill', colors, N=256)
        
        # 获取坐标轴范围
        ymin, ymax = ax.get_ylim()
        xmin, xmax = ax.get_xlim()
        
        # 创建垂直渐变图像（从上到下：1->0，即从曲线处到底部）
        gradient = np.linspace(1, 0, 256).reshape(-1, 1)
        
        # 绘制渐变背景
        im = ax.imshow(gradient, aspect='auto', cmap=cmap, 
                      extent=[xmin, xmax, ymin, ymax], 
                      origin='lower', zorder=0)
        
        # 创建曲线路径用于裁剪
        from matplotlib.path import Path
        from matplotlib.patches import PathPatch
        
        # 创建闭合路径（从曲线到底部）
        vertices = [(x[0], 0)] + [(x[i], y[i]) for i in range(len(x))] + [(x[-1], 0)]
        codes = [Path.MOVETO] + [Path.LINETO] * (len(vertices) - 1)
        path = Path(vertices, codes)
        
        # 创建裁剪路径
        patch = PathPatch(path, facecolor='none', edgecolor='none', zorder=1)
        ax.add_patch(patch)
        
        # 将渐变图像裁剪到曲线下方
        im.set_clip_path(patch)

    def _generate_solution_plot_1d(
        self,
        name: str,
        x,
        u,
        algo_dir = './equation_results',
        label = 'u',
        refcolor='white',
        format: str = 'svg'
    ) -> str:
        """
        Generate a graph of the calculation results and save it to algo_dir.
        """

        if refcolor == 'black':
            color = 'white'
        else:
            color = 'black'

        self.set_plt(color)
        
        # 确保目录存在
        os.makedirs(algo_dir, exist_ok=True)
        filepath = os.path.join(algo_dir, f"{name.replace(' ', '_')}_solution.{format}")
        
        if isinstance(u, dict):
            solutions = u
        else:
            solutions = {label: u}

        num_solutions = len(solutions)
        if num_solutions == 1:
            fig, axes = plt.subplots(figsize=(10, 6), dpi=300)
            axes = [axes]
        else:
            fig, axes = plt.subplots(num_solutions, 1, figsize=(10, 6 * num_solutions), dpi=300)

        for idx, (label_key, u_value) in enumerate(solutions.items()):
            self._plot_1d(axes[idx], x, u_value, label_key)
        
        # 标题
        axes[0].set_title(name)
        fig.savefig(filepath, format=format, bbox_inches="tight", facecolor="none")
        plt.close(fig)

        return filepath

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        algo_dir = './equation_results',
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        return circuit_files
