"""
Hamilton-Jacobi Equation Algorithm Module

Solve the one-dimensional Hamilton-Jacobi equation based on the Schrödingerization method:

∂u/∂t + H(∇u, x) = 0
"""
from .algorithm import HamiltonJacobiEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "hamiltonjacobi"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = HamiltonJacobiEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维 Hamilton-Jacobi 方程"

__all__ = ["HamiltonJacobiEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
