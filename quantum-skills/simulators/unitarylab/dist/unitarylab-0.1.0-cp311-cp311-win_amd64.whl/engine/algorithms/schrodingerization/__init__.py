"""
Schrödingerization Module
=========================

This module provides quantum algorithms for solving partial differential equations (PDEs):
"""

from .equation_heat import HeatEquationAlgorithm
from .equation_advection import AdvectionEquationAlgorithm
from .equation_backHeat import backHeatEquationAlgorithm
from .equation_backHeat2d import backHeat2dEquationAlgorithm
from .equation_blackScholes import BlackScholesEquationAlgorithm
from .equation_burgers import BurgersEquationAlgorithm
from .equation_burgers2d import Burgers2DEquationAlgorithm
from .equation_elasticWave import ElasticWaveEquationAlgorithm
from .equation_elasticWave2d import ElasticWave2DEquationAlgorithm
from .equation_heat2d import Heat2dEquationAlgorithm
from .equation_heatVariableCoefficient import HeatVariableCoefficientEquationAlgorithm
from .equation_Helmholtz import HelmholtzEquationAlgorithm
from .equation_maxwell import MaxwellEquationAlgorithm
from .equation_multiElliptic import MultiEllipticEquationAlgorithm
from .equation_multiTransport import MultiTransportEquationAlgorithm
from .equation_OUprocess import OUProcessEquationAlgorithm
from .equation_SchrABC import SchrABCEquationAlgorithm
from .equation_traffic import TrafficFlowEquationAlgorithm
from .equation_hamiltonjacobi import HamiltonJacobiEquationAlgorithm



from .algo_base import BaseAlgorithm, logger

__all__ = [
    "HeatEquationAlgorithm",
    "AdvectionEquationAlgorithm",
    "backHeatEquationAlgorithm",
    "backHeat2dEquationAlgorithm",
    "BlackScholesEquationAlgorithm",
    "BurgersEquationAlgorithm",
    "Burgers2DEquationAlgorithm",
    "ElasticWaveEquationAlgorithm",
    "ElasticWave2DEquationAlgorithm",
    "Heat2dEquationAlgorithm",
    "HeatVariableCoefficientEquationAlgorithm",
    "HamiltonJacobiEquationAlgorithm",
    "HelmholtzEquationAlgorithm",
    "MaxwellEquationAlgorithm",
    "MultiEllipticEquationAlgorithm",
    "MultiTransportEquationAlgorithm",
    "OUProcessEquationAlgorithm",
    "SchrABCEquationAlgorithm",
    "TrafficFlowEquationAlgorithm",
    "BaseAlgorithm",
    "logger",
]