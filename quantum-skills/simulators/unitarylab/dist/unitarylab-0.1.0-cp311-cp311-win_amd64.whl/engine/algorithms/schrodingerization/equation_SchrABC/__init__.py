"""
Schrödinger ABC Equation Algorithm Module

Solves two-dimensional Schrödinger equations with artificial boundaries based on the Schrödingerization method.
"""
from .algorithm import SchrABCEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "SchrABC"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = SchrABCEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解带人工边界的二维 Schrödinger 方程"

__all__ = ["SchrABCEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
