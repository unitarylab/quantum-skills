"""
Multiscale Elliptic Equation Algorithm Module

Solve one-dimensional multiscale elliptic equations based on the Schrödingerization method.
"""
from .algorithm import MultiEllipticEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "multiElliptic"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = MultiEllipticEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维多尺度椭圆方程"

__all__ = ["MultiEllipticEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
