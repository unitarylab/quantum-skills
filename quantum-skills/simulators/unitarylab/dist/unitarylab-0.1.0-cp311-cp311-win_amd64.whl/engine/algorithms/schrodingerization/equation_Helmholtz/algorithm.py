"""
Helmholtz Equation Algorithm Module

Solve one-dimensional Helmholtz equations based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm

# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from .... import GateSequence
from ....library import parse_equation


# ==========================================================
# 方程运行函数

class HelmholtzEquationAlgorithm(BaseAlgorithm):
    """Helmholtz Equation Algorithm

    Solve one-dimensional Helmholtz equations based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the Helmholtz equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 Helmholtz 方程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library import schro_classical as schro
        from ....library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        k = eq.get_parameter('k')
        Decay_rate = 'default'
        pre = 'yes'
        source = lambda x: -np.sin(k * x)

        Nx = 2**nx
        dx = L / (Nx - 1)
        kap = k * dx

        if kap >= 1:
            self.logger.warning("Warning: The space step is too large, which may cause the method to fail.")

        x = np.linspace(0, L, Nx)

        self.logger.info(f"  - 波数 k = {k}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        A0 = np.zeros((Nx, Nx), dtype=complex)
        for i in range(1, Nx - 1):
            A0[i, i - 1] = -1
            A0[i, i] = 2 - 2 * (1 - np.cos(k * dx))
            A0[i, i + 1] = -1

        A0[0, 0] = 1
        A0[Nx - 1, Nx - 1] = -(1 - 1j * k * dx)
        A0[Nx - 1, Nx - 2] = 1

        b0 = dx**2 * source(x)
        b0[0] = 0
        b0[-1] = 0

        if Decay_rate == 'default':
            m = (k * dx)**2 / 8

        if pre == 'yes':
            Pinv = np.zeros((Nx, Nx), dtype=complex)
            for i in range(1, Nx - 1):
                Pinv[i, i - 1] = -1
                Pinv[i, i] = 2 + 1j * 2 * (1 - np.cos(k * dx))
                Pinv[i, i + 1] = -1

            Pinv[0, 0] = 1
            Pinv[Nx - 1, Nx - 1] = -(1 - 1j * k * dx)
            Pinv[Nx - 1, Nx - 2] = 1

            P = np.linalg.inv(Pinv)

            A0 = P @ A0
            b0 = P @ b0

            if Decay_rate == 'default':
                m = 1 / k

        gam = 2 * m
        b = np.concatenate((np.zeros(Nx), -b0))
        A = np.block([[np.zeros((Nx, Nx)), -A0.conj().T],
                      [A0, -gam * np.eye(Nx)]])

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u0 = np.zeros_like(b)
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point, b=b, scale_b=1/T)
        u = u[:Nx]
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Helmholtz classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Helmholtz equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        u,
        format: str = 'svg'
    ) -> str:
        """
        Generate the computational results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param u: Final solution

        :param name: Graph title

        :return: Filename to save the graph (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制解
        ax.plot(x, np.real(u), "b-", linewidth=2, label=f"Re(u)")
        ax.plot(x, np.imag(u), "r--", linewidth=2, label=f"Im(u)")
        ax.fill_between(x, np.real(u), alpha=0.3)

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("u(x)", fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files

    def _pre_processing(self, A, u0, b=None, scale_b=None):
        """Preprocessing functions"""
        from scipy.sparse import csc_matrix
        A = csc_matrix(A)
        dim = u0.shape[0]
        if b is not None and scale_b is not None:
            b = b * scale_b
        return dim, A, u0


if __name__ == "__main__":
    result = HelmholtzEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
