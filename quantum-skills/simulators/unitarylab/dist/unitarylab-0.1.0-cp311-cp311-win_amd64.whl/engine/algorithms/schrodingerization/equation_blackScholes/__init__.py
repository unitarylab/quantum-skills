"""
Black-Scholes Equation Algorithm Module

Solve the one-dimensional Black-Scholes equation based on the Schrödingerization method:

∂u/∂t + (1/2)σ²S²∂²u/∂S² + rS∂u/∂S - ru = 0
"""
from .algorithm import BlackScholesEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "blackScholes"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = BlackScholesEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维 Black-Scholes 方程"

__all__ = ["BlackScholesEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
