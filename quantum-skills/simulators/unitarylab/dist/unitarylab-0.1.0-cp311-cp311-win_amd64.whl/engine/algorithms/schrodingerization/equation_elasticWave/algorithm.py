"""
Elastic Wave Equation Algorithm Module

Solve the one-dimensional elastic wave equation based on the Schrödingerization method:
ρ∂²u/∂t² = (λ+μ)∂²u/∂x² + μ∂²u/∂x²
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm


# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包

from engine import GateSequence
from engine.library import parse_equation


# ==========================================================
# 方程运行函数

class ElasticWaveEquationAlgorithm(BaseAlgorithm):
    """Elastic Wave Equation Algorithm

    Solve the one-dimensional elastic wave equation based on the Schrödingerization method:

    ρ∂²u/∂t² = (λ+μ)∂²u/∂x² + μ∂²u/∂x²

    Supported Boundary Conditions:

    - Dirichlet boundary conditions

    - Periodic boundary conditions

    Supported Solution Methods:

    - Classical: Classical matrix exponentiation method

    - Trotter: Trotter decomposition method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the algorithm for solving the elastic wave equations

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析弹性波方程参数...")
        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e


        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        elif method == 'trotter':
            return self._solve_trotter(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from engine.library import schro_classical as schro
        from engine.library.schrodingerization.classical import circuit_classical
        from engine.library.differential_operator.classical_matrices import first_order_derivative
        import scipy.sparse as sp

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        rho = eq.get_parameter('ρ')
        lamb = eq.get_parameter('λ')
        mu = eq.get_parameter('μ')

        Nx = 2**nx
        dx = L / Nx
        x = np.arange(0, L, step=dx)
        
        f0 = eq.initial.get_parameter('σ0(x)')
        sigma0 = f0(x)
        f1 = eq.initial.get_parameter('v0(x)')
        v0 = f1(x)
        if isinstance(v0, (int, float)):
            v0 = np.ones_like(x) * v0
        u0 = np.concatenate((v0, sigma0))

        self.logger.info(f"  - 密度 ρ = {rho}")
        self.logger.info(f"  - 第一拉梅系数 λ = {lamb}")
        self.logger.info(f"  - 第二拉梅系数 μ = {mu}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        A1, b1 = first_order_derivative(N=Nx, dx=dx, boundary_condition=bd, scheme=scheme)
        zero_block = sp.csc_matrix((Nx, Nx))  # 零矩阵，与 A 同维度
        A = sp.bmat([[zero_block, A1/rho], [A1*(lamb + 2*mu), zero_block]], format='csc')

        b = None
        if source is not None:
            b = np.zeros(2 * Nx)
            b[:Nx] = source(x) / rho

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point, b=b)
        qc = circuit_classical(nx+1, na)
        end_time = time.time()

        v = u[:Nx]
        sigma = u[Nx:Nx*2]

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Elastic wave Classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, v, sigma)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Elastic wave equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "v": v.tolist() if hasattr(v, 'tolist') else v,
            "sigma": sigma.tolist() if hasattr(sigma, 'tolist') else sigma,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_trotter(self, eq):
        from engine.library import schro_trotter as schro
        from engine.library import TDiff

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        rho = eq.get_parameter('ρ')
        lamb = eq.get_parameter('λ')
        mu = eq.get_parameter('μ')
        dt = eq.solver.dt
        Nt = int(T / dt)

        Nx = 2**nx
        dx = L / Nx
        x = np.arange(0, L, step=dx)
        kappa = np.sqrt((lamb + 2 * mu) / rho)
        gamma = np.sqrt((lamb + 2 * mu) * rho)

        
        f0 = eq.initial.get_parameter('σ0(x)')
        sigma0 = f0(x)
        f1 = eq.initial.get_parameter('v0(x)')
        v0 = f1(x)
        if isinstance(v0, (int, float)):
            v0 = np.ones_like(x) * v0
        u0 = np.concatenate((v0, sigma0 / gamma))

        self.logger.info(f"  - 密度 ρ = {rho}")
        self.logger.info(f"  - 第一拉梅系数 λ = {lamb}")
        self.logger.info(f"  - 第二拉梅系数 μ = {mu}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建量子电路...")

        gamma1 = -dt / dx

        H1 = None

        H2 = GateSequence(nx+1)
        H2.h(nx)
        func1 = (kappa * TDiff(n=nx, dx=dx, order=1)).data()[1]
        H2.append(func1(dt), target=range(nx), control=nx, control_sequence='0')
        H2.append(func1(-dt), target=range(nx), control=nx, control_sequence='1')
        H2.h(nx)

        self.logger.info("阶段 2/5: 量子电路构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始执行量子电路...")
        self.logger.info(f"  - 总时间步数: {Nt}")

        start_time = time.time()
        u, qc = schro(u0=u0, H1=H1, H2=H2, R=R, na=na, Nt=Nt, order=order, point=point)
        end_time = time.time()

        v = u[:Nx].flatten()
        sigma = u[Nx:Nx*2].flatten() * gamma

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D Elastic wave Lie-Trotter nx={nx} na={na} T={T} dt={dt}"
        solution_plot_path = self._generate_solution_plot(name, x, v, sigma)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc, H1, H2)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Elastic wave equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dt": dt, "nt": Nt},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "v": v.tolist() if hasattr(v, 'tolist') else v,
            "sigma": sigma.tolist() if hasattr(sigma, 'tolist') else sigma,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        v,
        sigma,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation results plot and save it to the algorithm folder.

        :param x: Spatial grid points

        :param v: Velocity field

        :param sigma: Stress field

        :param name: Plot title

        :return: Filename to save (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 创建图像
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), dpi=100)

        # 绘制速度场
        ax1.plot(x, v, "b-", linewidth=2, label=f"v")
        ax1.fill_between(x, v, alpha=0.3)
        ax1.set_title(f"{name} - Velocity", fontsize=14)
        ax1.set_xlabel("x", fontsize=12)
        ax1.set_ylabel("v(x, t)", fontsize=12)
        ax1.legend(loc="upper right")
        ax1.grid(True, alpha=0.3)

        # 绘制应力场
        ax2.plot(x, sigma, "r-", linewidth=2, label=f"σ")
        ax2.fill_between(x, sigma, alpha=0.3)
        ax2.set_title(f"{name} - Stress", fontsize=14)
        ax2.set_xlabel("x", fontsize=12)
        ax2.set_ylabel("σ(x, t)", fontsize=12)
        ax2.legend(loc="upper right")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files

    def _controlled_first_order_derivative(self, coeff, nx, ctrl_state='0'):
        """
        Controlled first derivative
        """
        from engine.library import first_order_derivative
        return first_order_derivative(coeff, nx, boundary_condition='dirichlet')
