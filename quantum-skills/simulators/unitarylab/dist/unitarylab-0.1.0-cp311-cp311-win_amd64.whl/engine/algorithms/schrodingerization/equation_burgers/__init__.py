"""
Burgers Equation Algorithm Module

Solves the one-dimensional Burgers equation based on the Schrödingerization method:

∂u/∂t + u * ∂u/∂x = ν * ∂²u/∂x²
"""
from .algorithm import BurgersEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "burgers"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = BurgersEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维 Burgers 方程"

__all__ = ["BurgersEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
