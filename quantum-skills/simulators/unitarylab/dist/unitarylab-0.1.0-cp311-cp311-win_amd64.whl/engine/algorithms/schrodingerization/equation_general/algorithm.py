"""
通用线性方程 (General Linear Equation) 算法模块

基于 Schrödingerization 方法求解一维通用线性方程:
∂u/∂t = a * ∂u/∂x + b * ∂²u/∂x² + c * ∂³u/∂x³ + ...
"""

# ==========================================================
# 通用导言区（本地 + 服务器 双兼容）

from typing import Dict, Any, List, Optional
import json
import os
import time
import sys
import numpy as np

# -------------------------
# BaseAlgorithm 兼容导入
# -------------------------
try:
    # 服务器版本
    from ..base import BaseAlgorithm, create_algorithm_logger
    algo_logger = create_algorithm_logger(__file__)
    SERVER_MODE = True
except Exception:
    # 本地版本
    from ..algo_base import BaseAlgorithm
    algo_logger = None
    SERVER_MODE = False

# -------------------------
# matplotlib 服务器安全模式
# -------------------------
import matplotlib
if SERVER_MODE:
    matplotlib.use("Agg")
import matplotlib.pyplot as plt

# -------------------------
# parse_equation 兼容导入
# -------------------------
try:
    # 服务器
    from engine.library import parse_equation
except Exception:
    # 本地
    from ....library import parse_equation

# -------------------------
# GateSequence（服务器需要）
# -------------------------
try:
    from app.algorithms.engine.core import GateSequence
except Exception:
    try:
        from engine import GateSequence
    except Exception:
        GateSequence = None

# -------------------------
# sys.path 注入（仅服务器需要）
# -------------------------
if SERVER_MODE:
    current_file_path = os.path.abspath(__file__)
    parent_dir = os.path.dirname(os.path.dirname(current_file_path))
    if parent_dir not in sys.path:
        sys.path.insert(0, parent_dir)

# ==========================================================

# ==========================================================
# 方程运行函数

class GeneralLinearEquationAlgorithm(BaseAlgorithm):
    """通用线性方程算法

    基于 Schrödingerization 方法求解一维通用线性方程:
    ∂u/∂t = a * ∂u/∂x + b * ∂²u/∂x² + c * ∂³u/∂x³ + ...

    支持的边界条件:
    - Dirichlet 边界条件: u(0,t) = 0, u(L,t) = 0
    - 周期性边界条件: u(0,t) = u(L,t)

    支持的求解方法:
    - Classical: 经典矩阵指数方法
    - Trotter: Trotter 分解方法
    - Block: 块编码方法
    """

    def run(self, params: Optional[Any] = None) -> Dict[str, Any]:
        """
        执行通用线性方程求解算法

        :param params:
            - None: 自动读取 setup.json
            - str: JSON 字符串
            - dict: 已解析参数
        :return: 算法执行结果
        """

        # ---------- 选择日志器 ----------
        logger = getattr(self, "logger", None)
        if logger is None:
            logger = globals().get("algo_logger", None)

        if logger:
            logger.info("=" * 50)
            logger.info("阶段 1/5: 开始解析通用线性方程参数...")

        # ---------- 解析参数 ----------
        try:
            if params is None:
                # 自动读取 setup.json（本地友好）
                file_path = os.path.join(os.path.dirname(__file__), "setup.json")
                with open(file_path, "r", encoding="utf-8") as f:
                    params_obj = json.load(f)

            elif isinstance(params, str):
                # 如果是 JSON 字符串
                params_obj = json.loads(params)

            elif isinstance(params, dict):
                params_obj = params

            else:
                raise TypeError(f"Unsupported params type: {type(params)}")

            eq = parse_equation(params_obj)

        except Exception as e:
            if logger:
                logger.error(f"参数解析失败: {e}")
            raise

        # ---------- 分发求解方法 ----------
        method = eq.solver.type.lower()

        if method == "classical":
            return self._solve_classical(eq)
        elif method == "trotter":
            return self._solve_trotter(eq)
        elif method == "block":
            return self._solve_block(eq)
        else:
            raise ValueError(f"method {method} is not supported!")

    def _solve_classical(self, eq):
        from ....library import schro_classical as schro
        from ....library import CDiff, ClassicalOperator
        from ....library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        print(derivative)
        bd = eq.boundary.type
        scheme = eq.discrete.type

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)
        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)
        elif bd == "neumann":
            dx = L / (Nx - 1)
            x = np.arange(0, L + dx, dx)
        u0 = f0(x)

        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        # 组合矩阵
        A = ClassicalOperator()
        for key, value in derivative.items():
            D_value = float(value)
            D_order = int(key)
            if D_value != 0:
                A += CDiff(N=Nx, dx=dx, order=D_order, scheme=scheme, boundary=bd) * D_value
        A = A.get_matrix()

        b = eq.get_rhs_1d(Nx, dx, scheme=scheme) + source(x)
        theta = 1
        if T > 1:
            theta = 1 / T

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point, b=b, scale_b=theta)
        qc = circuit_classical(nx, na)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D General Linear Classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot_1d(name, x, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "General linear equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_trotter(self, eq):
        from ....library import schro_trotter as schro
        from ....library import TDiff, TrotterOperator

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        dt = eq.solver.dt
        Nt = int(T / dt)

        Nx = 2**nx
        dx = L / (Nx + 1)
        x = np.arange(dx, L, dx)
        if bd == "periodic":
            dx = L / Nx
            x = np.arange(0, L, dx)
        elif bd == "neumann":
            dx = L / (Nx - 1)
            x = np.arange(0, L + dx, dx)
        u0 = f0(x)

        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建量子电路...")

        # 组合矩阵
        A = TrotterOperator()
        for key, value in derivative.items():
            D_value = float(value)
            D_order = int(key)
            if D_value != 0:
                A += TDiff(nx, dx, order=D_order, boundary=bd, scheme=scheme) * D_value
        func1, func2 = A.data()
        H1 = func1(dt / R)
        H2 = func2(dt)

        b = eq.get_rhs_1d(Nx, dx, scheme=scheme) + source(x)
        theta = 1
        if T > 1:
            b = b * T
            theta = 1 / T
        
        self.logger.info("阶段 2/5: 量子电路构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始执行量子电路...")
        self.logger.info(f"  - 总时间步数: {Nt}")

        start_time = time.time()
        u, qc = schro(u0=u0, H1=H1, H2=H2, Nt=Nt, na=na, R=R, order=order, point=point, b=b, theta=theta*dt)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"1D General Linear Lie-Trotter nx={nx} na={na} T={T} dt={dt}"
        solution_plot_path = self._generate_solution_plot_1d(name, x, u)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc, H1, H2)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "General linear equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dt": dt, "nt": Nt},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "u": u.tolist() if hasattr(u, 'tolist') else u,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_block(self, eq):
        self.logger.info('Block encoding will be supported soon! Now falling back to classical method!')
        return self._solve_classical(eq)
    
    def _generate_solution_plot(
        self,
        name: str,
        x,
        u,
        format: str = "svg"
    ) -> str:
        """
        生成计算结果图并保存到算法文件夹

        :param x: 空间网格点
        :param u: 最终时刻的温度分布
        :param name: 图标题
        :return: 保存的文件名（相对于算法文件夹）
        """

        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))

        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制温度分布曲线
        ax.plot(x, u, "b-", linewidth=2, label=f"u")
        ax.fill_between(x, u, alpha=0.3)

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel("x", fontsize=12)
        ax.set_ylabel("u(x, t)", fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 文件名安全化
        safe_name = name.replace(" ", "_")
        filename = f"{safe_name}_solution.{format}"
        solution_path = os.path.join(algo_dir, filename)

        # 保存图像
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        # 使用本地 logger
        if hasattr(self, "logger") and self.logger:
            self.logger.debug(f"计算结果图已保存到: {solution_path}")

        return filename
        
    def _generate_circuit_plots(
        self,
        name: str,
        qc,
        H1: Optional[Any] = None,
        H2: Optional[Any] = None,
        format: str = "svg"
    ) -> list:
        """
        生成多个量子电路图并保存到算法文件夹

        :param qc: 量子电路
        :param H1: 子电路 H1
        :param H2: 子电路 H2
        :param name: 图标题
        :return: 保存的文件信息列表
        """

        algo_dir = os.path.dirname(os.path.abspath(__file__))

        circuit_files = []
        base_name = name.replace(" ", "_")

        # 生成完整电路图
        filename1 = f"{base_name}_circuit_full.{format}"
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")

        circuit_files.append({
            "format": format,
            "filename": filename1,
        })

        # 生成 H1 电路图
        if H1 is not None:
            filename2 = f"{base_name}_circuit_H1.{format}"
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")

            circuit_files.append({
                "format": format,
                "filename": filename2,
            })

        # 生成 H2 电路图
        if H2 is not None:
            filename3 = f"{base_name}_circuit_H2.{format}"
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")

            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        # 本地 logger
        if hasattr(self, "logger") and self.logger:
            self.logger.debug(f"量子电路图已保存到: {algo_dir}")
            self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")

        return circuit_files

