"""
Multiscale Transport Equation Algorithm Module

Solve one-dimensional multiscale transport equations based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from scipy.integrate import quad
from ..algo_base import BaseAlgorithm

# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包
from engine import GateSequence
from engine.library import parse_equation


# ==========================================================
# 方程运行函数

class MultiTransportEquationAlgorithm(BaseAlgorithm):
    """Multi-scale transport equation algorithm

    Solving one-dimensional multi-scale transport equations based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the multi-scale transport equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析多尺度输运方程参数...")
        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from engine.library.schrodingerization.classical import circuit_classical
        from scipy import sparse as sp

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        Nx = 2**nx
        x = np.linspace(0, L, Nx + 2).conj().T
        dx = x[1] - x[0]
        dt = dx**2
        Nt = int(np.floor(T / dt))
        dt_a = 0.5

        Q = eq.get_parameter('Q')
        eps1 = eq.get_parameter('ε')
        sigma_S = eq.get_parameter('σS')
        sigma_A = eq.get_parameter('σA')
        ssigma = sigma_S + eps1**2 * sigma_A

        if eps1 > dx:
            raise ValueError("epsilon is too large")

        Nv = 4
        gauss_points = np.array([0.183434642495649804939476139852, 0.525532409916328985817739005708,
                                0.796666477413626739591553584604, 0.960289856497536231683560658813])
        gauss_weights = np.array([0.36268378337836198296515045, 0.31370664587788728733770525,
                                0.22238103445337447054435515, 0.10122853629037625915253185])

        f0 = np.zeros((Nx, 1))  # Initialize f0
        F_L = 0.5 * np.ones((Nv, 1))
        F_R = np.zeros((Nv, 1))
        r0 = (1/4) * (f0 + f0)
        j0 = (1/(2*eps1)) * (f0 - f0)
        j0 = (1/(Nx**2))*j0;
        R0 = np.kron(np.ones((Nv, 1)), r0)
        J0 = np.kron(np.ones((Nv, 1)), j0)

        self.logger.info(f"  - 源项 Q = {Q}")
        self.logger.info(f"  - 小尺度参数 ε = {eps1}")
        self.logger.info(f"  - 散射截面 σS = {sigma_S}")
        self.logger.info(f"  - 吸收截面 σA = {sigma_A}")
        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        def QFTmtx(nq):
            N = 2 ** nq
            # 创建DFT矩阵
            dft_matrix = np.fft.fft(np.eye(N))
            iF = sp.csr_matrix(1 / np.sqrt(N) * np.conj(dft_matrix))
            return iF

        def iQFTmtx(nq):
            N = 2 ** nq
            # 创建DFT矩阵
            dft_matrix = np.fft.fft(np.eye(N))
            iF = sp.csr_matrix(1/np.sqrt(N)*dft_matrix)
            return iF

        eps1_vk = eps1 * gauss_points
        eps1_vk_dx = eps1_vk + ssigma * dx

        Delta_x = np.zeros((Nx * Nv, Nx * Nv))
        L1 = np.zeros((Nx * Nv, Nx * Nv))
        L2 = np.diag(-2 * np.ones(Nx)) + np.diag(np.ones(Nx - 1), 1) + np.diag(np.ones(Nx - 1), -1)
        M1 = np.diag(np.zeros(Nx)) + np.diag(np.ones(Nx - 1), 1) + np.diag(-np.ones(Nx - 1), -1)
        M2 = np.zeros((Nx * Nv, Nx * Nv))
        B_v = np.zeros((Nx * Nv, 1))
        f_v = np.zeros((Nx * Nv, 1))
        g_v = np.zeros((Nx * Nv, 1))

        for i in range(Nv):
            vk = gauss_points[i]
            idx = slice(i * Nx, (i + 1) * Nx)

            Delta_xk = np.diag(-np.ones(Nx - 1), -1) + np.diag(np.ones(Nx - 1), 1)
            Delta_xk[0, 0] = (-eps1_vk[i]) / eps1_vk_dx[i]
            Delta_xk[Nx - 1, Nx - 1] = eps1_vk[i] / eps1_vk_dx[i]
            Delta_x[idx, idx] = (1 / (2 * dx)) * Delta_xk

            L1_k = np.diag(-2 * np.ones(Nx)) + np.diag(np.ones(Nx - 1), 1) + np.diag(np.ones(Nx - 1), -1)
            L1_k[0, 0] = -2 + (eps1_vk[i] - vk) / eps1_vk_dx[i]
            L1_k[Nx - 1, Nx - 1] = L1_k[0, 0]
            L1[idx, idx] = L1_k

            M2_k = np.diag(np.zeros(Nx)) + np.diag(np.ones(Nx - 1), 1) + np.diag(-np.ones(Nx - 1), -1)
            M2_k[0, 0] = (vk - eps1_vk[i]) / eps1_vk_dx[i]
            M2_k[Nx - 1, Nx - 1] = -M2_k[0, 0]
            M2[idx, idx] = M2_k

            B_v_temp = np.zeros((Nx, 1))
            B_v_temp[0] = -(ssigma / (2 * eps1_vk_dx[i])) * F_L[i]
            B_v_temp[Nx - 1] = ssigma / (2 * eps1_vk_dx[i]) * F_R[i]
            B_v[idx] = B_v_temp

            f_v_temp = np.zeros((Nx, 1))
            f_v_temp[0] = ((ssigma * dx * vk + vk**2) / eps1_vk_dx[i]) * F_L[i]
            f_v_temp[Nx - 1] = ((ssigma * dx * vk + vk**2) / eps1_vk_dx[i]) * F_R[i]
            f_v[idx] = f_v_temp

            g_v_temp = np.zeros((Nx, 1))
            g_v_temp[0] = ((ssigma * dx * vk + vk**2) / eps1_vk_dx[i]) * F_L[i]
            g_v_temp[Nx - 1] = -((ssigma * dx * vk + vk**2) / eps1_vk_dx[i]) * F_R[i]
            g_v[idx] = g_v_temp

        # 转换为稀疏矩阵（如果需要）
        Delta_x = sp.csr_matrix(Delta_x)
        L1 = sp.csr_matrix(L1)
        L2 = sp.csr_matrix(L2)
        M1 = sp.csr_matrix(M1)
        M2 = sp.csr_matrix(M2)

        # Evolution step
        lamb = dt / dx
        V = np.diag(gauss_points)
        ones_Nv_col = np.ones((Nv, 1))          # (4, 1)
        gauss_weights_row = gauss_weights.reshape(1, -1)  # (1, 4)
        W = np.kron(ones_Nv_col, gauss_weights_row)       # (4, 4)
        beta1 = np.exp(-(sigma_S * dt) / eps1**2)
        beta2 = (1 - np.exp(-(sigma_S * dt) / eps1**2) - (sigma_S * dt / eps1**2) * np.exp(-(sigma_S * dt) / eps1**2))
        beta3 = ((dt / eps1**2) * np.exp(-(sigma_S * dt) / eps1**2)) * (1 - eps1**2)

        # Create identity matrices
        I_Nx = sp.eye(Nx)
        I_NxNv = sp.eye(Nx * Nv)


        # A1 matrix
        A1 = (beta1 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, I_Nx) @ L1) 
            + (1 - beta1) * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, I_Nx) @ L1) @ sp.kron(W, I_Nx) 
            + (lamb / 2) * beta2 * sp.kron(V, M1) @ sp.kron((1 / ssigma) * V, I_Nx) @ Delta_x @ sp.kron(W, I_Nx) 
            + (lamb / 2) * beta3 * sp.kron(V, M1) @ sp.kron(V, I_Nx) @ Delta_x)
        # B1 matrix
        B1 = -(lamb / 2) * beta1 * sp.kron(V, M1)
        # A2 matrix
        A2 = (-beta3 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, L2)) @ sp.kron(V, I_Nx) @ Delta_x
            - beta2 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, L2)) @ sp.kron((1 / ssigma) * V, I_Nx) @ Delta_x @ sp.kron(W, I_Nx)
            - (lamb / 2) * np.exp(-(sigma_S * dt) / eps1**2) * sp.kron(V, I_Nx) @ M2
            - (lamb / 2) * (1 - beta1) * sp.kron(V, I_Nx) @ M2 @ sp.kron(W, I_Nx))
        # B2 matrix
        B2 = beta1 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, L2))
        # b_r vector
        b_r = ((lamb / 2) * beta2 * sp.kron(V, M1) @ sp.kron((1 / ssigma) * V @ W, I_Nx) @ B_v
            + (lamb / 2) * beta3 * sp.kron(V, M1) @ sp.kron(V, I_Nx) @ B_v
            + (lamb / 2) * f_v + dt * Q)
        # b_j vector
        b_j = (-beta2 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, L2)) @ sp.kron((1 / ssigma) * V, I_Nx) @ B_v
            - beta3 * ((1 - dt * sigma_A) * I_NxNv + (lamb / 2) * sp.kron(V, L2)) @ sp.kron(V, I_Nx) @ B_v
            + (lamb / 2) * g_v)

        # preprocessing
        Lambda_ = np.diag(gauss_weights**0.5)
        Lambda_inv = np.diag(gauss_weights**(-0.5))  # Lambda_^(-1)

        hR0 = sp.kron(Lambda_, I_Nx) @ R0
        hJ0 = (1/(Nx**2)) * J0
        hA1 = sp.kron(Lambda_, I_Nx) @ A1 @ sp.kron(Lambda_inv, I_Nx)
        hB1 = sp.kron(Lambda_, I_Nx) @ ((Nx**2)*B1)
        hA2 = (1/(Nx**2)) * A2 @ sp.kron(Lambda_inv, I_Nx)
        hb_r = sp.kron(Lambda_, I_Nx) @ b_r
        hb_j = (1/(Nx**2)) * b_j

        # Iterative - 构建C矩阵
        # 获取向量的尺寸用于构建零矩阵
        hb_j_size = hb_j.shape[0]
        hb_r_size = hb_r.shape[0]

        # 构建C矩阵的各部分
        C_top = sp.hstack([B2, hA2, hb_j/Nx**0.5, sp.csr_matrix((hb_j_size, 1))])
        C_middle = sp.hstack([hB1, hA1, sp.csr_matrix((hb_r_size, 1)), hb_r/Nx**0.5])
        C_bottom1 = sp.hstack([sp.csr_matrix((1, hb_j_size)), sp.csr_matrix((1, hb_j_size)), 
                                sp.csr_matrix([[1]]), sp.csr_matrix((1, 1))])
        C_bottom2 = sp.hstack([sp.csr_matrix((1, hb_r_size)), sp.csr_matrix((1, hb_r_size)), 
                                sp.csr_matrix((1, 1)), sp.csr_matrix([[1]])])

        # 垂直堆叠构建完整的C矩阵
        C = sp.vstack([C_top, C_middle, C_bottom1, C_bottom2])
        # dy/dt = (C-I)y
        hy0 = np.vstack([hJ0, hR0, np.array([[Nx**0.5]]), np.array([[Nx**0.5]])])
        hy = hy0.copy()

        for k in range(int(np.floor(Nt / dt_a))):
            # hy = C * hy
            # 使用隐式欧拉方法: hy = (I - dt_a * (C - I)) \ hy
            I_matrix = np.eye(C.shape[0])
            matrix_to_invert = I_matrix - dt_a * (C - I_matrix)
            hy = np.linalg.solve(matrix_to_invert, hy)

        # 提取结果
        hur = hy[Nv * Nx : Nv * Nx + Nv * Nx]  # hy(Nv*Nx+1:Nv*Nx+Nv*Nx)
        ur = sp.kron(Lambda_inv, np.eye(Nx)) @ hur
        rr = ur.reshape(Nx, Nv, order='F')  # MATLAB按列优先reshape

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()

        rho = rr @ gauss_weights.reshape(-1, 1)  # rho = rr *   gauss_weights'
        huj = hy[:Nv*Nx]  # hy(1:Nv*Nx)
        uj = (Nx**2) * huj
        drho_dx = uj[:Nx]  # uj(1:Nx)

        # 解析解
        tmp1 = np.zeros((1, Nv))
        tmp2 = np.zeros((1, Nv))
        for i in range(Nv):
            vk = gauss_points[i]
            tmp1[0, i] = (eps1_vk[i] / eps1_vk_dx[i]) * rr[0, i] + ((ssigma * dx) / eps1_vk_dx[i]) * F_L[i, 0]
            tmp2[0, i] = (eps1_vk[i] / eps1_vk_dx[i]) * rr[Nx-1, i] + ((ssigma * dx) / eps1_vk_dx[i]) * F_R[i, 0]

        # 构建完整的rho
        rho_full = np.vstack([
            tmp1 @ gauss_weights.reshape(-1, 1),
            rho,
            tmp2 @ gauss_weights.reshape(-1, 1)
        ])

        # 边界处理
        tmp3 = -(gauss_points[0] / eps1_vk_dx[0]) * rr[0, 0] + (gauss_points[0] / eps1_vk_dx[0]) * F_L[0, 0]
        tmp4 = (gauss_points[0] / eps1_vk_dx[0]) * rr[Nx-1, 0] - (gauss_points[0] / eps1_vk_dx[0]) * F_R[0, 0]

        drho_dx_full = np.vstack([
            np.array([[tmp3]]),
            drho_dx,
            np.array([[tmp4]])
        ])

        # D-Sch
        # Parameters
        Np = 2**na
        L = -Nx
        R = 5*Nx
        p = np.linspace(L, R, Np + 1).conj().T  # 列向量
        dp = p[1] - p[0]

        # QFT matrix - 修正这里
        nqp = int(np.log2(Np))  # 转换为整数
        mup = 2 * np.pi * np.arange(-Np//2, Np//2) / (R - L)
        mup = mup.reshape(-1, 1)  # 列向量

        # 创建Sp矩阵
        Sp = np.ones(Np)
        Sp[1::2] = -1  # 从索引1开始，每隔2个设为-1 (MATLAB的2:2:end)
        Sp = np.diag(Sp)

        Fp = Sp @ QFTmtx(nqp)
        iFp = iQFTmtx(nqp) @ Sp
        alpha = 1
        ep = p.copy()
        ep[ep < 0] = alpha * ep[ep < 0]

        hUY = hy0
        C_sch = np.zeros((Np, 1))
        for j in range(Np):
            C_sch[j, 0] = np.exp(-abs(ep[j]))

        c0 = np.kron(C_sch, hUY)
        C0 = c0.reshape(len(hy0),Np, order='F')  # reshape并转置
        C0=C0.conj().T
        Ix = sp.eye(len(hy0), len(hy0))
        C0 = iFp @ C0 @ Ix.conj().T
        C0 = C0.conj().T
        hc0 = C0.flatten(order='F')  # 按列优先展平

        H = C - np.eye(C.shape[0])
        # Compute Hermitian and anti-Hermitian parts
        H1 = (H + H.conj().T)/2  # Hermitian part
        H2 = (H - H.conj().T)/(2*1j)  # Anti-Hermitian part

        # Compute eigenvalues (largest and smallest real parts)
        # 注意：eigs函数参数与MATLAB不同
        try:
            e_largest = sp.linalg.eigs(H1, k=6, which='LR')[0]  # Largest Real
            e_smallest = sp.linalg.eigs(H1, k=6, which='SR')[0]  # Smallest Real
        except:
            # 如果稀疏矩阵特征值计算失败，使用稠密矩阵
            H1_dense = H1.toarray() if sp.issparse(H1) else H1
            e_largest = np.linalg.eigvals(H1_dense)
            e_smallest = e_largest  # 简化处理

        # Construct HD using sparse matrices
        Dmup = sp.diags(mup.flatten(), 0, shape=(Np, Np))  # Diagonal matrix of eta
        HD = sp.kron(Dmup, H1) - sp.kron(sp.eye(Np), H2)  # Sparse Kronecker product

        hc = hc0.copy()
        for kk in range(int(np.floor(Nt/dt_a))):
            I_HD = sp.eye(HD.shape[0], HD.shape[1]) + 1j * dt_a * HD
            hc = sp.linalg.spsolve(I_HD, hc)

        # Grid values
        C_matrix = hc.reshape(len(hy0), Np, order='F')
        C_matrix = C_matrix.conj().T  # reshape并转置
        W = (Fp @ C_matrix) @ Ix.conj().T
        W = np.real(np.array(W))
        W = W.conj().T
        # df = pd.DataFrame(W)
        # df.to_excel('W_npy.xlsx', index=False)

        # Numerical solutions recovered by two formulas 
        dp1 = 0.1
        ppp = np.arange(-1, R-1 + dp1, dp1)  # -1:dp1:R-1

        # Preallocate error arrays
        Rhoerr1 = np.zeros(len(ppp))
        RhoUerr1 = np.zeros(len(ppp))

        # Loop over ppp
        for idx in range(len(ppp)):
            pp = ppp[idx]

            # Method 1: Use p close to 0 from the right
            jR = np.where(p > pp)[0]
            if len(jR) > 0:
                jR = jR[0]
                if jR > W.shape[1]:
                    raise ValueError("The recover point p is too large! Please contact the administrator!")
                WN = W[:, jR]
                v = np.exp(-abs(p[jR]))
                uN = np.real(WN / v)
                U1 = uN
                
                Ur = U1[Nv*Nx : Nv*Nx + Nv*Nx]  # U1(Nv*Nx+1:Nv*Nx+Nv*Nx)
                Ur = sp.kron(Lambda_inv, np.eye(Nx)) @ Ur
                Uj = U1[:Nv*Nx]  # U1(1:Nv*Nx)
                Uj = (Nx**2) * Uj
                
                Urr1 = Ur[:Nx]  # Ur(1:Nx)
                Ujj1 = Uj[:Nx]  # Uj(1:Nx)
                
                # 注意：rho和drho_dx需要是之前计算的结果
                # 假设rho_full和drho_dx_full已经计算，去掉边界点
                rho_inner = rho_full[1:-1]  # rho(2:end-1)
                drho_dx_inner = drho_dx_full[1:-1]  # drho_dx(2:end-1)
                
                Rhoerr1[idx] = np.linalg.norm(Urr1 - rho_inner)
                RhoUerr1[idx] = np.linalg.norm(Ujj1 - drho_dx_inner)

        # Method 1: use some p close to 0 from the right
        pp = ppp[np.argmin(Rhoerr1)]
        print(f"Optimal pp: {pp}")

        jR = np.where(p > pp)[0]
        if len(jR) > 0:
            jR = jR[0]
            if jR >= W.shape[1]:
                raise ValueError("nx is large!")
            WN = W[:, jR]
            v = np.exp(-abs(p[jR]))
            uN = np.real(WN / v)
            U1 = uN
            Ur = U1[Nv*Nx : Nv*Nx + Nv*Nx]
            Ur = sp.kron(Lambda_inv, np.eye(Nx)) @ Ur
            Uj = U1[:Nv*Nx]
            Uj = (Nx**2) * Uj

            rr = Ur.reshape(Nx, Nv, order='F')  # reshape(Ur, Nx, Nv)
            Urr1 = rr @ gauss_weights.reshape(-1, 1)  # rr * gauss_weights'
            Ujj1 = Uj[:Nx]  # Uj(1:Nx)

            tmp1 = np.zeros((1, Nv))
            tmp2 = np.zeros((1, Nv))
            for i in range(Nv):
                vk = gauss_points[i]
                tmp1[0, i] = (eps1_vk[i] / eps1_vk_dx[i]) * rr[0, i] + ((ssigma * dx) / eps1_vk_dx[i]) * F_L[i, 0]
                tmp2[0, i] = (eps1_vk[i] / eps1_vk_dx[i]) * rr[Nx-1, i] + ((ssigma * dx) / eps1_vk_dx[i]) * F_R[i, 0]
            
            Urr1_full = np.vstack([
                tmp1 @ gauss_weights.reshape(-1, 1),
                Urr1,
                tmp2 @ gauss_weights.reshape(-1, 1)
            ])
            
            tmp3 = -(gauss_points[0] / eps1_vk_dx[0]) * rr[0, 0] + (gauss_points[0] / eps1_vk_dx[0]) * F_L[0, 0]
            tmp4 = (gauss_points[0] / eps1_vk_dx[0]) * rr[Nx-1, 0] - (gauss_points[0] / eps1_vk_dx[0]) * F_R[0, 0]
            Ujj1_full_tmp = np.insert(Ujj1,0,tmp3)
            Ujj1_full = np.insert(Ujj1_full_tmp,len(Ujj1)+1,tmp4)

        qc = circuit_classical(nx, na)

        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        Urr1_full = Urr1_full.flatten()
        Ujj1_full = Ujj1_full.flatten()

        name = f"1D Multiscale transport classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, x, Urr1_full, Ujj1_full)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Multiscale transport equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": x.tolist() if hasattr(x, 'tolist') else x,
            "Urr": Urr1_full.tolist() if hasattr(Urr1_full, 'tolist') else Urr1_full,
            "Ujj": Ujj1_full.tolist() if hasattr(Ujj1_full, 'tolist') else Ujj1_full,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        rho,
        drho_dx,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation result plot and save it to the algorithm folder.

        :param x: Spatial grid point

        :param rho: Density distribution

        :param drho_dx: Density gradient

        :param name: Plot title

        :return: Filename to save the plot (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 创建图像
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(10, 10), dpi=100)

        # 绘制密度分布
        ax1.plot(x, rho, "b-", linewidth=2, label=f"ρ")
        ax1.fill_between(x, rho, alpha=0.3)
        ax1.set_title(f"{name} - Density", fontsize=14)
        ax1.set_xlabel("x", fontsize=12)
        ax1.set_ylabel("ρ(x)", fontsize=12)
        ax1.legend(loc="upper right")
        ax1.grid(True, alpha=0.3)

        # 绘制密度梯度
        ax2.plot(x, drho_dx, "r-", linewidth=2, label=f"∂xρ")
        ax2.fill_between(x, drho_dx, alpha=0.3)
        ax2.set_title(f"{name} - Density Gradient", fontsize=14)
        ax2.set_xlabel("x", fontsize=12)
        ax2.set_ylabel("∂xρ(x)", fontsize=12)
        ax2.legend(loc="upper right")
        ax2.grid(True, alpha=0.3)

        plt.tight_layout()

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files
