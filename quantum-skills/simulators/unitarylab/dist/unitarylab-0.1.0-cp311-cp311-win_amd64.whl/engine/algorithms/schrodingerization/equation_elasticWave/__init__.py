"""
Elastic Wave Equation Algorithm Module

Solve the one-dimensional elastic wave equation based on the Schrödingerization method:
ρ∂²u/∂t² = (λ+μ)∂²u/∂x² + μ∂²u/∂x²
"""
from .algorithm import ElasticWaveEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "elasticWave"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = ElasticWaveEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解一维弹性波方程"

__all__ = ["ElasticWaveEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
