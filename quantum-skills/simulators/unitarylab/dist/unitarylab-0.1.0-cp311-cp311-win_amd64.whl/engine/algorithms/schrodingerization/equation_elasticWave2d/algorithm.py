"""
2D Elastic Wave Equation Algorithm Module

Solve the two-dimensional elastic wave equation based on the Schrödingerization method.
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm



# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

# 导入 engine 包

from .... import GateSequence
from ....library import parse_equation

# ==========================================================
# 方程运行函数

class ElasticWave2DEquationAlgorithm(BaseAlgorithm):
    """2D Elastic Wave Equation Algorithm

    Solving the 2D elastic wave equation based on the Schrödingerization method

    Supported solution methods:

    - Classical: Classical matrix exponentiation method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
        Execute the 2D elastic wave equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 2D 弹性波方程参数...")
        try:
            if params is None:
                import json as _json
                _setup = os.path.join(os.path.dirname(os.path.abspath(__file__)), "setup.json")
                with open(_setup, "r", encoding="utf-8") as _f:
                    params = _json.load(_f)
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e


        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from ....library.schrodingerization.classical import schro_classical_fulltime, circuit_classical
        from ....library import schro_classical as schro
        import scipy.sparse as sp

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        bd = eq.boundary.type
        scheme = eq.discrete.type

        f0_sigma = eq.initial.get_parameter('σ0(x, y)')
        f0_v = eq.initial.get_parameter('v0(x, y)')
        dt = eq.discrete.get_parameter('dt', 0)

        Nx = 2**nx
        x0, xM = 0.0, L
        x = np.linspace(x0, xM, Nx + 1)
        dx = x[1] - x[0]

        Ny = 2**nx
        y0, yM = 0.0, L
        y = np.linspace(y0, yM, Ny + 1)
        dy = y[1] - y[0]

        x_grid, y_grid = np.meshgrid(x[:-1], y[:-1], indexing='xy')

        rho = eq.get_parameter('ρ(x,y)')
        lambda_ = eq.get_parameter('λ(x,y)')
        mu = eq.get_parameter('μ(x,y)')

        self.logger.info(f"  - 计算域长度 L = {L}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info(f"  - 边界条件: {bd}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        def build_periodic_diff_matrix(n):
            D = - np.eye(n, k=0) + np.eye(n, k=1)
            D[-1, 0] = 1.0
            return sp.csc_matrix(D)

        Dx = build_periodic_diff_matrix(Nx)
        Dy = build_periodic_diff_matrix(Ny)

        I_Nx = sp.eye(Nx)
        I_Ny = sp.eye(Ny)

        D1 = (sp.kron(Dx, I_Ny)) / dx
        D2 = (sp.kron(I_Nx, Dy)) / dy

        O = sp.csc_matrix((Nx * Ny, Nx * Ny))

        n_dof = Nx * Ny

        # 密度相关矩阵（R1, R2）
        x_centers = x[:-1] + dx/2  # x方向单元格中心
        y_centers = y[:-1] + dy/2  # y方向单元格中心

        x_r1, y_r1 = np.meshgrid(x_centers, y[:-1], indexing='xy')
        r1_vals = rho(x_r1, y_r1).flatten()
        R1 = sp.diags(1.0 / r1_vals, format='csc')  # 1/rho(x+dx/2, y)

        x_r2, y_r2 = np.meshgrid(x[:-1], y_centers, indexing='xy')
        r2_vals = rho(x_r2, y_r2).flatten()
        R2 = sp.diags(1.0 / r2_vals, format='csc')  # 1/rho(x, y+dy/2)

        # 拉梅常数相关矩阵（C11, C12等）
        l1_vals = lambda_(x_grid, y_grid).flatten()
        m1_vals = mu(x_grid, y_grid).flatten()
        x_r3, y_r3 = np.meshgrid(x_centers, y_centers, indexing='xy')
        m2_vals = mu(x_r3, y_r3).flatten()

        C11 = sp.diags(l1_vals + 2 * m1_vals, format='csc')
        C22 = C11.copy()
        C12 = sp.diags(l1_vals, format='csc')
        C21 = C12.copy()
        C31 = sp.diags(m2_vals, format='csc')
        C32 = C31.copy()

        # 构建系统矩阵A（5x5块矩阵）
        A_blocks = [[O for _ in range(5)] for _ in range(5)]

        # 填充块矩阵（对应速度-应力方程的一阶系统）
        A_blocks[0][2] = R1 @ D1    # 速度v1与应力s11、s12的关系
        A_blocks[0][4] = R1 @ D2
        A_blocks[1][3] = R2 @ D2    # 速度v2与应力s22、s12的关系
        A_blocks[1][4] = R2 @ D1
        A_blocks[2][0] = -C11 @ D1.T  # 应力s11与速度v1、v2的关系
        A_blocks[2][1] = -C12 @ D2.T
        A_blocks[3][0] = -C21 @ D1.T  # 应力s22与速度v1、v2的关系
        A_blocks[3][1] = -C22 @ D2.T
        A_blocks[4][0] = -C31 @ D2.T  # 应力s12与速度v1、v2的关系
        A_blocks[4][1] = -C32 @ D1.T

        # 转换为大型稀疏矩阵
        A1 = sp.bmat(A_blocks, format='csc')

        u0 = np.zeros(5 * n_dof)

        v1_initial = f0_v(x_grid, y_grid).flatten()
        s11_initial = f0_sigma(x_grid, y_grid).flatten()
        u0[:n_dof] = v1_initial
        u0[2 * n_dof : 3 * n_dof] = s11_initial

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()

        if dt > 0:
            Nt = int(T / dt)

            # 经典薛定谔化
            u = schro_classical_fulltime(A=A1, u0=u0, T=T, R=R, na=na, order=order, point=point, dt=dt)

            v1_schro = u[:, :n_dof].reshape(Nt+1, Ny, Nx, order='F')
            v2_schro = u[:, n_dof : 2*n_dof].reshape(Nt+1, Ny, Nx, order='F')
            s11_schro = u[:, 2*n_dof : 3*n_dof].reshape(Nt+1, Ny, Nx, order='F')
            s22_schro = u[:, 3*n_dof : 4*n_dof].reshape(Nt+1, Ny, Nx, order='F')
            s12_schro = u[:, 4*n_dof : 5*n_dof].reshape(Nt+1, Ny, Nx, order='F')

        else:
            u = schro(A=A1, u0=u0, T=T, R=R, na=na, order=order, point=point)

            v1_schro = u[:n_dof].reshape(Ny, Nx, order='F')
            v2_schro = u[n_dof : 2*n_dof].reshape(Ny, Nx, order='F')
            s11_schro = u[2*n_dof : 3*n_dof].reshape(Ny, Nx, order='F')
            s22_schro = u[3*n_dof : 4*n_dof].reshape(Ny, Nx, order='F')
            s12_schro = u[4*n_dof : 5*n_dof].reshape(Ny, Nx, order='F')

        qc = circuit_classical(nx, na, dim=2)
        end_time = time.time()

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        name = f"2D Elastic Wave classical nx={nx} na={na} T={T}"
        if dt > 0:
            solution_plot_path = self._generate_solution_animation(name, x[:-1], y[:-1], v1_schro, v2_schro, s11_schro, s22_schro, s12_schro)
        else:
            solution_plot_path = self._generate_solution_plot(name, x[:-1], y[:-1], v1_schro, v2_schro, s11_schro, s22_schro, s12_schro)

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "2D Elastic wave equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dy": dy},
            "x": x[:-1].tolist() if hasattr(x[:-1], 'tolist') else x[:-1],
            "y": y[:-1].tolist() if hasattr(y[:-1], 'tolist') else y[:-1],
            "v1": v1_schro.tolist() if hasattr(v1_schro, 'tolist') else v1_schro,
            "v2": v2_schro.tolist() if hasattr(v2_schro, 'tolist') else v2_schro,
            "s11": s11_schro.tolist() if hasattr(s11_schro, 'tolist') else s11_schro,
            "s22": s22_schro.tolist() if hasattr(s22_schro, 'tolist') else s22_schro,
            "s12": s12_schro.tolist() if hasattr(s12_schro, 'tolist') else s12_schro,
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_trotter(self, eq):
        self.logger.info('Trotter decomposition will be supported soon! Now falling back to classical method!')
        return self._solve_classical(eq)

    def _solve_block(self, eq):
        self.logger.info('Block encoding will be supported soon! Now falling back to classical method!')
        return self._solve_classical(eq)

    def _generate_solution_plot(
        self,
        name: str,
        x,
        y,
        v1,
        v2,
        s11,
        s22,
        s12,
        format: str = 'svg'
    ) -> str:
        """
        Generate the calculation results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param y: Spatial grid points

        :param v1: Velocity field

        :param v2: Velocity field

        :param s11: Stress field

        :param s22: Stress field

        :param s12: Stress field

        :param name: Graph title

        :return: Saved file name (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        # 创建图像
        fig, (ax1, ax2, ax3, ax4, ax5) = plt.subplots(5, 1, figsize=(16, 20), dpi=100, subplot_kw={'projection': '3d'})

        # 绘制速度场v1
        X, Y = np.meshgrid(x, y)
        contour1 = ax1.plot_surface(X, Y, v1.reshape(len(y), len(x)), cmap='viridis')
        plt.colorbar(contour1, ax=ax1, label='v1')
        ax1.set_title(f"{name} - Velocity v1", fontsize=14)
        ax1.set_xlabel("x", fontsize=12)
        ax1.set_ylabel("y", fontsize=12)
        ax1.grid(True, alpha=0.3)

        # 绘制速度场v2
        contour2 = ax2.plot_surface(X, Y, v2.reshape(len(y), len(x)), cmap='viridis')
        plt.colorbar(contour2, ax=ax2, label='v2')
        ax2.set_title(f"{name} - Velocity v2", fontsize=14)
        ax2.set_xlabel("x", fontsize=12)
        ax2.set_ylabel("y", fontsize=12)
        ax2.grid(True, alpha=0.3)

        # 绘制应力场s11
        contour3 = ax3.plot_surface(X, Y, s11.reshape(len(y), len(x)), cmap='viridis')
        plt.colorbar(contour3, ax=ax3, label='σ11')
        ax3.set_title(f"{name} - Stress σ11", fontsize=14)
        ax3.set_xlabel("x", fontsize=12)
        ax3.set_ylabel("y", fontsize=12)
        ax3.grid(True, alpha=0.3)

        # 绘制应力场s22
        contour4 = ax4.plot_surface(X, Y, s22.reshape(len(y), len(x)), cmap='viridis')
        plt.colorbar(contour4, ax=ax4, label='σ22')
        ax4.set_title(f"{name} - Stress σ22", fontsize=14)
        ax4.set_xlabel("x", fontsize=12)
        ax4.set_ylabel("y", fontsize=12)
        ax4.grid(True, alpha=0.3)

        # 绘制应力场s12
        contour5 = ax5.plot_surface(X, Y, s12.reshape(len(y), len(x)), cmap='viridis')
        plt.colorbar(contour5, ax=ax5, label='σ12')
        ax5.set_title(f"{name} - Stress σ12", fontsize=14)
        ax5.set_xlabel("x", fontsize=12)
        ax5.set_ylabel("y", fontsize=12)
        ax5.grid(True, alpha=0.3)

        plt.tight_layout()

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_solution_animation(
        self,
        name: str,
        x,
        y,
        v1,
        v2,
        s11,
        s22,
        s12,
    ) -> str:
        """
        Generate the calculation results graph and save it to the algorithm folder.

        :param x: Spatial grid points

        :param y: Spatial grid points

        :param v1: Velocity field

        :param v2: Velocity field

        :param s11: Stress field

        :param s22: Stress field

        :param s12: Stress field

        :param name: Graph title

        :return: Saved file name (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        from ....library.schrodingerization.solutionAnimation import plot2d_animation
       
        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.gif'
        solution_path = os.path.join(algo_dir, filename)
        plot2d_animation(name, solution_path, x, y, [v1, v2, s11, s22, s12], ['v_1', 'v_2', r'\sigma_{11}', r'\sigma_{22}', r'\sigma_{12}'])

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        _this = os.path.abspath(__file__)
        algo_dir = os.path.join(os.getcwd(), "results",
                                os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files


if __name__ == "__main__":
    result = ElasticWave2DEquationAlgorithm().run()
    print("执行完成:", list(result.keys()))
