"""
Ornstein-Uhlenbeck Process (OU Process) Algorithm Module

Solve the Ornstein-Uhlenbeck process based on the Schrödingerization method.
"""
from .algorithm import OUProcessEquationAlgorithm

# ========== 算法元数据 (必需) ==========
# 算法注册名称 - 用于 API 调用（使用文件夹名称）
ALGORITHM_NAME = "OUprocess"

# 算法类 - 必须继承 BaseAlgorithm
ALGORITHM_CLASS = OUProcessEquationAlgorithm

# 算法描述 (可选)
ALGORITHM_DESCRIPTION = "基于 Schrödingerization 方法求解 Ornstein-Uhlenbeck 过程"

__all__ = ["OUProcessEquationAlgorithm", "ALGORITHM_NAME", "ALGORITHM_CLASS", "ALGORITHM_DESCRIPTION"]
