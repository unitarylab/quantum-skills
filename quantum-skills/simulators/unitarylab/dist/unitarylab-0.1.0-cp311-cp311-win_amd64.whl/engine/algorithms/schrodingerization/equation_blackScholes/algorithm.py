"""
Black-Scholes Equation Algorithm Module

Solve the one-dimensional Black-Scholes equation based on the Schrödingerization method:
∂u/∂t + (1/2)σ²S²∂²u/∂S² + rS∂u/∂S - ru = 0
"""

# ==========================================================
# 这里是服务器server需要用的导言区，作对应调整
from typing import Dict, Any, List, Optional
import time
import os
import sys

import numpy as np
from ..algo_base import BaseAlgorithm

# 使用非交互式后端，避免服务器端显示问题
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

from engine import GateSequence
from engine.library import parse_equation


# ==========================================================
# 方程运行函数

class BlackScholesEquationAlgorithm(BaseAlgorithm):
    """Black-Scholes Equation Algorithm

    Solve the one-dimensional Black-Scholes equation based on the Schrödingerization method:

    ∂u/∂t + (1/2)σ²S²∂²u/∂S² + rS∂u/∂S - ru = 0

    Supported solution methods:

    - Classical: Classical matrix exponentiation method

    - Trotter: Trotter decomposition method
    """

    def run(self, params: Optional[str] = None) -> Dict[str, Any]:
        """
       Execute the Black-Scholes equation solving algorithm

        :param params: JSON string parameters containing equation configuration and solution method configuration

        :return: Algorithm execution result
        """
        self.logger.info("=" * 50)
        self.logger.info("阶段 1/5: 开始解析 Black-Scholes 方程参数...")
        try:
            eq = parse_equation(params)
        except Exception as e:
            self.logger.error(f"参数解析失败: {e}")
            raise e

        # 解析求解方法，根据求解方法不同调用不同的函数
        method = eq.solver.type
        if method == 'classical':
            return self._solve_classical(eq)
        elif method == 'trotter':
            return self._solve_trotter(eq)
        else:
            raise ValueError(f'method {method} is not supported!')

    def _solve_classical(self, eq):
        from engine.library import schro_classical as schro
        from engine.library.schrodingerization.classical import circuit_classical

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        r = eq.get_parameter('r')
        sigma = eq.get_parameter('σ')
        K = eq.get_parameter('K')

        L1 = eq.get_parameter('L1', np.log(1e-4))
        L2 = eq.get_parameter('L2', np.log(10 * K))

        Nx = 2**nx
        dx = (L2 - L1) / (Nx + 1)


        #x = np.arange(L1 + dx, L2, step=dx)
        x = np.linspace(L1 + dx, L2 - dx, Nx)





        u0 = f0(x)
        scale_b = K * (0.5 * sigma**2 / (dx**2) + 0.25 * (-sigma**2 + 2 * r) / dx)
        u0 = np.concatenate((u0, np.ones(Nx) * scale_b))

        self.logger.info(f"  - 无风险利率 r = {r}")
        self.logger.info(f"  - 波动率 σ = {sigma}")
        self.logger.info(f"  - 执行价格 K = {K}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建差分矩阵 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建差分矩阵...")

        from scipy.sparse import csc_matrix, eye
        from engine.library.differential_operator.classical_matrices import first_order_derivative, second_order_derivative
        A1, b1 = first_order_derivative(N=Nx, dx=dx)
        A2, b2 = second_order_derivative(N=Nx, dx=dx)
        A = (r - 0.5 * sigma**2) * A1 + 0.5 * sigma**2 * A2
        A.resize(2 * Nx, 2 * Nx)
        A = A + csc_matrix(([-1], ([Nx-1], [2*Nx-1])), shape=(2 * Nx, 2 * Nx))
        A = A - r * eye(2 * Nx)

        dim = A.shape[0] // 2

        self.logger.info("阶段 2/5: 差分矩阵构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始计算...")

        start_time = time.time()
        u = schro(A, u0, T=T, na=na, R=R, order=order, point=point)
        qc = circuit_classical(nx+1, na)
        end_time = time.time()

        u = u[:dim] + np.exp(x)

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        end = int((np.log(2*K)-L1) / dx)
        name = f"1D Black Scholes Classical nx={nx} na={na} T={T}"
        solution_plot_path = self._generate_solution_plot(name, np.exp(x[:end]), u[:end], xlabel='S', ylabel='Option Price')

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Black-Scholes equation solved",
            "grid": {"n_points": 2**nx, "dx": dx},
            "x": np.exp(x[:end]).tolist(),
            "u": u[:end].tolist(),
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _solve_trotter(self, eq):
        from engine.library import schro_trotter as schro
        from engine.library import TDiff

        # ========== 阶段1: 不同方法对应参数 ==========
        # 解析方程特有参数
        L, T, source, nx, na, R, point, order, f0 = eq.get_common_coefficients()
        derivative = eq.get_derivative_1d()
        bd = eq.boundary.type
        scheme = eq.discrete.type
        r = eq.get_parameter('r')
        sigma = eq.get_parameter('σ')
        K = eq.get_parameter('K')
        dt = eq.solver.dt
        Nt = int(T / dt)

        L1 = eq.get_parameter('L1', np.log(1e-4))
        L2 = eq.get_parameter('L2', np.log(10 * K))

        Nx = 2**nx
        dx = (L2 - L1) / (Nx + 1)


        #x = np.arange(L1 + dx, L2, step=dx)
        x = np.linspace(L1 + dx, L2 - dx, Nx)


        u0 = f0(x)
        scale_b = K * (0.5 * sigma**2 / (dx**2) + 0.25 * (-sigma**2 + 2 * r) / dx)
        u0 = np.concatenate((u0, np.ones(Nx) * scale_b))

        self.logger.info(f"  - 无风险利率 r = {r}")
        self.logger.info(f"  - 波动率 σ = {sigma}")
        self.logger.info(f"  - 执行价格 K = {K}")
        self.logger.info(f"  - 最终时间 T = {T}")
        self.logger.info(f"  - 时间步长 dt = {dt}")
        self.logger.info(f"  - 空间量子比特数 nx = {nx}")
        self.logger.info(f"  - 辅助量子比特数 na = {na}")
        self.logger.info("阶段 1/5: 参数解析完成 ✓")

        # ========== 阶段2: 构建量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 2/5: 开始构建量子电路...")

        gamma1 = -dt / dx
        gamma2 = -2 * dt / dx**2

        H1 = GateSequence(nx+1)
        func1 = (sigma**2 / 2 * TDiff(n=nx, dx=dx, order=2)).data()[0]
        H1.append(func1(dt/R), target=range(nx), control=nx, control_sequence='0')
        H1.mcrx(dt/R, range(nx), nx)
        H1.gp(-r * dt / R)

        H2 = GateSequence(nx+1)
        func2 = ((r-sigma**2/2) * TDiff(n=nx, dx=dx, order=1)).data()[1]
        H2.append(func2(dt), target=range(nx), control=nx, control_sequence='0')
        H2.mcry(dt, range(nx), nx)

        self.logger.info("阶段 2/5: 量子电路构建完成 ✓")

        # ========== 阶段3: 执行量子电路 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 3/5: 开始执行量子电路...")
        self.logger.info(f"  - 总时间步数: {Nt}")

        start_time = time.time()
        u, qc = schro(u0=u0, H1=H1, H2=H2, R=R, na=na, Nt=Nt, order=order, point=point)
        end_time = time.time()

        u = u[:Nx] + np.exp(x)

        self.logger.info(f"  - 实际计算耗时: {end_time - start_time:.4f} 秒")
        self.logger.info("阶段 3/5: 量子电路执行完成 ✓")

        # ========== 阶段4: 生成解的图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 4/5: 开始生成解的可视化图...")

        end = int((np.log(2*K)-L1) / dx)
        name = f"1D Black Scholes Lie-Trotter nx={nx} na={na} T={T} dt={dt}"
        solution_plot_path = self._generate_solution_plot(name, np.exp(x[:end]), u[:end], xlabel='S', ylabel='Option Price')

        self.logger.info("阶段 4/5: 解的可视化图生成完成 ✓")

        # ========== 阶段5: 生成电路图 ==========
        self.logger.info("=" * 50)
        self.logger.info("阶段 5/5: 开始生成量子电路图...")

        circuit_plot_paths = self._generate_circuit_plots(name, qc, H1, H2)

        self.logger.info("阶段 5/5: 量子电路图生成完成 ✓")

        # ========== 完成 ==========
        self.logger.info("=" * 50)
        self.logger.info("所有阶段完成，计算成功！")
        self.logger.info("=" * 50)

        return {
            "status": "ok",
            "message": "Black-Scholes equation solved",
            "grid": {"n_points": 2**nx, "dx": dx, "dt": dt, "nt": Nt},
            "x": np.exp(x[:end]).tolist(),
            "u": u[:end].tolist(),
            "circuit": circuit_plot_paths,
            "plot": {
                "format": "svg",
                "filename": solution_plot_path,
            },
        }

    def _generate_solution_plot(
        self,
        name: str,
        x,
        u,
        xlabel: str = 'x',
        ylabel: str = 'u(x, t)',
        format: str = 'svg'
    ) -> str:
        """
        Generate a graph of the calculation results and save it to the algorithm folder.

        :param x: Spatial grid points

        :param u: Final solution

        :param name: Graph title

        :param xlabel: x-axis label

        :param ylabel: y-axis label

        :return: Filename to save the graph (relative to the algorithm folder)
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        # 创建图像
        fig, ax = plt.subplots(figsize=(10, 6), dpi=100)

        # 绘制解曲线
        ax.plot(x, u, "b-", linewidth=2, label=f"u")
        ax.fill_between(x, u, alpha=0.3)

        # 设置标题和标签
        ax.set_title(f"{name}", fontsize=14)
        ax.set_xlabel(xlabel, fontsize=12)
        ax.set_ylabel(ylabel, fontsize=12)
        ax.legend(loc="upper right")
        ax.grid(True, alpha=0.3)

        # 将图像保存到算法文件夹
        filename = f'{name.replace(" ", "_")}_solution.{format}'
        solution_path = os.path.join(algo_dir, filename)
        fig.savefig(solution_path, format=format, bbox_inches="tight", facecolor="white")

        # 清理资源
        plt.close(fig)

        self.logger.debug(f"计算结果图已保存到: {solution_path}")

        # 返回文件名（相对路径）
        return filename

    def _generate_circuit_plots(
        self,
        name: str,
        qc: GateSequence,
        H1: Optional[GateSequence] = None,
        H2: Optional[GateSequence] = None,
        format: str = 'svg'
    ) -> list:
        """
        Generate multiple quantum circuit diagrams and save them to the algorithm folder.

        :param qc: Quantum circuit

        :param H1: Quantum circuit

        :param H2: Quantum circuit

        :param name: Diagram title

        :return: List of saved file information
        """
        # 获取算法文件所在目录
        algo_dir = os.path.dirname(os.path.abspath(__file__))
        
        circuit_files = []
        base_name = name.replace(" ", "_")
        
        # 生成完整电路图
        filename1 = f'{base_name}_circuit_full.{format}'
        circuit_path1 = os.path.join(algo_dir, filename1)
        qc.draw(filename=circuit_path1, title=f"{name} (Schro)")
        circuit_files.append({
            "format": format,
            "filename": filename1,
        })
        
        # 生成H1电路图
        if H1:
            filename2 = f'{base_name}_circuit_H1.{format}'
            circuit_path2 = os.path.join(algo_dir, filename2)
            H1.decompose().draw(filename=circuit_path2, title=f"{name} (H1)")
            circuit_files.append({
                "format": format,
                "filename": filename2,
            })
        
        # 生成H2电路图
        if H2:
            filename3 = f'{base_name}_circuit_H2.{format}'
            circuit_path3 = os.path.join(algo_dir, filename3)
            H2.decompose().draw(filename=circuit_path3, title=f"{name} (H2)")
            circuit_files.append({
                "format": format,
                "filename": filename3,
            })

        self.logger.debug(f"量子电路图已保存到: {algo_dir}")
        self.logger.info(f"共生成 {len(circuit_files)} 个量子电路图")
        return circuit_files