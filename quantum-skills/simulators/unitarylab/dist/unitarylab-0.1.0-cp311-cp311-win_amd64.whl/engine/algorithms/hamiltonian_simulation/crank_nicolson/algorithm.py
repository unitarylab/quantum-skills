import time
from typing import Dict, Any

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

# ==========================================================
# Crank-Nicolson 演化算法类实现 (标准化模板)
# ==========================================================

class CrankNicolsonAlgorithm:
    """
    Crank-Nicolson Evolutionary Algorithm Module (Classical Matrix Simulation)

    Given Hamiltonian H, the simulation format is:

    e^{-iH \Delta t} \approx (I + i \frac{\Delta t}{2} H)^{-1}(I - i \frac{\Delta t}{2}H)
    """
    def __init__(self):
        # 严格遵守：INFO 后面不加额外英文
        self.log_prefix = "INFO: " 
        self.last_result = {}

    def run(self, H: sp.spmatrix, dt: float, psi0: np.ndarray, steps: int) -> Dict[str, Any]:
        """Execution of Crank-Nicolson matrix construction and state evolution logic"""
        print("=" * 70)
        print(f"{self.log_prefix}启动 Crank-Nicolson 演化 (步长={dt}, 步数={steps})")
        print("=" * 70)

        # ================= 阶段 1: 准备参数 =================
        print(f"{self.log_prefix}阶段 1/4: 准备参数与解析...")
        N = H.shape[0]
        total_time = dt * steps
        print(f"  - 系统维度 (N): {N}")
        print(f"  - 时间步长 (dt): {dt}")
        print(f"  - 演化步数: {steps}")
        print(f"  - 总演化时间: {total_time:.4f}")
        
        # ================= 阶段 2: 构建演化算子 (不输出时间) =================
        print(f"{self.log_prefix}阶段 2/4: 构建演化矩阵与 LU 分解...")
        
        # 构建 A 和 B 矩阵
        I = sp.identity(N, format="csr")
        A = I + 1j * dt / 2 * H
        B = I - 1j * dt / 2 * H
        
        # 对 A 做 LU 分解，返回一个函数 solver(b) 求解 A^{-1}
        solver = spla.factorized(A)
        
        print(f"{self.log_prefix}演化算子构建完成")

        # ================= 阶段 3: 运行态演化 (仅计算这一步的时间) =================
        print(f"{self.log_prefix}阶段 3/4: 运行态矢量迭代演化...")
        
        exec_start_time = time.time()
        
        # ---------------------------------------------------------
        # 核心迭代求解逻辑
        # ---------------------------------------------------------
        psi = psi0.copy()
        for _ in range(steps):
            psi = solver(B @ psi)
            
        exec_time = time.time() - exec_start_time
        
        print(f"  - 运行演化耗时: {exec_time:.6f} 秒")

        # ================= 阶段 4: 结果汇总 =================
        print(f"{self.log_prefix}阶段 4/4: 汇总结果 (仅内存返回)...")

        # 统一状态更新
        self._update_last_result(
            N=N, dt=dt, steps=steps, total_time=total_time, exec_time=exec_time
        )

        return {
            "status": "success",
            "final_state": psi,
            "plot": self.format_result_ascii()
        }

    # ==========================================================
    # 核心辅助模块
    # ==========================================================

    def _update_last_result(self, **kwargs):
        """Unified result dictionary update"""
        self.last_result = kwargs

    def format_result_ascii(self) -> str:
        """Formatted output standard ASCII panel"""
        if not self.last_result: return "无运行记录"
        r = self.last_result
        return f"""
{'='*70}
{' '*15}🌊 Crank-Nicolson 演化执行结果 🌊
{'='*70}
📊 配置信息:
  - 系统维度: {r['N']}
  - 时间步长 (dt): {r['dt']}
  - 演化步数: {r['steps']}
  - 总演化时间: {r['total_time']:.4f}
{'─'*70}
⚡ 性能与资源统计:
  - 态矢量演化耗时: {r['exec_time']:.6f} 秒
  - 最终态输出: (仅内存返回，未生成文件)
{'='*70}
"""

# ==========================================================
# Main 测试入口
# ==========================================================

if __name__ == "__main__":
    # 测试用例：构造一个简单的 4x4 紧束缚哈密顿量模型
    dim = 4
    diagonals = [[-1.0]*(dim-1), [2.0]*dim, [-1.0]*(dim-1)]
    H_test = sp.diags(diagonals, [-1, 0, 1], format='csr', dtype=complex)
    
    # 初始化状态：粒子完全集中在第一个格点 |0>
    psi_init = np.zeros(dim, dtype=complex)
    psi_init[0] = 1.0
    
    # 实例化并运行算法
    cn_algo = CrankNicolsonAlgorithm()
    
    # 运行算法 (仅内存计算)
    result = cn_algo.run(
        H=H_test, 
        dt=0.05, 
        psi0=psi_init, 
        steps=100
    )
    
    # 打印标准化结果面板
    print(result['plot'])
    
    # (可选) 打印验证末态概率分布是否归一化
    final_prob = np.abs(result['final_state'])**2
    print(f"INFO: 验证末态概率分布: {final_prob.round(4)}, 总概率和: {np.sum(final_prob):.6f}")