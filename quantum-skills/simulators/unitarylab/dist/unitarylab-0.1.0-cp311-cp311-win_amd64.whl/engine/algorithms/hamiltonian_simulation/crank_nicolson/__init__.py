"""
Crank-Nicolson Module
===========================
"""

from .algorithm import CrankNicolsonAlgorithm

__all__ = [
    'CrankNicolsonAlgorithm',
]