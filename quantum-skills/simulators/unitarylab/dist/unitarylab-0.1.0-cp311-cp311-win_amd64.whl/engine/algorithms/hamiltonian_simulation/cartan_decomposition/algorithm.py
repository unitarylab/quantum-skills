import time
import os
from typing import Dict, Any, List, Tuple

# ==========================================================
# Cartan 分解算法类实现
# ==========================================================

class CartanDecompositionAlgorithm:
    """
    The Cartan decomposition algorithm module partitions Lie algebras into symmetric subalgebras k and antisymmetric spaces m.
    """
    def __init__(self):
        self.log_prefix = "INFO: [Cartan] "
        self.last_result = None

    def run(self, pauli_list: List[str], target_involution: str = None) -> Dict[str, Any]:
        """
        Perform Cartan decomposition

        Args:

        pauli_list: List of input Pauli strings

        target_involution: Reference string used for involution definition (defaults to all Z)
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Cartan 分解 (输入算子数: {len(pauli_list)})")
        print("=" * 70)

        start_time = time.time()

        # 1. 自动生成参考算子 (Involution Target)
        n_qubits = len(pauli_list[0])
        if target_involution is None:
            target_involution = 'Z' * n_qubits
        
        print(f"{self.log_prefix}阶段 1/2: 使用参考算子 {target_involution} 进行内对合...")

        # 2. 执行基于反对易计数的物理分解
        k_set, m_set = self._real_cartan_decomp(pauli_list, target_involution)
        
        comp_time = time.time() - start_time
        
        print(f"{self.log_prefix}阶段 2/2: 分解完成 (k:{len(k_set)}, m:{len(m_set)})")

        self.last_result = {
            "n_qubits": n_qubits,
            "target": target_involution,
            "input_count": len(pauli_list),
            "k_size": len(k_set),
            "m_size": len(m_set),
            "comp_time": comp_time,
            "k_list": k_set,
            "m_list": m_set
        }

        return {
            "status": "ok",
            "k_set": k_set,
            "m_set": m_set,
            "plot": self.format_result_ascii()
        }

    # ==========================================================
    # 核心物理逻辑：基于 Pauli 串的对易关系
    # ==========================================================

    def _real_cartan_decomp(self, pauli_list: List[str], target: str):
        """
        Strict physical definitions:

        k-space (Symmetric): Commutes with target [P, T] = 0

        m-space (Anti-symmetric): Anti-commutates with target {P, T} = 0
        """
        anticommute_pairs = {
            ('X','Y'), ('Y','X'), ('Y','Z'), ('Z','Y'), ('Z','X'), ('X','Z'),
        }
        
        k, m = [], []
        for p in pauli_list:
            # 计算 p 和 target 在对应位上属于 'anticommute_pairs' 的个数
            # 只有当两个位都不为 'I' 且不同时，才可能反对易
            anticomm_count = sum(
                (a, b) in anticommute_pairs for a, b in zip(p, target)
            )
            
            # 物理定律：奇数个位反对易则整体反对易 (m)，偶数个位反对易则整体对易 (k)
            if anticomm_count % 2 == 1:
                m.append(p)
            else:
                k.append(p)
        return k, m

    def format_result_ascii(self) -> str:
        """Formatted output panel"""
        if not self.last_result: return "无运行记录"
        r = self.last_result
        return f"""
{'='*70}
{' '*15}⚔️  CARTAN 分解执行结果 ⚔️
{'='*70}
📊 基本信息:
  - 量子比特数: {r['n_qubits']}
  - 参考算子 (Target): {r['target']}
  - 输入算子总数: {r['input_count']}
{'─'*70}
🔍 分解详情:
  - 子代数 𝔨 (Symmetric/对易): {r['k_size']} 个项
    样本: {r['k_list'][:5]}
  - 空间 𝔪 (Anti-symmetric/反对易): {r['m_size']} 个项
    样本: {r['m_list'][:5]}
{'─'*70}
⚡ 性能统计:
  - 计算总耗时: {r['comp_time']:.6f} 秒
{'='*70}
"""

# ==========================================================
# Main 测试入口
# ==========================================================

if __name__ == "__main__":
    # 构造一个能产生 4:4 分解的测试集
    # target 默认是 'ZZ'
    test_paulis = [
        'II', 'IZ', 'ZI', 'ZZ',  # 偶数个反对易位(0) -> 属于 k
        'XI', 'IX',              # 奇数个反对易位(1) -> 属于 m
        'YI', 'IY'               # 奇数个反对易位(1) -> 属于 m
    ]
    
    algo = CartanDecompositionAlgorithm()
    result = algo.run(test_paulis)
    print(result['plot'])