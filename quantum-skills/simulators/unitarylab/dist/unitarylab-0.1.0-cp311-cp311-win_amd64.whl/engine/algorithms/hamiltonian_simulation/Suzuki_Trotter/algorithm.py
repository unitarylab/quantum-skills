import os
import time
from typing import Dict, Any, List, Tuple

# 导入项目核心组件
from ....core import GateSequence, Register
from setuptools.errors import ClassError 

# ==========================================================
# Suzuki-Trotter 演化算法类实现 (标准化模板)
# ==========================================================

class SuzukiTrotterAlgorithm:
    """
    The Suzuki-Trotter evolution algorithm module supports higher-order Trotter decomposition for simulating Hamiltonian evolution e^{-iHt}.
    """
    def __init__(self, order: int = 1, reps: int = 1):
        if order > 1 and order % 2 == 1:
            raise ValueError("Trotter 阶数必须为 1 或者偶数！")
        
        self.order = order
        self.reps = reps
        # 严格遵守：INFO 后面不加额外英文
        self.log_prefix = "INFO: " 
        self.last_result = {}

    def run(self, grouped_paulis: List[List[Tuple[str, float]]], total_time: float, backend: str = 'torch',
            algo_dir = None) -> Dict[str, Any]:
        """Execute Trotter circuit construction and evolution logic"""
        print("=" * 70)
        print(f"{self.log_prefix}启动 Suzuki-Trotter 演化 (阶数={self.order}, 步数={self.reps}，后端为：{backend})")
        print("=" * 70)

        # ================= 阶段 1: 准备参数 =================
        print(f"{self.log_prefix}阶段 1/4: 准备参数与解析...")
        n_qubits = len(grouped_paulis[0][0][0])
        print(f"  - 量子比特数: {n_qubits}")
        print(f"  - 总演化时间: {total_time}")
        
        # ================= 阶段 2: 构建电路 (不输出时间) =================
        print(f"{self.log_prefix}阶段 2/4: 构建量子逻辑门电路...")
        full_sequence = self._expand(grouped_paulis, total_time)
        print(f"  - 分解完成，总项数: {len(full_sequence)}")
        
        rk = Register('K', n_qubits)
        gs = GateSequence(rk, name=f'Trotter_O{self.order}_R{self.reps}', backend=backend)
        
        for step_group in full_sequence:
            for pauli_str, coeff in step_group:
                gate = self._PauliEvolutionGate(n_qubits, pauli_str, -coeff, backend=backend)
                gs.append(gate, range(n_qubits))
                
        print(f"{self.log_prefix}电路构建完成")

        # ================= 阶段 3: 运行电路 (仅计算这一步的时间) =================
        print(f"{self.log_prefix}阶段 3/4: 运行电路...")
        
        exec_start_time = time.time()
        
        # ---------------------------------------------------------
        # 在这里执行你的底层模拟器调用，例如：gs.execute() 或取态矢量
        # ---------------------------------------------------------
        
        exec_time = time.time() - exec_start_time
        
        print(f"  - 运行电路耗时: {exec_time:.6f} 秒")

        # ================= 阶段 4: 导出与保存 =================
        print(f"{self.log_prefix}阶段 4/4: 导出结果与保存...")
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"Trotter_order{self.order}.svg")
        
        try:
            # gs.decompose().draw(filename=circuit_path)
            pass
        except Exception as e:
            print(f"  - 绘图跳过或失败: {e}")

        # 统一状态更新
        self._update_last_result(
            n_qubits=n_qubits, total_time=total_time, backend=backend, 
            exec_time=exec_time, term_count=len(full_sequence), circuit_path=circuit_path
        )

        return {
            "status": "success",
            "circuit": gs,
            "plot": self.format_result_ascii()
        }

    # ==========================================================
    # 核心辅助模块
    # ==========================================================

    def _update_last_result(self, **kwargs):
        """Unified result dictionary update"""
        self.last_result = {
            "order": self.order,
            "reps": self.reps,
            **kwargs
        }

    def _PauliEvolutionGate(self, n, s, theta, backend='torch'):
        """Custom Pauli Evolution Gate"""
        if not isinstance(s, str):
            raise TypeError('s should be a string.') 
        s_list = list(s)
        if len(s_list) != n:
            raise ValueError('The length of the string must be equal to the number of qubits.')
            
        idx = [i for i, p in enumerate(s_list) if p != 'I']
        if not idx:
            return GateSequence(n, backend=backend)
            
        gs = GateSequence(n, backend=backend)
        
        for i in range(n):
            if s_list[i] == 'X':
                gs.h(i)
            elif s_list[i] == 'Y':
                gs.sdag(i)
                gs.h(i)
                
        for i in range(len(idx) - 1):
            gs.cnot(idx[i], idx[i + 1])
            
        gs.rz(2 * theta, idx[-1]) 
        
        for i in range(len(idx) - 1, 0, -1):
            gs.cnot(idx[i - 1], idx[i])
            
        for i in range(n):
            if s_list[i] == 'X':
                gs.h(i)
            elif s_list[i] == 'Y':
                gs.h(i)
                gs.s(i)
        return gs
    
    def _recurse(self, order: int, grouped_paulis: List[List[Tuple[str, float]]]):
        """Core recursive logic"""
        if order == 1:
            return grouped_paulis
        elif order == 2:
            halves = [[(p, c/2) for p, c in paulis] for paulis in grouped_paulis[:-1]]
            full = [grouped_paulis[-1]]
            return halves + full + list(reversed(halves))
        else:
            reduction = 1 / (4 - 4 ** (1 / (order - 1)))
            outer_base = self._recurse(order - 2, [
                [(p, c * reduction) for p, c in paulis] for paulis in grouped_paulis
            ])
            outer = outer_base + outer_base
            inner = self._recurse(order - 2, [
                [(p, c * (1 - 4 * reduction)) for p, c in paulis] for paulis in grouped_paulis
            ])
            return outer_base + outer_base + inner + outer_base + outer_base

    def _expand(self, grouped_paulis, time_val):
        """Scaling factor and repeat based on reps"""
        scaled_list = [[(p, c * time_val / self.reps) for p, c in paulis] for paulis in grouped_paulis]
        unit_sequence = self._recurse(self.order, scaled_list)
        return unit_sequence * self.reps

    def format_result_ascii(self) -> str:
        """Formatted output standard ASCII panel"""
        if not self.last_result: return "无运行记录"
        r = self.last_result
        return f"""
{'='*70}
{' '*15}🌀 Suzuki-Trotter 演化执行结果 🌀
{'='*70}
📊 配置信息:
  - 计算后端: {r['backend']}
  - 分解阶数: {r['order']}
  - 迭代步数: {r['reps']}
  - 量子比特数: {r['n_qubits']}
  - 总演化时间: {r['total_time']}
{'─'*70}
⚡ 性能与资源统计:
  - 运行电路耗时: {r['exec_time']:.6f} 秒
  - 生成总项数: {r['term_count']} 项
  - 导出路径: {r['circuit_path']}
{'='*70}
"""

# ==========================================================
# Main 测试入口
# ==========================================================

if __name__ == "__main__":
    hamiltonian = [
        [("XX", 0.5)],
        [("YY", 0.3)]
    ]
    
    trotter = SuzukiTrotterAlgorithm(order=2, reps=5)
    
    result = trotter.run(grouped_paulis=hamiltonian, total_time=1.0, backend='torch')
    
    print(result['plot'])