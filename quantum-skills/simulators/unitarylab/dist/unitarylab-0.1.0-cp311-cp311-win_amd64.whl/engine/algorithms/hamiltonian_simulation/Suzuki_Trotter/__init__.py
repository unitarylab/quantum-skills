"""
Suzuki-Trotter Decomposition Module
===================================

Implementation of higher-order Suzuki-Trotter product formulas for 
Hamiltonian simulation.
"""

from .algorithm import SuzukiTrotterAlgorithm

__all__ = [
    'SuzukiTrotterAlgorithm',
]