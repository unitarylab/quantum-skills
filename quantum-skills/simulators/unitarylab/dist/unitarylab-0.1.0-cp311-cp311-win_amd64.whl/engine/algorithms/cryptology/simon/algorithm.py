import time
import os
import sys
import numpy as np
from typing import Dict, Any, Optional

# 导入项目核心组件
from ....core import GateSequence, Register, State,ClassicalRegister

# ==========================================================
# Simon 算法类实现
# ==========================================================

class SimonAlgorithm:
    """
    Simon Algorithm Module (Standalone Class Version)

    Encapsulates the entire process of quantum circuit construction, execution, and classical post-processing to solve for s,

    including standardized stage log output and an ASCII results panel.
    """
    def __init__(self):
        # 统一日志前缀与状态保存
        self.log_prefix = "INFO: "
        self.last_result = None

    def run(self, s_target: str = '1010', backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        """
        Modifiable input parameters params:

        - s_target: Secret string s (defaults to '1010')

        - backend: Simulation backend (currently only 'torch' is supported)

        - algo_dir: Directory for saving the quantum circuit diagram

        return: A dictionary containing the algorithm's execution results, including the found s, the graph path, and the formatted ASCII panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Simon 算法主程序 (目标掩码 s={s_target}, 后端={backend.upper()})")
        print("=" * 70)

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 开始准备 Simon 算法参数...")
        
        # 验证输入字符串
        n = len(s_target)
        if s_target.find('1') == -1:
            raise ValueError("秘密字符串 s 不能为全 0 串！")
            
        print(f"  - 秘密字符串 s: {s_target}")
        print(f"  - 寄存器大小: n = {n} (总计 {2*n} 量子比特)")
        print(f"  - 预设模拟后端: {backend}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路 (后端: {backend})...")
        
        # 后端版本校验（强制要求 torch）
        if backend != 'torch':
            raise ValueError(f"Simon 算法目前仅支持 'torch' 后端进行含测量模拟，当前输入为: {backend}")
        
        rx = Register('x', n)
        ry = Register('y', n)
        cqr=ClassicalRegister('cr',n)
        gs = GateSequence(rx, ry,cqr, name=f'Simon_{s_target}', backend=backend)

        # Simon 核心线路步骤
        gs.h(rx[:]) 
        self._build_simon_oracle(gs, s_target)
        gs.measure(ry[:],cqr[:]) # Simon 算法中途包含测量
        gs.h(rx[:])
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        start_time = time.time()
        re_state = gs.execute()
        state_obj = State(re_state)
        # 获取 x 寄存器的测量概率分布
        state_basis_dict = state_obj.calculate_state(range(n))
        end_time = time.time()
        comp_time = end_time - start_time

        print(f"  - 计算耗时: {comp_time:.4f} 秒")
        print(f"  - 测量得到有效基态数量: {len(state_basis_dict)}")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 开始执行经典后处理 (解线性方程组)...")
        
        # 1. 提取线性无关的基向量
        basis = self._get_basis_simple(list(state_basis_dict.keys()), n)
        # 2. 回代求解 s
        found_s = self._solve_simon_general(basis, n)
        is_success = (found_s == s_target)
        
        print(f"  - 提取线性无关方程数: {len(basis)}")
        print(f"  - 计算求得结果 s: {found_s}")
        print(f"  - 结果验证: {'成功' if is_success else '失败'}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        # 确保保存目录存在
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        circuit_filename = f"Simon_s_{s_target}_circuit.svg"
        circuit_path = os.path.join(algo_dir, circuit_filename)
        
        # 使用项目内置的 draw 功能保存电路图
        gs.draw(filename=circuit_path, title=f"Simon Algorithm (s={s_target})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        # ================= 结果包装 =================
        msg = "算法执行成功，成功推导出隐藏掩码 s。" if is_success else "算法求解失败，推导得出的 s 与目标不匹配。"
        
        # 更新内部状态，供 ASCII 面板使用
        self._update_last_result(
            s_target=s_target, n=n, backend=backend,
            comp_time=comp_time, valid_states=len(state_basis_dict),
            equations=len(basis), found_s=found_s, is_success=is_success,
            circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(found_s, is_success, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, s_target, n, backend, comp_time, valid_states, equations, found_s, is_success, circuit_path, msg):
        """The internal state is saved uniformly for format_result_ascii rendering."""
        self.last_result = {
            "s_target": s_target, "n": n, "backend": backend,
            "comp_time": comp_time, "valid_states": valid_states,
            "equations": equations, "found_s": found_s,
            "is_success": is_success, "circuit_path": circuit_path,
            "message": msg
        }

    def _build_return(self, found_s, is_success, circuit_path, msg):
        """Unified construction of returned dictionaries"""
        return {
            "status": "ok" if is_success else "failed",
            "found_s": found_s,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        """Format the result of the last executed algorithm into beautiful ASCII art."""
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        
        r = self.last_result
        status_emoji = '✅' if r['is_success'] else '❌'
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  SIMON 算法执行结果 ⚛️
{'='*70}

📊 执行状态: {status_emoji} {'成功寻找隐藏掩码 s' if r['is_success'] else '寻找掩码 s 失败'}

{'─'*70}
🔢 输入参数
{'─'*70}
  目标掩码 s: {r['s_target']}
  寄存器大小 n: {r['n']}
  模拟后端: {r['backend'].upper()}
{'─'*70}
⚡ 量子电路配置
{'─'*70}
  总量子比特数: {2 * r['n']} (x: {r['n']}, y: {r['n']})
{'─'*70}
🎯 量子计算结果
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
  测量得到有效态数量: {r['valid_states']}
  提取线性无关方程数: {r['equations']}
{'─'*70}
🔓 经典后处理结果
{'─'*70}
"""
        if r['is_success']:
            ascii_art += f"""  ✓ 求解成功！
  推导得出的 s: {r['found_s']}
  结果验证: {r['found_s']} == {r['s_target']} ✓
"""
        else:
            ascii_art += f"""  ✗ 求解失败！
  推导得出的 s: {r['found_s']}
  结果验证: {r['found_s']} != {r['s_target']} ✗
"""
            
        ascii_art += f"""{'─'*70}
📁 输出文件
{'─'*70}
  量子电路图: {r['circuit_path'] if r.get('circuit_path') else '无'}
{'─'*70}
💡 执行备注
{'─'*70}
  {r['message']}
{'='*70}
🔬 量子计算模拟器 | Simon 算法模块
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件与经典解方程辅助函数
    # ==========================================================

    def _build_simon_oracle(self, gs, s):
        """Constructing the Oracle U_f for the Simon algorithm"""
        n = len(s)
        for i in range(n-1, -1, -1):
            gs.cx(i, i+n)
        
        pivot_idx = s.find('1')
        for i in range(n):
            if s[i] == '1':
                gs.cx(n-1-pivot_idx, n-1-i+n)

    def _get_basis_simple(self, state_list, n_qubits):
        """Select vectors from the list of ground states that have different principal component positions."""
        basis_list, seen_pivots = [], set()
        for bin_str in state_list:
            pivot = bin_str.find('1')
            if pivot != -1 and pivot not in seen_pivots:
                seen_pivots.add(pivot)
                basis_list.append(bin_str)
            if len(basis_list) == n_qubits - 1:
                break
        return basis_list

    def _solve_simon_general(self, basis_list, n):
        """Solving by back substitution of linearly independent vector groups s"""
        s_vec = [0] * n
        pivot_map = {y.find('1'): y for y in basis_list if y.find('1') != -1}
        free_idx = next((i for i in range(n) if i not in pivot_map), -1)
        
        if free_idx == -1: return "Error"
        s_vec[free_idx] = 1
        
        for p in sorted(pivot_map.keys(), reverse=True):
            y_vec = pivot_map[p]
            dot_sum = 0
            for j in range(p + 1, n):
                if y_vec[j] == '1': dot_sum ^= s_vec[j]
            s_vec[p] = dot_sum
        return "".join(map(str, s_vec))

if __name__ == "__main__":
    simon = SimonAlgorithm()
    result = simon.run(s_target='1101', backend='torch')
    print(result['plot'])