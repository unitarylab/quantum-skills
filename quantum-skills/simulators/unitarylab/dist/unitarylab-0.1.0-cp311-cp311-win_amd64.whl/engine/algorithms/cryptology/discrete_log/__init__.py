"""
discrete log  Algorithm Module
========================

Implementation of Simon's algorithm for finding hidden periods.
"""

from .algorithm import DiscreteLogAlgorithm

__all__ = [
    'DiscreteLogAlgorithm',
]
