import os
import sys
import time
import math
import random
from fractions import Fraction
import numpy as np
from typing import Dict, Any, Optional, List

# 导入项目核心组件
from ....core import GateSequence, Register, State
from ....library import QFT, IQFT

class ShorAlgorithm:
    """
    Shor's Algorithm Module (Standalone Class Version)

    Supports both matrix and operator methods.

    Includes complete automatic retry logic to ensure the `run()` method runs to completion and returns the final result.
    """
    def __init__(self):
        self.last_result = None
        self.log_prefix = "INFO: "

    def run(self, N: int, method: str = 'matrix', backend: str = 'torch', max_retries: int = 15, algo_dir: str = './shor_results') -> Dict[str, Any]:
        """
        Modifiable input parameters `params`:

            - N: The composite number to be decomposed (e.g., 15)

            - method: The solution method, optional 'matrix' or 'operator' (modular multiplication operator method)

            - backend: The simulation backend (currently only 'torch' is supported)

            - algo_dir: The directory to save the quantum circuit diagram

        return: A dictionary containing the algorithm's execution results, with the following structure:

            - "status" (str): The running status, "ok" for success.

            - "factors" (list): The list of prime factors obtained at the end.

            - "period" (int/None): The period r calculated by the algorithm; None for classical decomposition.

            - "circuit_path" (str/None): The local save path for the generated quantum circuit diagram (SVG format).

            - "message" (str): Runtime comments indicating whether the decomposition was performed using the quantum circuit or classical path.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Shor 算法主程序 (待分解数 N={N}, 模式={method.upper()}, 后端={backend.upper()})")
        print("=" * 70)
        
        # --- 1. 经典极速预检查：处理 N 为偶数的情况 ---
        if N % 2 == 0:
            factors = [2, N // 2]
            msg = "直接分解：N 是偶数"
            print(f"  - {msg} -> {factors}")
            self._update_last_result(N, None, method, backend, factors, None, None, msg, is_classical=True)
            return self._build_return(factors, None, None, msg)

        # --- 2. 核心大循环：不断尝试底数 a 直到成功 ---
        for attempt in range(1, max_retries + 1):
            print(f"\n▶️ [尝试 {attempt}/{max_retries}] 启动新一轮探索...")
            
            # ================= 阶段 1 =================
            print("=" * 50)
            print(f"{self.log_prefix}阶段 1/5: 开始准备参数 (N={N})...")
            
            a = random.randint(2, N - 1)
            gcd_val = math.gcd(a, N)
            
            if gcd_val > 1:
                factors = [gcd_val, N // gcd_val]
                msg = f"经典分解：随机底数 a={a} 与 N 存在公约数"
                print(f"  - 自动选取底数 a: {a}")
                print(f"  - 触发经典直接分解，发现公约数")
                print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")
                print("=" * 50)
                print(f"{self.log_prefix}经典算法直接求得结果...")
                print(f"  - 最终求得因子: {factors}")
                self._update_last_result(N, a, method, backend, factors, None, None, msg, is_classical=True)
                return self._build_return(factors, None, None, msg)
            
            n_work = N.bit_length()
            n_count = 2 * n_work
            
            if method == 'matrix':
                n_work_actual = n_work
            elif method == 'operator':
                n_work_actual = n_work * 2 + 2
            else:
                raise ValueError(f"不支持的求解方法: {method}")

            total_qubits = n_count + n_work_actual
            
            print(f"  - 自动选取底数 a: {a}")
            print(f"  - 模式: {method}, 总比特数: {total_qubits}")
            print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

            # ================= 阶段 2 =================
            print("=" * 50)
            print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路 (后端: {backend})...")
            
            gs = GateSequence(total_qubits, name=f'Shor_N{N}_a{a}_{method}', backend=backend)
            gs.h(range(n_count))
            gs.x(n_count) 

            if method == 'matrix':
                self._build_modular_matrix_circuit(gs, n_count, n_work, a, N)
            else:
                self._build_modular_operator_circuit(gs, n_count, n_work, n_work_actual, a, N, backend)

            gs.append(IQFT(n_count, backend=backend), range(n_count))
            print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")
            
            # ================= 阶段 3 =================
            print("=" * 50)
            print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
            
            start_time = time.time()
            result_vector = gs.execute()
            result_state = State(result_vector)
            measure_bin = result_state.measure(range(n_count), endian='little')
            measure_int = int(measure_bin, 2)
            end_time = time.time()
            comp_time = end_time - start_time

            print(f"  - 计算耗时: {comp_time:.4f} 秒")
            print(f"  - 测量结果: {measure_int} (|{measure_bin}>)")
            print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")
            
            # ================= 阶段 4 =================
            print("=" * 50)
            print(f"{self.log_prefix}阶段 4/5: 开始经典后处理 (连分数分解)...")
            
            phase = measure_int / (2**n_count)
            frac = Fraction(phase).limit_denominator(N)
            r = frac.denominator
            print(f"  - 推测周期 r: {r}")
            
            factors = []
            if r % 2 == 0 and r > 0:
                guess = pow(a, r // 2, N)
                if guess != N - 1 and guess != 1:
                    p = math.gcd(guess - 1, N)
                    q = math.gcd(guess + 1, N)
                    
                    if p * q == N or (p > 1 and N % p == 0):
                        factors = [p, N // p] if p * q != N else [p, q]
                        msg = f"量子计算成功 (第 {attempt} 次尝试)"
                        print(f"  - 最终求得因子: {factors}")
                        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")
                        
                        # ================= 阶段 5 (仅在成功时触发) =================
                        print("=" * 50)
                        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
                        os.makedirs(algo_dir, exist_ok=True)
                        circuit_path = os.path.join(algo_dir, f"Shor_N{N}_a{a}_{method}.svg")
                        gs.draw(filename=circuit_path, title=f"Shor Algorithm (N={N}, a={a})")
                        print(f"  - 电路图已保存至: {circuit_path}")
                        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")
                        
                        self._update_last_result(N, a, method, backend, factors, r, circuit_path, msg, measure_int, measure_bin, phase, n_count, n_work, total_qubits, comp_time)
                        return self._build_return(factors, r, circuit_path, msg)
                    else:
                        print("  - 最终求得因子: [] (因子验证失败)")
                else:
                    print(f"  - 最终求得因子: [] (找到平凡根 guess={guess})")
            else:
                print("  - 最终求得因子: [] (周期 r 为奇数或 0)")
            
            # 若运行到这里，说明本次 a 失败，结束阶段 4 并准备进入下一次循环
            print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓ (未找到有效因子，即将重试)")

        # --- 循环结束仍未找到 ---
        msg = f"已达到最大尝试次数 ({max_retries})，未能成功分解。"
        print("=" * 50)
        print(f"\n❌ {msg}")
        self._update_last_result(N, a, method, backend, [], r, None, msg, measure_int, measure_bin, phase, n_count, n_work, total_qubits, comp_time)
        return self._build_return([], r, None, msg)
    
    def _update_last_result(self, N, a, method, backend, factors, r, circuit_path, msg, measure_int=None, measure_bin=None, phase=None, n_count=None, n_work=None, total_qubits=None, comp_time=0, is_classical=False):
        """The internal state is saved uniformly for format_result_ascii rendering."""
        self.last_result = {
            "N": N, "a": a, "method": method, "backend": backend,
            "factors": factors, "period": r, "circuit_path": circuit_path, "message": msg,
            "measure_int": measure_int, "measure_bin": measure_bin, "phase": phase,
            "n_count": n_count, "n_work": n_work, "total_qubits": total_qubits,
            "computation_time": comp_time, "is_classical": is_classical
        }

    def _build_return(self, factors, r, circuit_path, msg):
        """Unified construction of returned dictionaries"""
        return {
            "status": "ok" if factors else "failed",
            "factors": factors,
            "period": r,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        """Format the result of the last executed algorithm into beautiful ASCII art."""
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        
        r = self.last_result
        status_emoji = '✅' if r.get('factors') else '❌'
        is_classical = r.get('is_classical', False)
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  SHOR 算法执行结果 ⚛️
{'='*70}

📊 执行状态: {status_emoji} {'成功' if r.get('factors') else '未找到因子'}

{'─'*70}
🔢 输入参数
{'─'*70}
  待分解数 N: {r['N']}
  选取底数 a: {r['a']}
  求解方法: {r['method'].upper()}
  模拟后端: {r['backend'].upper()}
  分解路径: {'经典算法直接命中' if is_classical else '量子电路'}
{'─'*70}
"""
        if not is_classical:
            ascii_art += f"""⚡ 量子电路配置
{'─'*70}
  工作寄存器比特数: {r['n_work']}
  计数寄存器比特数: {r['n_count']}
  总比特数: {r['total_qubits']}
{'─'*70}
🎯 量子计算结果
{'─'*70}
  测量结果: {r['measure_int']} (|{r['measure_bin']}>)
  相位值: {r['phase']:.6f}
  推测周期 r: {r['period']}
  计算耗时: {r['computation_time']:.4f} 秒
{'─'*70}
"""
        ascii_art += f"""🔓 质因子分解结果
{'─'*70}
"""
        factors = r.get('factors', [])
        if factors:
            ascii_art += f"""
  {'✓' if factors else '✗'} 分解成功！
  发现的质因子:
    1. {factors[0]}
    2. {factors[1]}
  验证: {factors[0]} × {factors[1]} = {factors[0] * factors[1]} {'✓' if factors[0] * factors[1] == r['N'] else '✗'}
"""
        else:
            ascii_art += f"""
  ✗ 本次运行未发现有效因子
  💡 建议: 增大 max_retries 或检查 N 的规模
"""
        ascii_art += f"""
{'─'*70}
📁 输出文件
{'─'*70}
  量子电路图: {r['circuit_path'] if r.get('circuit_path') else '无'}
{'─'*70}
💡 执行备注
{'─'*70}
  {r['message']}
{'='*70}
🔬 量子计算模拟器 | Shor 算法模块
{'='*70}
"""
        return ascii_art


    # ==========================================================
    #  Matrix 方法组件
    # ==========================================================
    def _get_modular_matrix(self, a, N, n_qubits):
        """Construct modular multiplication unitary: y -> (a * y) mod N."""
        dim = 2**n_qubits
        matrix = np.zeros((dim, dim))
        for y in range(dim):
            if y < N: target = (a * y) % N
            else: target = y
            matrix[target, y] = 1.0
        return matrix

    def _build_modular_matrix_circuit(self, gs, n_count, n_work, a, N):
        """Build controlled modular multiplication circuit for phase estimation."""
        total_qubits = n_count + n_work
        for q in range(n_count):
            power_factor = pow(a, 2**q, N)
            matrix = self._get_modular_matrix(power_factor, N, n_work)
            gs.unitary(matrix, range(n_count, total_qubits), q, '1')

    # ==========================================================
    #  Operator 方法专用的严谨算术组件 (完全保留你的原版逻辑)
    # ==========================================================
    def _Ph(self, n, a, gs):
        """Pure phase rotation"""
        for i in range(n):
            theta = 2 * np.pi * a / (2 ** (n-i))
            gs.p(theta, i)

    def _Controlled_Ph(self, n, a, gs, control_qubit, data_qubits):
        """Controlled phase rotation"""
        for i in range(n):
            theta = 2 * np.pi * a / (2 ** (n-i))
            gs.cp(theta, control_qubit, data_qubits[i])

    def _Add_constant_mod_opt(self, n_qubits: int, a: int, N: int, backend='torch'):
        """Original quantum modular adder"""
        n_padding = n_qubits + 1      
        n_total = n_qubits + 2        
        
        gs = GateSequence(n_total, name=f"+({a})%({N})", backend=backend)
        all_qubits = list(range(n_total))           
        work_qubits = list(range(n_padding))        
        ancilla = n_total - 1                       

        gs.append(QFT(n_total, backend=backend), all_qubits)
        self._Ph(n_total, a - N, gs)
        gs.append(IQFT(n_total, backend=backend), all_qubits)
        
        gs.append(QFT(n_padding, backend=backend), work_qubits)    
        self._Controlled_Ph(n_padding, N, gs, ancilla, work_qubits)
        
        self._Ph(n_padding, -a, gs)
        gs.append(IQFT(n_padding, backend=backend), work_qubits)    
        msb_padding = n_qubits 
        gs.x(ancilla)
        gs.cnot(msb_padding, ancilla)
        gs.append(QFT(n_padding, backend=backend), work_qubits)
        self._Ph(n_padding, a, gs)
        gs.append(IQFT(n_padding, backend=backend), work_qubits)

        return gs

    def _multiple_mod(self, n_qubits, a, N, backend='torch'):
        """The original complete quantum modular multiplier"""
        a = a % N
        n_data = n_qubits
        n_work = n_qubits + 2
        n_total = n_data + n_work
        
        list_n_data = list(range(n_data))
        list_n_work = list(range(n_data, n_total))
        
        # gs = GateSequence(n_total, name=f'*({a})%({N})', backend=backend)
        gs = GateSequence(n_total, name=f'M', backend=backend)

        for i in list_n_data:
            gs_add_mod = self._Add_constant_mod_opt(n_qubits, (2**i * a) % N, N, backend=backend)
            gs.append(gs_add_mod, list_n_work, list_n_data[i])
        
        for i in range(len(list_n_data)):
            gs.swap(list_n_data[i], list_n_work[i])

        try:
            a_inv = pow(a, -1, N) 
        except ValueError:
            raise ValueError(f"a={a} 和 N={N} 不互质,Shor算法无法继续")

        for i in range(n_data):
            term = (a_inv * (2**i)) % N
            sub_val = (N - term) % N
            gs_sub_mod = self._Add_constant_mod_opt(n_qubits, sub_val, N, backend=backend)
            gs.append(gs_sub_mod, list_n_work, list_n_data[i])
            
        return gs

    def _build_modular_operator_circuit(self, gs, n_count, n_work, n_work_actual, a, N, backend):
        """Connect the module multiplier to the main circuit."""
        total_qubits = n_count + n_work_actual
        for q in range(n_count):
            b = pow(a, 2**q, N)
            gs_tem = self._multiple_mod(n_work, b, N, backend=backend)
            gs.append(gs_tem, range(n_count, total_qubits), q)

if __name__ == "__main__":
    shor = ShorAlgorithm()
    # 只需要调用 run，它会在内部自动寻找直到成功！
    result = shor.run(15, method='matrix')
    print(result['plot'])