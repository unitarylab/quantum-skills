import time
import os
import math
import numpy as np
from fractions import Fraction
from typing import Dict, Any, Optional, List

# 导入项目核心组件 (假设路径一致)
from ....core import GateSequence, Register, State, ClassicalRegister
from ....library import IQFT

# ==========================================================
# Discrete Logarithm (DLP) 算法类实现
# ==========================================================

class DiscreteLogAlgorithm:
    """
    Discrete Logarithm Problem (DLP) Module
    求解 g^x ≡ y (mod P) 中的 x。
    
    支持基于矩阵的量子电路构建与复杂的经典后处理（连分数提取周期与解同余方程）。
    """
    def __init__(self):
        self.log_prefix = "INFO: "
        self.last_result = None

    def run(self, g: int, y: int, P: int, backend: str = 'torch', algo_dir: str = './dlg_results') -> Dict[str, Any]:
        """
        求解 g^x ≡ y (mod P)
        
        - g: 底数 (Base)
        - y: 目标值 (Target)
        - P: 模数 (Modulus, 通常为素数)
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Discrete Log 算法 (求解 {g}^x ≡ {y} mod {P}, 后端={backend.upper()})")
        print("=" * 70)

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 开始准备算法参数...")
        
        # 验证输入与计算比特数
        if math.gcd(g, P) != 1 or math.gcd(y, P) != 1:
            raise ValueError("g 和 y 必须与 P 互质。")
            
        # n_count 决定精度，理论要求 2^n >= r^2，此处取 P 的位长或更高
        n_count = 2*P.bit_length()  # 连分数 对比特数量有一定的限制。
        n_work = P.bit_length()
        N_size = 2**n_count
        
        print(f"  - 计数寄存器大小 (n_count): {n_count}")
        print(f"  - 工作寄存器大小 (n_work): {n_work}")
        print(f"  - 总量子比特数: {2 * n_count + n_work}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路...")
        
        ra = Register("reg_a", n_count)
        rb = Register("reg_b", n_count)
        rw = Register("reg_work", n_work)
        # 注意：此处假设 GateSequence 支持多寄存器传入
        gs = GateSequence(ra, rb, rw, name=f'DLP_{g}^{{x}}_{y}', backend=backend)

        # 辅助索引获取逻辑
        def get_p(reg_slice):
            reg, idxs = reg_slice[0]
            if reg.name == "reg_a": offset = 0
            elif reg.name == "reg_b": offset = n_count
            else: offset = 2 * n_count
            return [i + offset for i in idxs]

        # 初始化步骤
        gs.h(get_p(ra[:]))
        gs.h(get_p(rb[:]))
        gs.x(get_p(rw[0])) # |work> 设为 |1>

        # 阶段一：受控 g^a
        for i in range(n_count):
            mult = pow(g, 2**i, P)
            matrix = self._get_modular_matrix(mult, P, n_work)
            gs.unitary(matrix, get_p(rw[:]), get_p(ra[i])[0], '1')

        # 阶段二：受控 (y^-1)^b
        y_inv = pow(y, -1, P)
        for j in range(n_count):
            mult = pow(y_inv, 2**j, P)
            matrix = self._get_modular_matrix(mult, P, n_work)
            gs.unitary(matrix, get_p(rw[:]), get_p(rb[j])[0], '1')

        # 逆量子傅里叶变换
        gs.append(IQFT(n_count, backend=backend), get_p(ra[:]))
        gs.append(IQFT(n_count, backend=backend), get_p(rb[:]))
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        start_time = time.time()
        res_vec = gs.execute()
        state_obj = State(res_vec)
        # 获取前 2*n_count 位（A和B）的概率分布
        probs_dict = state_obj.calculate_state(range(2 * n_count))
        end_time = time.time()
        comp_time = end_time - start_time

        print(f"  - 计算耗时: {comp_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 开始执行经典后处理 (连分数与同余方程)...")
        
        found_x, found_r, info_msg = self._classical_post_processing(probs_dict, g, y, P, n_count, N_size)
        is_success = found_x is not None
        
        print(f"  - 探测到阶 r: {found_r if found_r else '未知'}")
        print(f"  - 最终求得结果 x: {found_x if is_success else '未找到'}")
        print(f"  - 结果验证: {'成功' if is_success else '失败'}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"DLP_g{g}_y{y}_P{P}.svg")
        gs.draw(filename=circuit_path, title=f"Discrete Log (g={g}, y={y}, P={P})")
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        # ================= 结果包装 =================
        self._update_last_result(g, y, P, n_count, comp_time, found_x, found_r, is_success, circuit_path, info_msg)
        return self._build_return(found_x, is_success, circuit_path, info_msg)

    def _get_modular_matrix(self, a, N, n_qubits):
        dim = 2**n_qubits
        matrix = np.zeros((dim, dim))
        for z in range(dim):
            if z < N: target = (a * z) % N
            else: target = z
            matrix[target, z] = 1.0
        return matrix

    def _classical_post_processing(self, probs, g, y, P, n, N_size):
        sorted_probs = sorted(probs.items(), key=lambda x: x[1]['prob'], reverse=True)
        
        for bitstring, data in sorted_probs:
            if data['prob'] < 0.02: continue
            
            # 统一处理位序
            v_bin, u_bin = bitstring[:n], bitstring[n:]
            u, v = int(u_bin, 2), int(v_bin, 2)
            if u == 0: continue

            # 1. 连分数找 r (通过 u/N 逼近 s/r)
            frac = Fraction(u, N_size).limit_denominator(P)
            r_base, s_base = frac.denominator, frac.numerator
            
            # 寻找真正的阶 r (检查候选者的倍数)
            real_r = None
            for k in range(1, 10): # 扩大搜索倍数以增加通用性
                if pow(g, r_base * k, P) == 1:
                    real_r = r_base * k
                    real_s = s_base * k
                    break
            
            if real_r is None: continue

            # 2. 求解方程 sx = -target (mod r)
            # target = round(v * r / N)
            target = int(round((v * real_r) / N_size))
            
            d = math.gcd(real_s, real_r)
            # 方程 sx ≡ -target (mod r) 有解的条件是 d 能整除 target
            if (-target) % d == 0:
                s_red = real_s // d
                r_red = real_r // d
                t_red = (-target) // d
                

                try:
                    x0 = (t_red * pow(s_red, -1, r_red)) % r_red
                    for i in range(d):
                        x_test = (x0 + i * r_red) % real_r
                        if pow(g, x_test, P) == (y % P):
                            # 关键：确保返回最小非负解
                            final_x = x_test % real_r 
                            return final_x, real_r, "成功"
                except ValueError: 
                    continue

                # try:
                #     # 核心解：x0 = (-target/d) * (s/d)^-1 mod (r/d)
                #     x0 = (t_red * pow(s_red, -1, r_red)) % r_red
                #     # 在阶 r 的范围内检查所有 d 个可能的解
                #     for i in range(d):
                #         x_test = (x0 + i * r_red) % real_r
                #         if x_test >= 0 and pow(g, x_test, P) == y:
                #             return x_test, real_r, "成功"
                        
                except ValueError: continue
        return None, None, "未找到解"

    def _update_last_result(self, g, y, P, n, comp_time, x, r, success, path, msg):
        self.last_result = {
            "g": g, "y": y, "P": P, "n": n, "comp_time": comp_time,
            "x": x, "r": r, "success": success, "path": path, "msg": msg
        }

    def _build_return(self, x, success, path, msg):
        return {
            "status": "ok" if success else "failed",
            "found_x": x,
            "circuit_path": path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None: return "尚未执行"
        res = self.last_result
        status_emoji = '✅' if res['success'] else '❌'
        
        return f"""
{'='*70}
{' '*15}⚛️  DISCRETE LOG (DLP) 算法执行结果 ⚛️
{'='*70}

📊 执行状态: {status_emoji} {'成功找到离散对数 x' if res['success'] else '求解失败'}

{'─'*70}
🔢 输入参数
{'─'*70}
  方程: {res['g']}^x ≡ {res['y']} (mod {res['P']})
  寄存器大小 n: {res['n']}
{'─'*70}
🎯 量子计算结果
{'─'*70}
  计算耗时: {res['comp_time']:.4f} 秒
  探测到的阶 r: {res['r']}
{'─'*70}
🔓 经典后处理结果
{'─'*70}
  最终求得 x: {res['x'] if res['success'] else 'N/A'}
  验证验证: {res['g']}^{res['x'] if res['success'] else '?'} ≡ {res['y']} (mod {res['P']}) {'✓' if res['success'] else '✗'}
{'─'*70}
📁 输出文件: {res['path']}
💡 执行备注: {res['msg']}
{'='*70}
"""

if __name__ == "__main__":
    # 测试 P=7, g=3, y=6 (预期 x=3)
    dlg = DiscreteLogAlgorithm()
    result = dlg.run(g=3, y=6, P=7)
    print(result['plot'])