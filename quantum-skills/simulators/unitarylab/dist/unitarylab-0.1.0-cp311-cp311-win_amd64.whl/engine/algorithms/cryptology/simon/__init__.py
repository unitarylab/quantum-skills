"""
Simon's Algorithm Module
========================

Implementation of Simon's algorithm for finding hidden periods.
"""

from .algorithm import SimonAlgorithm

__all__ = [
    'SimonAlgorithm',
]
