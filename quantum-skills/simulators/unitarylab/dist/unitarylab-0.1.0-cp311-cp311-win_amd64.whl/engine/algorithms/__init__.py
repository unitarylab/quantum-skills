"""
Quantum Algorithms Module
=========================

This module provides quantum algorithms including:
- schrodingerization: Schrödingerization for PDE solving
- simon: Simon's algorithm
- shor: Shor's algorithm
"""


from .schrodingerization import (
    HeatEquationAlgorithm,
    AdvectionEquationAlgorithm,
    backHeatEquationAlgorithm,
    backHeat2dEquationAlgorithm,
    BlackScholesEquationAlgorithm,
    BurgersEquationAlgorithm,
    Burgers2DEquationAlgorithm,
    ElasticWaveEquationAlgorithm,
    ElasticWave2DEquationAlgorithm,
    Heat2dEquationAlgorithm,
    HeatVariableCoefficientEquationAlgorithm,
    HelmholtzEquationAlgorithm,
    HelmholtzEquationAlgorithm,
    MaxwellEquationAlgorithm,
    MultiEllipticEquationAlgorithm,
    MultiTransportEquationAlgorithm,
    OUProcessEquationAlgorithm,
    SchrABCEquationAlgorithm,
    TrafficFlowEquationAlgorithm,
)

from .schrodingerization import HeatEquationAlgorithm
from .cryptology import SimonAlgorithm,ShorAlgorithm,DiscreteLogAlgorithm
from .hamiltonian_simulation import SuzukiTrotterAlgorithm,CartanDecompositionAlgorithm,CrankNicolsonAlgorithm,QDriftAlgorithm,TridiagonalSimulationAlgorithm
from .fundamental_algorithm import AmplitudeAmplificationAlgorithm,HadamardTransformAlgorithm,HadamardTestAlgorithm,AmplitudeEstimationAlgorithm,QPEAlgorithm
from .linear_algebra import LCUAlgorithm,QSVTLinearSolverAlgorithm,HHLAlgorithm,QSPAlgorithm
from .quantum_machine_learning import QNNAlgorithm,QCBMAlgorithm,CVQNNAlgorithm,VQCAlgorithm,QAOAAlgorithm,VQEAlgorithm


__all__ = [
    # PDE Solving
    "HeatEquationAlgorithm",
    
    # cryptology algorithm
    "SimonAlgorithm",
    "ShorAlgorithm",
    "DiscreteLogAlgorithm",

    #hamiltonian_simulation
    "SuzukiTrotterAlgorithm",
    "CartanDecompositionAlgorithm",
    "CrankNicolsonAlgorithm",
    "QDriftAlgorithm",
    "TridiagonalSimulationAlgorithm",

    #fundamental_algorithm
    "AmplitudeAmplificationAlgorithm",
    "HadamardTransformAlgorithm",
    "HadamardTestAlgorithm",
    "AmplitudeEstimationAlgorithm",
    "QPEAlgorithm",

    #linear_algebra
    "LCUAlgorithm",
    "QSVTLinearSolverAlgorithm",
    "HHLAlgorithm",
    "QSPAlgorithm",

    #quantum_machine_learning
    "QNNAlgorithm",
    "QCBMAlgorithm",
    "CVQNNAlgorithm",
    "VQCAlgorithm",
    "QAOAAlgorithm",
    "VQEAlgorithm",
]
