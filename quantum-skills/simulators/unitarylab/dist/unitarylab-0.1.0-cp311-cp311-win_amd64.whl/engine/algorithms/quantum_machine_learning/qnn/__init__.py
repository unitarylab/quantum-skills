# qnn/__init__.py
from .algorithm import QNNAlgorithm

__all__ = ["QNNAlgorithm"]