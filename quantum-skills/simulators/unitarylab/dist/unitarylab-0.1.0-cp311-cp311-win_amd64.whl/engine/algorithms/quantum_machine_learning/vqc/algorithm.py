import time
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from torch.utils.data import DataLoader, TensorDataset
from typing import Dict, Any, List

# 严格从您的 engine 中导入
from ....core import GateSequence

class VQCAlgorithm:
    """
    变分量子分类器 (Variational Quantum Classifier, VQC) 算法封装类。
    
    [功能]: 针对 Iris 数据集（4特征，3类别）进行监督学习分类。
    [原理]: 采用数据重上传 (Data Re-uploading) 策略，利用 Pauli-Z 期望值作为分类 Logits。
    [后端]: 灵活支持 'torch' 与 'unitarylab'。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [VQC] "
        self.last_result = None
        torch.manual_seed(seed)
        np.random.seed(seed)
        torch.set_default_dtype(torch.float64)

    def run(self, n_layers: int = 3, epochs: int = 20, lr: float = 0.05, 
            batch_size: int = 16, backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        """
        执行 VQC 训练与评估流程。

        Args:
            n_layers (int): 变分层深度。
            epochs (int): 训练迭代轮次。
            lr (float): Adam 优化器的学习率。
            batch_size (int): 训练批次大小。
            backend (str): 计算后端，可选 'torch' (默认) 或 'unitarylab'。
            algo_dir (str): 结果与图像导出目录。

        Returns:
            Dict[str, Any]: 包含 loss, accuracy, 图像路径及标准报告面板的字典。
        """
        print(f"{self.log_prefix}启动变分量子分类器 (VQC) 任务 (后端={backend.upper()}, Layers={n_layers})")
        print("=" * 70)
        total_start_time = time.time()
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)

        # ================= 阶段 1/5: 初始化 =================
        print(f"{self.log_prefix}阶段 1/5: 正在加载 Iris 数据集并初始化变分参数...")
        x_train, y_train, x_test, y_test = self._load_iris_data()
        train_loader = DataLoader(TensorDataset(x_train, y_train), batch_size=batch_size, shuffle=True)
        
        n_qubits = 4 # Iris 特征维度
        theta = torch.nn.Parameter(torch.rand((n_qubits, n_layers)) * 2 * np.pi)
        optimizer = torch.optim.Adam([theta], lr=lr)
        criterion = torch.nn.CrossEntropyLoss()
        shift = np.pi / 2 # Parameter Shift 步长
        print(f"  - 数据规模: {len(x_train)} 训练样本 | {len(x_test)} 测试样本")
        print(f"{self.log_prefix}阶段 1/5 完成 ✓")

        # ================= 阶段 2/5: 映射 =================
        print(f"{self.log_prefix}阶段 2/5: 正在映射量子可观测算符与 Logits 逻辑 (引擎: {backend.upper()})...")
        # 预计算用于分类的 Pauli-Z 算符
        observables = [self._get_observable(i, n_qubits) for i in range(1, 4)]
        # 用于结构展示的示例线路
        qc_draw = self._build_circuit(x_train[0], theta.detach(), backend)
        print(f"{self.log_prefix}阶段 2/5 完成 ✓")

        # ================= 阶段 3/5: 执行 (核心计算步) =================
        print(f"{self.log_prefix}阶段 3/5: 启动变分参数训练循环 (基于 Parameter Shift)...")
        loss_history = []
        acc_history = []
        
        # 核心量子模拟计算耗时统计开始
        q_comp_start = time.time()
        
        for ep in range(1, epochs + 1):
            epoch_loss = 0.0
            for xb, yb in train_loader:
                theta_base = theta.detach().clone()
                # 手动计算梯度
                grad_theta = torch.zeros_like(theta_base)
                for i in range(theta_base.shape[0]):
                    for j in range(theta_base.shape[1]):
                        th_p, th_m = theta_base.clone(), theta_base.clone()
                        th_p[i, j] += shift; th_m[i, j] -= shift
                        
                        loss_p = criterion(10 * self._get_batch_logits(xb, th_p, observables, backend), yb)
                        loss_m = criterion(10 * self._get_batch_logits(xb, th_m, observables, backend), yb)
                        grad_theta[i, j] = (loss_p - loss_m) * 0.5
                
                optimizer.zero_grad()
                theta.grad = grad_theta
                optimizer.step()
                
                with torch.no_grad():
                    logits = self._get_batch_logits(xb, theta, observables, backend)
                    epoch_loss += criterion(10 * logits, yb).item() * xb.size(0)
            
            avg_loss = epoch_loss / len(x_train)
            loss_history.append(avg_loss)
            acc_history.append(self._evaluate(x_test, y_test, theta, observables, backend))
            
            if ep % 5 == 0 or ep == 1:
                print(f"  - Epoch {ep:02d}/{epochs} | Loss: {avg_loss:.4f} | Test Acc: {acc_history[-1]:.2%}")
        
        q_comp_time = time.time() - q_comp_start
        print(f"  - 核心量子计算耗时 ({backend.upper()}): {q_comp_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5 完成 ✓")

        # ================= 阶段 4/5: 评估 =================
        print(f"{self.log_prefix}阶段 4/5: 正在执行模型最终性能统计...")
        final_acc = acc_history[-1]
        print(f"{self.log_prefix}阶段 4/5 完成 ✓")

        # ================= 阶段 5/5: 导出 =================
        print(f"{self.log_prefix}阶段 5/5: 正在导出分析图谱 (含原生 draw 线路图)...")
        path_circ = os.path.abspath(os.path.join(algo_dir, "VQC_Circuit.png"))
        qc_draw.draw(filename=path_circ)

        paths = self._generate_all_plots(loss_history, acc_history, algo_dir)
        paths['circuit'] = path_circ
        print(f"{self.log_prefix}阶段 5/5 完成 ✓")

        comp_time = time.time() - total_start_time
        self.last_result = {
            "n_qubits": n_qubits, "layers": n_layers, "epochs": epochs,
            "loss": loss_history[-1], "accuracy": final_acc,
            "q_comp_time": q_comp_time, "comp_time": comp_time, 
            "paths": paths, "backend": backend
        }

        return {
            "status": "success", "loss": loss_history[-1], "accuracy": final_acc,
            "plots": paths, "plot": self.format_result_ascii()
        }

    # ==========================================================
    # 内部辅助逻辑
    # ==========================================================

    def _load_iris_data(self):
        from sklearn.datasets import load_iris
        from sklearn.model_selection import train_test_split
        from sklearn.preprocessing import StandardScaler
        iris = load_iris()
        X = StandardScaler().fit_transform(iris["data"])
        # 特征映射至 [-pi/2, pi/2]
        X = (X - X.min(axis=0)) / (X.max(axis=0) - X.min(axis=0) + 1e-12) * np.pi - np.pi/2
        xt, xv, yt, yv = train_test_split(X, iris["target"], test_size=0.2, stratify=iris["target"])
        return torch.tensor(xt), torch.tensor(yt), torch.tensor(xv), torch.tensor(yv)

    def _get_observable(self, target, total):
        I = torch.eye(2, dtype=torch.complex128)
        Z = torch.tensor([[1, 0], [0, -1]], dtype=torch.complex128)
        op = Z if target == 0 else I
        for i in range(1, total):
            op = torch.kron(op, Z if i == target else I)
        return op

    def _build_circuit(self, x, theta, backend) -> GateSequence:
        qc = GateSequence(4, backend=backend)
        for q in range(4): qc.ry(float(x[q]), q) # 编码
        for l in range(theta.shape[1]):
            for q in range(4): qc.ry(float(theta[q, l]), q) # 变分
            if l < theta.shape[1] - 1:
                for q in range(4): qc.cx(q, (q + 1) % 4) # 纠缠
        return qc

    def _get_batch_logits(self, x_batch, theta, observables, backend):
        all_logits = []
        for x in x_batch:
            qc = self._build_circuit(x, theta, backend)
            state0 = np.zeros((16, 1), dtype=np.complex128); state0[0,0] = 1.0
            psi_out = qc.execute(initial_state=state0)
            psi = torch.as_tensor(psi_out).to(torch.complex128)
            bra = psi.conj().t()
            logits = [ (bra @ op @ psi).real.squeeze() for op in observables ]
            all_logits.append(torch.stack(logits))
        return torch.stack(all_logits)

    @torch.no_grad()
    def _evaluate(self, x, y, theta, obs, backend):
        logits = self._get_batch_logits(x, theta, obs, backend)
        return (torch.argmax(logits, dim=1) == y).float().mean().item()

    def _generate_all_plots(self, loss_h, acc_h, algo_dir):
        paths = {}
        p_metrics = os.path.abspath(os.path.join(algo_dir, "VQC_Metrics.png"))
        fig, ax1 = plt.subplots(figsize=(8, 5))
        ax1.plot(loss_h, color='#e74c3c', lw=2, label='Loss')
        ax1.set_ylabel('CrossEntropy Loss', color='#e74c3c')
        ax2 = ax1.twinx()
        ax2.plot(acc_h, color='#2ecc71', lw=2, label='Accuracy')
        ax2.set_ylabel('Test Accuracy', color='#2ecc71')
        plt.title("VQC Training Progress"); fig.tight_layout()
        fig.savefig(p_metrics); plt.close(fig); paths['metrics'] = p_metrics
        return paths

    def format_result_ascii(self) -> str:
        if not self.last_result: return ""
        r = self.last_result
        return f"""
{'='*70}
{' '*18}⚛️  VQC 变分量子分类器报告 ⚛️
{'='*70}

🎯 训练评估指标 | 最终精度: {r['accuracy']*100:.2f}% | 最终 Loss: {r['loss']:.6f}

{'─'*70}
🔢 算法参数与模型配置
{'─'*70}
  量子比特数 (Qubits) : {r['n_qubits']} (Iris 4-Features)
  变分层深度 (Layers) : {r['layers']}
  分类类别数 (Classes): 3
  总训练轮次 (Epochs) : {r['epochs']}
{'─'*70}
⚡ 量子计算性能统计
{'─'*70}
  执行后端           : {r['backend'].upper()}
  量子模拟计算耗时   : {r['q_comp_time']:.4f} 秒
  任务总计执行耗时   : {r['comp_time']:.4f} 秒
{'─'*70}
📁 导出的图像文件路径 (直接输出)
{'─'*70}
  1. 量子线路架构 : {r['paths']['circuit']}
  2. 训练指标图谱 : {r['paths']['metrics']}
{'─'*70}
💡 备注: VQC 已完成 Iris 数据集学习。
{'='*70}
"""

if __name__ == "__main__":
    algo = VQCAlgorithm()
    result = algo.run(n_layers=3, epochs=15)
    print(result['plot'])