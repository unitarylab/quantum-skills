import time
import os
import numpy as np
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
from sklearn.datasets import make_moons
from typing import Dict, Any, List

# 严格从您的 engine 中导入
from engine import GateSequence 

# ==========================================================
# 核心物理引擎 (CVSimulator & Model)
# ==========================================================

class CVSimulator:
    """基于截断 Fock 空间的连续变量光量子模拟器核心。"""
    def __init__(self, cutoff_dim=6, device='cpu'):
        self.cutoff = cutoff_dim
        self.device = device
        a_data = np.zeros((cutoff_dim, cutoff_dim))
        for n in range(1, cutoff_dim):
            a_data[n-1, n] = np.sqrt(n)
        self.a = torch.tensor(a_data, dtype=torch.complex128).to(device)
        self.adag = self.a.T.conj()
        self.x_op = (self.a + self.adag) / np.sqrt(2)
        self.n_op = self.adag @ self.a
        self.vacuum = torch.zeros((cutoff_dim, 1), dtype=torch.complex128).to(device)
        self.vacuum[0, 0] = 1.0 + 0j

    def displacement(self, alpha):
        return torch.matrix_exp(alpha * self.adag - torch.conj(torch.as_tensor(alpha)) * self.a)

    def squeezing(self, z):
        return torch.matrix_exp(0.5 * (torch.conj(torch.as_tensor(z)) * (self.a @ self.a) - torch.as_tensor(z) * (self.adag @ self.adag)))

    def rotation(self, theta):
        return torch.matrix_exp(-1j * torch.as_tensor(theta) * self.n_op)

    def kerr(self, kappa):
        return torch.matrix_exp(1j * torch.as_tensor(kappa) * (self.n_op @ self.n_op))

class CVClassifier(nn.Module):
    """CV 量子分类器模型。"""
    def __init__(self, n_layers=2, cutoff=6):
        super().__init__()
        self.sim = CVSimulator(cutoff_dim=cutoff)
        self.n_layers = n_layers
        self.cutoff = cutoff
        self.sq_r = nn.Parameter(torch.randn(n_layers, 2) * 0.1)
        self.disp_r = nn.Parameter(torch.randn(n_layers, 2) * 0.1)
        self.rot_theta = nn.Parameter(torch.rand(n_layers, 2) * 2 * np.pi)
        self.kerr_k = nn.Parameter(torch.randn(n_layers, 2) * 0.05)
        self.bs_theta = nn.Parameter(torch.rand(n_layers) * np.pi)

    def forward(self, x_batch):
        outputs = []
        I = torch.eye(self.cutoff, dtype=torch.complex128)
        for i in range(x_batch.shape[0]):
            features = x_batch[i]
            st0 = self.sim.displacement(features[0]) @ self.sim.vacuum
            st1 = self.sim.displacement(features[1]) @ self.sim.vacuum
            curr_state = torch.kron(st0, st1)
            for L in range(self.n_layers):
                a0 = torch.kron(self.sim.a, I); adag0 = a0.conj().T
                a1 = torch.kron(I, self.sim.a); adag1 = a1.conj().T
                U_bs = torch.matrix_exp(self.bs_theta[L] * (adag0 @ a1 - a0 @ adag1))
                U0 = (self.sim.kerr(self.kerr_k[L,0]) @ self.sim.displacement(self.disp_r[L,0]) @ 
                      self.sim.squeezing(self.sq_r[L,0]) @ self.sim.rotation(self.rot_theta[L,0]))
                U1 = (self.sim.kerr(self.kerr_k[L,1]) @ self.sim.displacement(self.disp_r[L,1]) @ 
                      self.sim.squeezing(self.sq_r[L,1]) @ self.sim.rotation(self.rot_theta[L,1]))
                curr_state = torch.kron(U0, U1) @ U_bs @ curr_state
            x_exp = curr_state.conj().T @ torch.kron(self.sim.x_op, I) @ curr_state
            outputs.append(x_exp.real.squeeze())
        return torch.stack(outputs).view(-1, 1)

# ==========================================================
# 算法封装类 (工业级标准模板)
# ==========================================================

class CVQNNAlgorithm:
    """
    连续变量量子神经网络 (CVQNN) 算法封装。
    支持相空间映射、变分梯度下降及多后端切换。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [CVQNN] "
        self.last_result = None
        torch.manual_seed(seed)
        np.random.seed(seed)
        torch.set_default_dtype(torch.float64)

    def _build_circuit(self, n_layers: int, backend: str, n_modes: int = 2) -> GateSequence:
        """
        利用 GateSequence 记录线路拓扑。
        """
        # 核心修改：初始化 GateSequence 时传递用户指定的 backend
        qc = GateSequence(n_modes, backend=backend) 
        for m in range(n_modes):
            qc.ry(0.0, m) # 编码层
        for l in range(n_layers):
            qc.cx(0, 1) # 纠缠层 (BS)
            for m in range(n_modes):
                qc.rx(0.0, m) 
                qc.ry(0.0, m) 
                qc.rz(0.0, m) # 变分层演化组合
        return qc

    def run(self, x_train: np.ndarray, y_train: np.ndarray, 
            n_layers: int = 2, cutoff: int = 6, epochs: int = 40, 
            lr: float = 0.05, backend: str = 'torch', algo_dir: str = './cvqnn_results') -> Dict[str, Any]:
        """
        执行 CVQNN 混合训练与评估流程。

        Args:
            x_train (np.ndarray): 输入特征。
            y_train (np.ndarray): 标签。
            n_layers (int): 变分层深度。
            cutoff (int): Fock 截断维度。
            epochs (int): 迭代轮次。
            lr (float): 学习率。
            backend (str): 计算后端，可选 'torch' 或 'unitarylab'。
            algo_dir (str): 结果保存目录。
        """
        print(f"{self.log_prefix}启动物理级 CVQNN 模拟 (后端={backend.upper()}, Cutoff={cutoff})")
        print("=" * 70)
        total_start = time.time()
        os.makedirs(algo_dir, exist_ok=True)

        # ================= 阶段 1/5: 初始化 =================
        print(f"{self.log_prefix}阶段 1/5: 正在进行数据特征预处理与模型初始化...")
        x_mean, x_std = x_train.mean(axis=0), x_train.std(axis=0)
        X_norm = (x_train - x_mean) / x_std
        x_tensor = torch.tensor(X_norm, dtype=torch.float64)
        y_tensor = torch.tensor(y_train, dtype=torch.float64).view(-1, 1)
        y_target = torch.where(y_tensor > 0.5, 1.0, -1.0) 

        model = CVClassifier(n_layers=n_layers, cutoff=cutoff)
        optimizer = torch.optim.Adam(model.parameters(), lr=lr)
        criterion = nn.MSELoss()
        print(f"{self.log_prefix}阶段 1/5 完成 ✓")

        # ================= 阶段 2/5: 映射 =================
        print(f"{self.log_prefix}阶段 2/5: 正在构建量子相空间架构 (Backend: {backend.upper()})...")
        qc = self._build_circuit(n_layers, backend=backend)
        print(f"{self.log_prefix}阶段 2/5 完成 ✓")

        # ================= 阶段 3/5: 执行 (核心计算步) =================
        print(f"{self.log_prefix}阶段 3/5: 正在启动基于变分梯度的参数优化循环...")
        loss_history = []
        
        # 核心量子模拟计算耗时统计开始
        q_comp_start = time.time()
        for e in range(1, epochs + 1):
            optimizer.zero_grad()
            preds = model(x_tensor)
            loss = criterion(preds, y_target)
            loss.backward()
            optimizer.step()
            loss_history.append(loss.item())
            if e % 10 == 0 or e == 1:
                print(f"  - Epoch {e:03d}/{epochs} | Loss: {loss.item():.6f}")
        
        q_comp_time = time.time() - q_comp_start
        print(f"  - 核心量子计算耗时 ({backend.upper()}): {q_comp_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5 完成 ✓")

        # ================= 阶段 4/5: 评估 =================
        print(f"{self.log_prefix}阶段 4/5: 正在执行分类决策边界评估与收敛性测试...")
        with torch.no_grad():
            final_preds = model(x_tensor)
            final_acc = ((torch.where(final_preds > 0, 1.0, 0.0)) == y_tensor).float().mean().item()
        print(f"  - 最终准确率 (Acc): {final_acc:.2%}")
        print(f"{self.log_prefix}阶段 4/5 完成 ✓")

        # ================= 阶段 5/5: 导出 =================
        print(f"{self.log_prefix}阶段 5/5: 正在导出全维度分析图谱 (含原生 draw 线路图)...")
        path_circ = os.path.abspath(os.path.join(algo_dir, "CVQNN_Circuit.png"))
        qc.draw(filename=path_circ)

        paths = self._generate_metrics_plots(X_norm, y_train, model, loss_history, final_acc, algo_dir)
        paths['circuit'] = path_circ
        print(f"{self.log_prefix}阶段 5/5 完成 ✓")

        comp_time = time.time() - total_start
        self.last_result = {
            "n_modes": 2, "layers": n_layers, "cutoff": cutoff, "epochs": epochs,
            "loss": loss_history[-1], "accuracy": final_acc, "q_comp_time": q_comp_time,
            "comp_time": comp_time, "paths": paths, "backend": backend
        }

        return {
            "status": "success", "loss": loss_history[-1], "accuracy": final_acc,
            "plots": paths, "plot": self.format_result_ascii()
        }

    def _generate_metrics_plots(self, X_norm, y_train, model, history, acc, algo_dir):
        paths = {}
        p_metrics = os.path.abspath(os.path.join(algo_dir, "CVQNN_Metrics.png"))
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))
        ax1.plot(history, color='#e74c3c', lw=2); ax1.set_title("Training Loss"); ax1.set_xlabel("Epochs")
        grid_res = 15
        x_min, x_max = X_norm[:, 0].min()-0.5, X_norm[:, 0].max()+0.5
        y_min, y_max = X_norm[:, 1].min()-0.5, X_norm[:, 1].max()+0.5
        xx, yy = np.meshgrid(np.linspace(x_min, x_max, grid_res), np.linspace(y_min, y_max, grid_res))
        with torch.no_grad():
            pts = torch.tensor(np.c_[xx.ravel(), yy.ravel()], dtype=torch.float64)
            zz = model(pts).view(xx.shape).numpy()
        ax2.contourf(xx, yy, zz, levels=20, cmap="RdBu", alpha=0.8)
        ax2.scatter(X_norm[:, 0], X_norm[:, 1], c=y_train, cmap="RdBu_r", edgecolors='k')
        ax2.set_title(f"Decision Boundary (Acc: {acc:.2%})")
        plt.tight_layout(); fig.savefig(p_metrics); plt.close(fig)
        paths['metrics'] = p_metrics
        return paths

    def format_result_ascii(self) -> str:
        if not self.last_result: return ""
        r = self.last_result
        return f"""
{'='*70}
{' '*18}⚛️  CV-QNN 物理模拟分类报告 ⚛️
{'='*70}

🎯 训练评估指标 | 最终精度: {r['accuracy']*100:.2f}% | 最终 Loss: {r['loss']:.6f}

{'─'*70}
🔢 算法参数与模型配置
{'─'*70}
  量子模态数 (Modes) : {r['n_modes']} (双模全纠缠模拟)
  Fock 截断维度      : {r['cutoff']}
  变分层深度 (Layers): {r['layers']}
  总训练轮次 (Epochs): {r['epochs']}
{'─'*70}
⚡ 量子计算性能统计
{'─'*70}
  执行后端           : {r['backend'].upper()}
  量子模拟计算耗时   : {r['q_comp_time']:.4f} 秒
  任务总计执行耗时   : {r['comp_time']:.4f} 秒
{'─'*70}
📁 导出的图像文件路径 (直接输出)
{'─'*70}
  1. 量子线路架构 : {r['paths']['circuit']}
  2. 训练指标图谱 : {r['paths']['metrics']}
{'─'*70}
💡 备注: CVQNN 已完成非线性分类任务。
{'='*70}
"""

if __name__ == "__main__":
    X, y = make_moons(n_samples=40, noise=0.1, random_state=42)
    algo = CVQNNAlgorithm()
    result = algo.run(x_train=X, y_train=y, n_layers=2, cutoff=5, epochs=30)
    print(result['plot'])