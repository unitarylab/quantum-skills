import time
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
import networkx as nx
from scipy.optimize import minimize
from typing import Dict, Any, List

# 严格从您的 engine 中导入
from engine import GateSequence

class QAOAAlgorithm:
    """
    量子近似优化算法 (QAOA) 工业级封装版。
    
    专门用于解决 Max-Cut 问题。支持用户自定义计算后端，并在核心优化阶段统计模拟耗时。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [QAOA] "
        self.last_result = None
        np.random.seed(seed)
        torch.manual_seed(seed)

    def _get_h_cost(self, edges: List, n_qubits: int):
        dim = 2**n_qubits
        h_c = np.zeros((dim, dim), dtype=np.complex128)
        z = np.array([[1, 0], [0, -1]], dtype=np.complex128)
        i_mat = np.eye(2, dtype=np.complex128)
        for u, v in edges:
            operators = [i_mat] * n_qubits
            operators[u] = z
            operators[v] = z
            res = operators[0]
            for k in range(1, n_qubits):
                res = np.kron(res, operators[k])
            h_c += res
        return h_c

    def _build_circuit(self, params: np.ndarray, n_qubits: int, edges: List, backend: str) -> GateSequence:
        """构造变分线路并指定后端"""
        p = len(params) // 2
        gammas, betas = params[:p], params[p:]
        # 修复点：将用户定义的 backend 传递给 GateSequence
        qc = GateSequence(n_qubits, backend=backend)
        for i in range(n_qubits): qc.h(i)
        for i in range(p):
            for u, v in edges:
                qc.cx(u, v); qc.rz(2 * gammas[i], v); qc.cx(u, v)
            for j in range(n_qubits): qc.rx(2 * betas[i], j)
        return qc

    def run(self, edges: List = None, n_qubits: int = 6, p_layers: int = 4, 
            max_iter: int = 100, backend: str = 'torch', algo_dir: str = './qaoa_results') -> Dict[str, Any]:
        """
        执行 QAOA 训练流程。

        Args:
            edges (List): 边列表。
            n_qubits (int): 比特数。
            p_layers (int): 演化层数。
            max_iter (int): 优化器最大迭代步数。
            backend (str): 计算后端 ('torch' 或 'numpy')。
            algo_dir (str): 结果保存目录。
        """
        print(f"{self.log_prefix}启动 QAOA Max-Cut 任务 (后端={backend.upper()}, Qubits={n_qubits})")
        print("=" * 70)
        total_start = time.time()
        os.makedirs(algo_dir, exist_ok=True)
        
        if edges is None:
            edges = [(0, 1), (1, 2), (2, 3), (3, 0), (0, 4), (1, 5)]

        # ================= 阶段 1/5 =================
        print(f"{self.log_prefix}阶段 1/5: 正在初始化哈密顿量矩阵与参数空间...")
        h_cost = self._get_h_cost(edges, n_qubits)
        exact_energy = float(np.linalg.eigvalsh(h_cost)[0])
        initial_params = np.random.uniform(0, np.pi, 2 * p_layers)
        print(f"{self.log_prefix}阶段 1/5 完成 ✓")

        # ================= 阶段 2/5 =================
        print(f"{self.log_prefix}阶段 2/5: 正在映射量子线路演化架构 (Backend: {backend})...")
        qc_draw = self._build_circuit(initial_params, n_qubits, edges, backend)
        print(f"{self.log_prefix}阶段 2/5 完成 ✓")

        # ================= 阶段 3/5 (核心计算步) =================
        print(f"{self.log_prefix}阶段 3/5: 正在启动变分参数优化 (COBYLA)...")
        history = []
        q_comp_start = time.time()
        
        def obj_func(p_flat):
            # 内部迭代必须使用指定的 backend
            qc = self._build_circuit(p_flat, n_qubits, edges, backend)
            psi_out = qc.execute(initial_state=np.eye(2**n_qubits, 1, dtype=np.complex128))
            
            # 兼容性处理：无论后端返回什么，均转为 numpy 数组进行能量计算
            psi = np.asarray(psi_out)
            energy = np.real(psi.conj().T @ h_cost @ psi).item()
            history.append(energy)
            return energy

        opt_res = minimize(obj_func, x0=initial_params, method='COBYLA', options={'maxiter': max_iter})
        
        q_comp_time = time.time() - q_comp_start
        print(f"  - 核心量子计算耗时 ({backend.upper()}): {q_comp_time:.4f} 秒")
        print(f"  - 最终优化能量: {opt_res.fun:.6f}")
        print(f"{self.log_prefix}阶段 3/5 完成 ✓")

        # ================= 阶段 4/5 =================
        print(f"{self.log_prefix}阶段 4/5: 正在执行最优态测量与比特串解码...")
        qc_final = self._build_circuit(opt_res.x, n_qubits, edges, backend)
        final_psi_out = qc_final.execute(initial_state=np.eye(2**n_qubits, 1, dtype=np.complex128))
        final_psi = np.asarray(final_psi_out)
        
        best_idx = int(np.argmax(np.abs(final_psi.flatten())**2))
        best_bits = format(best_idx, f"0{n_qubits}b")
        maxcut_val = len([(u, v) for u, v in edges if best_bits[u] != best_bits[v]])
        print(f"{self.log_prefix}阶段 4/5 完成 ✓")

        # ================= 阶段 5/5 =================
        print(f"{self.log_prefix}阶段 5/5: 正在导出全维度分析图谱...")
        paths = self._generate_outputs(edges, best_bits, history, qc_draw, n_qubits, algo_dir)
        print(f"{self.log_prefix}阶段 5/5 完成 ✓")

        comp_time = time.time() - total_start
        self.last_result = {
            "n_qubits": n_qubits, "layers": p_layers, "energy": opt_res.fun,
            "exact_energy": exact_energy, "maxcut": maxcut_val, 
            "bitstring": best_bits, "q_comp_time": q_comp_time, "paths": paths,
            "comp_time": comp_time, "backend": backend
        }

        return {
            "status": "success", "maxcut": maxcut_val, "plots": paths, "plot": self.format_result_ascii()
        }

    def _generate_outputs(self, edges, best_bits, history, qc_draw, n_qubits, algo_dir):
        paths = {}
        p_circ = os.path.abspath(os.path.join(algo_dir, "QAOA_Circuit.png"))
        qc_draw.draw(filename=p_circ); paths['circuit'] = p_circ
        p_loss = os.path.abspath(os.path.join(algo_dir, "QAOA_Convergence.png"))
        plt.figure(figsize=(6, 4)); plt.plot(history, color='#3498db', lw=2)
        plt.title("Energy Convergence"); plt.savefig(p_loss); plt.close(); paths['loss'] = p_loss
        p_res = os.path.abspath(os.path.join(algo_dir, "MaxCut_Solution.png"))
        g = nx.Graph(); g.add_edges_from(edges)
        colors = ["#3498db" if best_bits[i] == "0" else "#e74c3c" for i in range(n_qubits)]
        plt.figure(figsize=(8, 6)); pos = nx.spring_layout(g)
        nx.draw(g, pos, node_color=colors, with_labels=True, node_size=800, font_color='white')
        plt.savefig(p_res); plt.close(); paths['solution'] = p_res
        return paths

    def format_result_ascii(self) -> str:
        if not self.last_result: return ""
        r = self.last_result
        return f"""
{'='*70}
{' '*18}⚛️  QAOA MAX-CUT 求解报告 ⚛️
{'='*70}

🎯 核心优化指标 | 最终切割数: {r['maxcut']} | 最佳比特串: {r['bitstring']}

{'─'*70}
🔢 算法参数与模型配置
{'─'*70}
  量子比特数 (Qubits) : {r['n_qubits']}
  QAOA 层数 (p-Layers): {r['layers']}
  最低期望能量       : {r['energy']:.6f}
  理论基态能量       : {r['exact_energy']:.6f}
{'─'*70}
⚡ 量子计算性能统计
{'─'*70}
  执行后端           : {r['backend'].upper()}
  量子模拟计算耗时   : {r['q_comp_time']:.4f} 秒
  任务总计执行耗时   : {r['comp_time']:.4f} 秒
{'─'*70}
📁 导出的图像文件路径 (直接输出)
{'─'*70}
  1. 量子线路架构 : {r['paths']['circuit']}
  2. 参数收敛曲线 : {r['paths']['loss']}
  3. 最终划分方案 : {r['paths']['solution']}
{'─'*70}
💡 备注: QAOA 已完成图划分优化。
{'='*70}
"""

if __name__ == "__main__":
    algo = QAOAAlgorithm()
    # 支持用户手动传入 backend='numpy' 进行测试
    result = algo.run(p_layers=4, max_iter=60)
    print(result['plot'])