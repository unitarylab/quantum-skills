# vqc/__init__.py
from .algorithm import VQCAlgorithm

__all__ = ["VQCAlgorithm"]