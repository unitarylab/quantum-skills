import time
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from scipy.optimize import minimize
from typing import Dict, Any, List

# 严格从您的 engine 中导入
from engine import GateSequence

class VQEAlgorithm:
    """
    变分量子本征求解器 (Variational Quantum Eigensolver, VQE) 算法封装类。
    
    [当前内核]: 基于 Ising 模型 (H = Z0Z1 - 0.5*X0 - 0.5*X1)。
    [后端支持]: 支持用户自定义计算后端 (如 'torch', 'numpy')。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [VQE] "
        self.last_result = None
        np.random.seed(seed)
        torch.manual_seed(seed)
        torch.set_default_dtype(torch.float64)

    def _get_hamiltonian(self) -> torch.Tensor:
        """构造 2-qubit Ising 模型哈密顿量矩阵。"""
        I = torch.eye(2, dtype=torch.complex128)
        X = torch.tensor([[0, 1], [1, 0]], dtype=torch.complex128)
        Z = torch.tensor([[1, 0], [0, -1]], dtype=torch.complex128)
        ZZ = torch.kron(Z, Z)
        XI = torch.kron(X, I)
        IX = torch.kron(I, X)
        return 1.0 * ZZ - 0.5 * XI - 0.5 * IX

    def _build_circuit(self, params_flat: np.ndarray, n_qubits: int, n_layers: int, backend: str) -> GateSequence:
        """
        构造变分 Ansatz 线路，并指定后端。
        """
        params = params_flat.reshape(n_qubits, n_layers)
        # 修复点：将 backend 传递给 GateSequence
        qc = GateSequence(n_qubits, backend=backend)
        for l in range(n_layers):
            for q in range(n_qubits):
                qc.ry(float(params[q, l]), q)
            qc.cx(0, 1)
        return qc

    def run(self, n_qubits: int = 2, n_layers: int = 3, max_iter: int = 150, 
            backend: str = 'torch', algo_dir: str = './vqe_results') -> Dict[str, Any]:
        """
        执行 VQE 混合训练流程。

        Args:
            n_qubits (int): 量子比特数。
            n_layers (int): 变分层深度。
            max_iter (int): 优化器最大迭代次数。
            backend (str): 计算后端，默认为 'torch'。
            algo_dir (str): 结果与图像的保存路径。

        Returns:
            Dict[str, Any]: 结果字典。
        """
        print(f"{self.log_prefix}启动 VQE 本征求解任务 (后端={backend.upper()}, Qubits={n_qubits})")
        print("=" * 70)
        total_start = time.time()
        os.makedirs(algo_dir, exist_ok=True)

        # ================= 阶段 1/5: 初始化 =================
        print(f"{self.log_prefix}阶段 1/5: 正在初始化哈密顿量与参数...")
        h_mat = self._get_hamiltonian()
        exact_energy = float(torch.linalg.eigvalsh(h_mat)[0].real.item())
        initial_params = np.random.rand(n_qubits * n_layers) * 2 * np.pi
        print(f"{self.log_prefix}阶段 1/5 完成 ✓")

        # ================= 阶段 2/5: 映射 =================
        print(f"{self.log_prefix}阶段 2/5: 正在映射变分线路架构 (Backend: {backend})...")
        qc_draw = self._build_circuit(initial_params, n_qubits, n_layers, backend)
        print(f"{self.log_prefix}阶段 2/5 完成 ✓")

        # ================= 阶段 3/5: 执行 (核心计算步) =================
        print(f"{self.log_prefix}阶段 3/5: 启动变分能量最小化迭代...")
        history = []
        q_comp_start = time.time()
        
        def obj_func(p_flat):
            qc = self._build_circuit(p_flat, n_qubits, n_layers, backend)
            state_0 = np.zeros((2**n_qubits, 1), dtype=np.complex128)
            state_0[0, 0] = 1.0 + 0.0j
            # 获取模拟器返回的结果
            psi_out = qc.execute(initial_state=state_0)
            # 兼容性处理：无论后端返回什么，都转为 torch tensor 进行期望值计算
            psi = torch.as_tensor(psi_out).to(torch.complex128)
            energy = (torch.conj(psi.t()) @ h_mat @ psi).real.item()
            history.append(energy)
            return energy

        opt_res = minimize(obj_func, x0=initial_params, method='COBYLA', options={'maxiter': max_iter})
        q_comp_time = time.time() - q_comp_start
        
        print(f"  - 核心量子计算耗时 ({backend.upper()}): {q_comp_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5 完成 ✓")

        # ================= 阶段 4/5: 评估 =================
        print(f"{self.log_prefix}阶段 4/5: 正在分析自旋可观测值...")
        with torch.no_grad():
            qc_final = self._build_circuit(opt_res.x, n_qubits, n_layers, backend)
            psi_f_out = qc_final.execute(initial_state=np.eye(2**n_qubits, 1, dtype=np.complex128))
            psi_f = torch.as_tensor(psi_f_out).to(torch.complex128)
            
            I_op = torch.eye(2, dtype=torch.complex128)
            Z_op = torch.tensor([[1, 0], [0, -1]], dtype=torch.complex128)
            z0_val = (torch.conj(psi_f.t()) @ torch.kron(Z_op, I_op) @ psi_f).real.item()
            z1_val = (torch.conj(psi_f.t()) @ torch.kron(I_op, Z_op) @ psi_f).real.item()
            z0z1_val = (torch.conj(psi_f.t()) @ torch.kron(Z_op, Z_op) @ psi_f).real.item()
        print(f"{self.log_prefix}阶段 4/5 完成 ✓")

        # ================= 阶段 5/5: 导出 =================
        print(f"{self.log_prefix}阶段 5/5: 正在导出全维度分析图谱...")
        paths = self._generate_outputs(history, qc_draw, z0_val, z1_val, z0z1_val, algo_dir)
        print(f"{self.log_prefix}阶段 5/5 完成 ✓")

        comp_time = time.time() - total_start
        self.last_result = {
            "n_qubits": n_qubits, "layers": n_layers, "energy": opt_res.fun,
            "exact_energy": exact_energy, "q_comp_time": q_comp_time, "paths": paths,
            "observables": {"Z0": z0_val, "Z1": z1_val, "Z0Z1": z0z1_val},
            "comp_time": comp_time, "backend": backend # 记录用户选择的后端
        }

        return {
            "status": "success", "energy": opt_res.fun, "plots": paths, "plot": self.format_result_ascii()
        }

    def _generate_outputs(self, history, qc_draw, z0, z1, z0z1, algo_dir):
        paths = {}
        p_circ = os.path.abspath(os.path.join(algo_dir, "VQE_Circuit.png"))
        qc_draw.draw(filename=p_circ); paths['circuit'] = p_circ
        p_loss = os.path.abspath(os.path.join(algo_dir, "VQE_Convergence.png"))
        plt.figure(figsize=(6, 4)); plt.plot(history, color='#9b59b6', lw=2)
        plt.title("Energy Convergence"); plt.savefig(p_loss); plt.close(); paths['loss'] = p_loss
        p_obs = os.path.abspath(os.path.join(algo_dir, "VQE_Observables.png"))
        plt.figure(figsize=(6, 4))
        plt.bar(["<Z0>", "<Z1>", "<Z0Z1>"], [z0, z1, z0z1], color=['#3498db', '#e74c3c', '#2ecc71'])
        plt.ylim(-1.1, 1.1); plt.savefig(p_obs); plt.close(); paths['observables'] = p_obs
        return paths

    def format_result_ascii(self) -> str:
        if not self.last_result: return ""
        r = self.last_result
        obs = r['observables']
        return f"""
{'='*70}
{' '*18}⚛️  VQE 本征求解报告 (Ising Model) ⚛️
{'='*70}

🎯 核心物理指标 | 优化能量: {r['energy']:.6f} | 理论误差: {abs(r['energy']-r['exact_energy']):.6e}

{'─'*70}
🔢 算法参数与模型配置
{'─'*70}
  量子比特数 (Qubits) : {r['n_qubits']}
  变分层深度 (Layers) : {r['layers']}
  理论基态能量       : {r['exact_energy']:.6f}
{'─'*70}
🔮 自旋可观测值测量
{'─'*70}
  <Z0> (Spin 0 Dir)  : {obs['Z0']:.4f}
  <Z1> (Spin 1 Dir)  : {obs['Z1']:.4f}
  <Z0Z1> (Correlation): {obs['Z0Z1']:.4f}
{'─'*70}
⚡ 量子计算性能统计
{'─'*70}
  执行后端           : {r['backend'].upper()}
  量子模拟计算耗时   : {r['q_comp_time']:.4f} 秒
  任务总计执行耗时   : {r['comp_time']:.4f} 秒
{'─'*70}
📁 导出的图像文件路径 (直接输出)
{'─'*70}
  1. 量子线路架构 : {r['paths']['circuit']}
  2. 参数收敛曲线 : {r['paths']['loss']}
  3. 自旋测量图谱 : {r['paths']['observables']}
{'─'*70}
💡 备注: VQE 已完成本征求解。
{'='*70}
"""

if __name__ == "__main__":
    algo = VQEAlgorithm()
    result = algo.run(n_layers=3, max_iter=80)
    print(result['plot'])