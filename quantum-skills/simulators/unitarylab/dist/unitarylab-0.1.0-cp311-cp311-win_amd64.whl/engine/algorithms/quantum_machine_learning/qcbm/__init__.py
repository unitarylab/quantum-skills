# qcb/__init__.py
from .algorithm import QCBMAlgorithm

__all__ = ["QCBMAlgorithm"]