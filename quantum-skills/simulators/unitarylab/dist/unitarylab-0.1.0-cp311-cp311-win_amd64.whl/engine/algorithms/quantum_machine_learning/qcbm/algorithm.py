import time
import os
import numpy as np
import torch
import matplotlib.pyplot as plt
from typing import Dict, Any, List

# 严格从您的 engine 中导入
from ....core import GateSequence 

class QCBMAlgorithm:
    """
    量子玻恩机 (Quantum Circuit Born Machine, QCBM) 算法封装类。
    
    [功能]: 学习并建模离散概率分布（以 2x2 Bars and Stripes 为例）。
    [原理]: 利用变分量子线路 (VQC) 的 Born Rule 映射概率，通过 Parameter Shift Rule 进行梯度优化。
    [后端]: 支持 'torch' 与 'unitarylab' 动态切换。
    """
    def __init__(self, seed: int = 42):
        self.log_prefix = "INFO: [QCBM] "
        self.last_result = None
        torch.manual_seed(seed)
        np.random.seed(seed)
        torch.set_default_dtype(torch.float64)

    def run(self, n_qubits: int = 4, n_layers: int = 4, epochs: int = 40, 
            lr: float = 0.1, backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        """
        执行 QCBM 训练流程并导出全维度分析图谱。

        Args:
            n_qubits (int): 比特数 (2x2 BAS 固定为 4)。
            n_layers (int): 变分层深度。
            epochs (int): 训练迭代轮次。
            lr (float): Adam 优化器学习率。
            backend (str): 计算后端，可选 'torch' 或 'unitarylab'。
            algo_dir (str): 结果与图像保存目录。
        """
        print(f"{self.log_prefix}启动 QCBM 训练任务 (后端={backend.upper()}, Qubits={n_qubits})")
        print("=" * 70)
        total_start = time.time()
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)

        # ================= 阶段 1/5: 初始化 =================
        print(f"{self.log_prefix}阶段 1/5: 正在准备 BAS 目标分布与参数空间...")
        target_probs, valid_states = self._get_bas_dist(n_qubits)
        theta = torch.nn.Parameter(torch.rand((n_layers, n_qubits)) * 2 * np.pi)
        optimizer = torch.optim.Adam([theta], lr=lr)
        shift = np.pi / 2
        print(f"  - 状态空间维度: 2^{n_qubits} = {2**n_qubits}")
        print(f"{self.log_prefix}阶段 1/5 完成 ✓")

        # ================= 阶段 2/5: 映射 =================
        print(f"{self.log_prefix}阶段 2/5: 正在映射变分量子算子序列 (引擎: {backend.upper()})...")
        # 建立用于绘图的线路示例
        qc_draw = self._build_circuit(theta.detach(), n_qubits, backend)
        print(f"{self.log_prefix}阶段 2/5 完成 ✓")

        # ================= 阶段 3/5: 执行 (核心计算步) =================
        print(f"{self.log_prefix}阶段 3/5: 启动基于 Parameter Shift 的梯度优化循环...")
        loss_history = []
        
        # 核心量子模拟计算耗时统计开始
        q_comp_start = time.time()
        for ep in range(1, epochs + 1):
            curr_probs = self._get_probs(theta.detach(), n_qubits, backend)
            eps = 1e-12
            loss_val = torch.sum(target_probs * torch.log((target_probs + eps) / (curr_probs + eps)))
            loss_history.append(loss_val.item())

            grad_theta = torch.zeros_like(theta)
            for l in range(n_layers):
                for q in range(n_qubits):
                    th_p = theta.detach().clone(); th_p[l, q] += shift
                    th_m = theta.detach().clone(); th_m[l, q] -= shift
                    p_p = self._get_probs(th_p, n_qubits, backend)
                    p_m = self._get_probs(th_m, n_qubits, backend)
                    grad_p = 0.5 * (p_p - p_m)
                    grad_theta[l, q] = torch.sum(-(target_probs / (curr_probs + eps)) * grad_p)

            optimizer.zero_grad()
            theta.grad = grad_theta
            optimizer.step()
            
            if ep % 10 == 0 or ep == 1:
                print(f"  - Epoch [{ep:03d}/{epochs}] | KL Loss: {loss_val.item():.6f}")
        
        q_comp_time = time.time() - q_comp_start
        print(f"  - 核心量子计算耗时 ({backend.upper()}): {q_comp_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5 完成 ✓")

        # ================= 阶段 4/5: 评估 =================
        print(f"{self.log_prefix}阶段 4/5: 评估最优参数下的概率保真度...")
        with torch.no_grad():
            final_probs = self._get_probs(theta, n_qubits, backend).cpu().numpy()
        print(f"{self.log_prefix}阶段 4/5 完成 ✓")

        # ================= 阶段 5/5: 导出 =================
        print(f"{self.log_prefix}阶段 5/5: 导出分析图谱 (含原生 draw 线路图)...")
        path_circ = os.path.abspath(os.path.join(algo_dir, "QCBM_Circuit.png"))
        qc_draw.draw(filename=path_circ)

        paths = self._generate_all_outputs(target_probs.numpy(), final_probs, loss_history, algo_dir)
        paths['circuit'] = path_circ
        print(f"{self.log_prefix}阶段 5/5 完成 ✓")

        total_comp_time = time.time() - total_start
        self.last_result = {
            "n_qubits": n_qubits, "layers": n_layers, "epochs": epochs,
            "loss": loss_history[-1], "q_comp_time": q_comp_time, 
            "comp_time": total_comp_time, "paths": paths, "backend": backend
        }

        return {
            "status": "success", "loss": loss_history[-1], 
            "plots": paths, "plot": self.format_result_ascii()
        }

    def _generate_all_outputs(self, target, final, history, algo_dir):
        """生成并保存收敛、分布及采样图。"""
        paths = {}
        # 1. Loss 曲线
        p_loss = os.path.abspath(os.path.join(algo_dir, "QCBM_Loss.png"))
        plt.figure(figsize=(6, 4)); plt.plot(history, color='#e67e22', lw=2)
        plt.title("QCBM KL Loss Convergence"); plt.savefig(p_loss); plt.close()
        paths['loss'] = p_loss

        # 2. 分布对比
        p_dist = os.path.abspath(os.path.join(algo_dir, "QCBM_Distribution.png"))
        plt.figure(figsize=(10, 5)); x = np.arange(len(target))
        plt.bar(x - 0.2, target, 0.4, label='Target', alpha=0.4)
        plt.bar(x + 0.2, final, 0.4, label='QCBM Learned', color='#3498db')
        plt.legend(); plt.savefig(p_dist); plt.close()
        paths['dist'] = p_dist

        # 3. 采样图案 (结构化网格)
        p_samples = os.path.abspath(os.path.join(algo_dir, "QCBM_Samples.png"))
        samples = np.random.choice(np.arange(len(final)), size=8, p=final/final.sum())
        fig = plt.figure(figsize=(10, 5))
        for i, s in enumerate(samples):
            ax = fig.add_subplot(2, 4, i+1)
            grid = np.array([int(b) for b in f"{int(s):04b}"]).reshape(2, 2)
            ax.imshow(grid, cmap='binary', vmin=0, vmax=1, interpolation='nearest')
            ax.set_xticks(np.arange(-.5, 2, 1), minor=True); ax.set_yticks(np.arange(-.5, 2, 1), minor=True)
            ax.grid(which='minor', color='gray', linestyle='-', linewidth=0.5)
            ax.set_xticks([]); ax.set_yticks([]); ax.set_title(f"State: {s}")
        plt.tight_layout(); plt.savefig(p_samples); plt.close()
        paths['samples'] = p_samples
        return paths

    def _get_bas_dist(self, n_qubits):
        valid = [0, 3, 5, 10, 12, 15]
        probs = np.zeros(2**n_qubits)
        probs[valid] = 1.0 / len(valid)
        return torch.from_numpy(probs), valid

    def _build_circuit(self, theta, n_qubits, backend) -> GateSequence:
        qc = GateSequence(n_qubits, backend=backend)
        for l in range(theta.shape[0]):
            for q in range(n_qubits): qc.ry(float(theta[l, q]), q)
            if l < theta.shape[0] - 1:
                for q in range(n_qubits): qc.cx(q, (q + 1) % n_qubits)
        return qc

    def _get_probs(self, theta, n_qubits, backend):
        qc = self._build_circuit(theta, n_qubits, backend)
        state0 = np.zeros((2**n_qubits, 1), dtype=np.complex128); state0[0,0] = 1.0
        final_state = qc.execute(initial_state=state0)
        # 兼容性处理：转为 tensor
        return torch.as_tensor(np.abs(np.asarray(final_state).flatten())**2)

    def format_result_ascii(self) -> str:
        if not self.last_result: return ""
        r = self.last_result
        return f"""
{'='*70}
{' '*18}⚛️  QCBM 量子玻恩机综合报告 ⚛️
{'='*70}

🎯 训练评估指标 | 最终 KL Loss: {r['loss']:.6f} | 状态空间: 2^{r['n_qubits']}

{'─'*70}
🔢 算法参数与模型配置
{'─'*70}
  量子比特数 (Qubits) : {r['n_qubits']}
  变分层深度 (Layers) : {r['layers']}
  总训练轮次 (Epochs) : {r['epochs']}
{'─'*70}
⚡ 量子计算性能统计
{'─'*70}
  执行后端           : {r['backend'].upper()}
  量子模拟计算耗时   : {r['q_comp_time']:.4f} 秒
  任务总计执行耗时   : {r['comp_time']:.4f} 秒
{'─'*70}
📁 导出的图像文件路径 (直接输出)
{'─'*70}
  1. 量子线路架构 : {r['paths']['circuit']}
  2. 训练损耗曲线 : {r['paths']['loss']}
  3. 概率分布对比 : {r['paths']['dist']}
  4. 生成样本图案 : {r['paths']['samples']}
{'─'*70}
💡 备注: QCBM 已捕获 BAS 模式特征。
{'='*70}
"""

if __name__ == "__main__":
    algo = QCBMAlgorithm()
    result = algo.run(n_qubits=4, epochs=30)
    print(result['plot'])