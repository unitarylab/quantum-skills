# cvqnn/__init__.py
from .algorithm import CVQNNAlgorithm

__all__ = ["CVQNNAlgorithm"]