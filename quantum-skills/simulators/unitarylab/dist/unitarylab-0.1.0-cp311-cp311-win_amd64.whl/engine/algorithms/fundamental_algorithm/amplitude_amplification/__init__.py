"""
AmplitudeAmplificationAlgorithm
========================


"""

from .algorithm import AmplitudeAmplificationAlgorithm

__all__ = [
    'AmplitudeAmplificationAlgorithm',
]
