import time
import os
import math
import numpy as np
from typing import Dict, Any, List, Optional

# 导入项目核心组件
from ....core import GateSequence, Register

# ==========================================================
# Amplitude Estimation (量子振幅估计) 算法类实现
# ==========================================================

class AmplitudeEstimationAlgorithm:
    r"""
    Amplitude Estimation Algorithm Module (Standalone Version)

    This module combines Grover iterations with quantum phase estimation (QPE)
    to encode the amplitude information of a target state into phase information,
    thereby estimating the success probability :math:`p` of the quantum state
    with high accuracy in :math:`O(1 / \epsilon)` query complexity.
    """
    def __init__(self):
        self.log_prefix = "INFO: [QAE] "
        self.last_result = None

    def run(self, U: GateSequence, good_zero_qubits: List[int], d: int = 6, 
            backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        r"""
        Execute the main amplitude estimation process.

        Args:
            U (GateSequence): Unitary operator used to prepare the state to be measured,
                excluding auxiliary feedback qubits.
            good_zero_qubits (list[int]): Indices of qubits defining the "good" state.
                A measurement is considered successful when all these qubits are in
                the state :math:`|0\rangle`.
            d (int): Number of qubits in the phase register, which determines the
                estimation precision.
            backend (str): Simulation backend. This implementation forces ``'torch'``.
            algo_dir (str): Directory used to save generated quantum circuit diagrams.

        Returns:
            dict: A dictionary containing the execution results, including the
            estimated amplitude, estimated phase, measurement histogram, and
            ASCII panel output.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Amplitude Estimation 主程序 (精度位数 d={d}, 后端={backend.upper()})")
        print("=" * 70)

        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 解析与配置系统参数...")
        
        n_data = U.get_num_qubits()
        # QAE 需要：d 个相位比特 + n_data 个数据比特 + 1 个 Grover 辅助比特
        total_qubits = d + n_data + 1 
        
        print(f"  - 相位寄存器 (Phase): {d} Qubits")
        print(f"  - 数据寄存器 (Data): {n_data} Qubits")
        print(f"  - Grover 辅助比特 (Ancilla): 1 Qubit")
        print(f"  - 目标状态条件: Qubits {good_zero_qubits} 必须全为 |0>")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建复杂的 QPE + Grover 电路...")
        
        # 1. 制备数据寄存器的初始态 (不干扰 ancilla)
        prepare = GateSequence(n_data + 1, name="prepare")
        data_indices = list(range(n_data))
        prepare.append(U, data_indices)
        
        # 2. 构造单次 Grover 迭代算子 G
        G = self._grover_operator_from_zero_oracle(U, good_zero_qubits)
        
        # 3. 构造完整的 QPE 线路 (将 G 作为受控目标)
        qpe_circ = self._qpe_circuit(G, d=d, prepare_target=prepare)
        
        print(f"  - 已构建单次 Grover 迭代基元 G")
        print(f"  - 已完成 {d}-qubit 控制的 QPE 展开与 iQFT 逆变换")
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算与相位提取...")
        
        sim_start = time.time()
        state = qpe_circ.execute()
        statevector = np.asarray(state, dtype=complex).reshape(-1)
        sim_time = time.time() - sim_start
        
        # 提取相位寄存器 (最低 d 位) 的概率直方图
        histogram = self._phase_histogram(statevector, d=d)
        
        print(f"  - 底层计算耗时: {sim_time:.4f} 秒")
        print(f"  - 成功获取相位直方图分布 (非零项: {len(histogram)})")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行经典后处理 (推算成功概率 p)...")
        
        # 获取概率最高的 bitstring
        best_bits = next(iter(histogram))
        phi_raw = int(best_bits, 2) / (2 ** d)
        
        # QPE 会出现对称的 ± 本征相位主峰，折叠到 [0, 0.5]
        phi = min(phi_raw, 1.0 - phi_raw)
        
        # 根据 p = sin^2(pi * phi) 计算估计振幅
        est_amp = float(np.sin(np.pi * phi) ** 2)
        
        print(f"  - 测得最可能相位峰值 (二进制): {best_bits}")
        print(f"  - 等效十进制相位 phi: {phi:.6f}")
        print(f"  - 反推目标成功概率 p: {est_amp:.6f}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"QAE_d{d}_circuit.svg")
        
        qpe_circ.draw(filename=circuit_path, title=f"Amplitude Estimation (d={d})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        msg = f"成功提取相位 {best_bits}，估计目标概率 p ≈ {est_amp:.4f}"
        
        self._update_last_result(
            d=d, total_qubits=total_qubits, backend=backend, comp_time=comp_time,
            best_bits=best_bits, phi=phi, est_amp=est_amp, histogram=histogram,
            circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(est_amp, phi, histogram, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, d, total_qubits, backend, comp_time, best_bits, phi, est_amp, histogram, circuit_path, msg):
        self.last_result = {
            "d": d, "total_qubits": total_qubits, "backend": backend,
            "comp_time": comp_time, "best_bits": best_bits, "phi": phi,
            "est_amp": est_amp, "histogram": histogram, 
            "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, est_amp, phi, histogram, circuit_path, msg):
        return {
            "status": "success",
            "estimated_amplitude": est_amp,
            "phi": phi,
            "histogram": histogram,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        r = self.last_result
        
        # 准备直方图 Top 3 字符串
        top_hist = ""
        for i, (bits, prob) in enumerate(list(r['histogram'].items())[:3]):
            top_hist += f"    {i+1}. |{bits}> : {prob:.4f}\n"

        ascii_art = f"""
{'='*70}
{' '*15}⚛️  AMPLITUDE ESTIMATION 结果 ⚛️
{'='*70}

📊 核心估算结果: 成功概率 p ≈ {r['est_amp']:.6f}

{'─'*70}
🔢 算法配置
{'─'*70}
  精度位数 (d): {r['d']}
  总量子比特数: {r['total_qubits']}
  模拟后端: {r['backend'].upper()}
{'─'*70}
🎯 量子相位估计 (QPE) 分析
{'─'*70}
  最优观测比特串: |{r['best_bits']}>
  对应等效相位 φ: {r['phi']:.6f}
  Top 测量分布:
{top_hist.rstrip()}
{'─'*70}
⚡ 执行统计
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
  电路图路径: {r['circuit_path']}
{'─'*70}
💡 备注: {r['message']}
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件: QFT / iQFT / QPE / Grover
    # ==========================================================
    def _iqft_circuit(self, n: int, do_swaps: bool = True) -> GateSequence:
        """Constructing an Inverse Quantum Fourier Transform (iQFT) Circuit"""
        gs = GateSequence(n, name=f"iQFT_{n}")
        if do_swaps:
            for i in range(n // 2):
                gs.swap(i, n - 1 - i)
        for j in range(n):
            for k in range(0, j):
                angle = -np.pi / (2 ** (j - k))
                gs.mcp(angle, k, j)
            gs.h(j)
        return gs

    def _qpe_circuit(self, U: GateSequence, d: int, prepare_target: Optional[GateSequence] = None) -> GateSequence:
        """Constructing the core circuit for quantum phase estimation (QPE)"""
        n_target = U.get_num_qubits()
        gs = GateSequence(d + n_target, name=f"QPE_d{d}")
        
        phase = list(range(d))
        target = list(range(d, d + n_target))

        if prepare_target is not None:
            gs.append(prepare_target, target)

        for q in phase:
            gs.h(q)

        cU = U.control(1)
        for k in range(d):
            power = 2 ** k
            for _ in range(power):
                gs.append(cU, target + [phase[k]])

        iqft = self._iqft_circuit(d, do_swaps=True)
        gs.append(iqft, phase)
        return gs

    def _prepare_kickback_ancilla_minus(self, gs: GateSequence, ancilla: int) -> None:
        gs.x(ancilla)
        gs.h(ancilla)

    def _unprepare_kickback_ancilla_minus(self, gs: GateSequence, ancilla: int) -> None:
        gs.h(ancilla)
        gs.x(ancilla)

    def _phase_oracle_all_zeros(self, gs: GateSequence, zero_qubits: list[int], ancilla: int) -> None:
        self._prepare_kickback_ancilla_minus(gs, ancilla)
        for q in zero_qubits:
            gs.x(q)

        controls = list(zero_qubits)
        if len(controls) == 0:
            gs.x(ancilla)
        elif len(controls) == 1:
            gs.cx(controls[0], ancilla)
        else:
            gs.mcx(controls, ancilla)

        for q in zero_qubits:
            gs.x(q)
        self._unprepare_kickback_ancilla_minus(gs, ancilla)

    def _diffusion_about_prepared_state(self, gs: GateSequence, U: GateSequence, data_qubits: list[int], ancilla: int) -> None:
        gs.append(U.dagger(), data_qubits)
        self._phase_oracle_all_zeros(gs, zero_qubits=list(data_qubits), ancilla=ancilla)
        gs.append(U, data_qubits)

    def _grover_operator_from_zero_oracle(self, U: GateSequence, good_zero_qubits: list[int]) -> GateSequence:
        """Construct a single Grover iteration (including global phase correction)"""
        n_data = U.get_num_qubits()
        data = list(range(n_data))
        ancilla = n_data

        gs = GateSequence(n_data + 1, name="GroverIter")
        self._phase_oracle_all_zeros(gs, zero_qubits=good_zero_qubits, ancilla=ancilla)
        self._diffusion_about_prepared_state(gs, U=U, data_qubits=data, ancilla=ancilla)

        # 全局相位修正 (-1)
        self._prepare_kickback_ancilla_minus(gs, ancilla)
        gs.x(ancilla)
        self._unprepare_kickback_ancilla_minus(gs, ancilla)

        return gs

    def _phase_histogram(self, statevector: np.ndarray, d: int) -> dict[str, float]:
        """Extracting the phase register histogram from the state vector"""
        probs = np.abs(statevector) ** 2
        counts: dict[str, float] = {}
        modulus = 2 ** d
        for idx, p in enumerate(probs):
            if p < 1e-12: continue
            k = idx % modulus 
            bits = format(k, f'0{d}b')
            counts[bits] = counts.get(bits, 0.0) + float(p)
        return dict(sorted(counts.items(), key=lambda kv: kv[1], reverse=True))

# ==========================================================
# Main 测试入口
# ==========================================================
if __name__ == "__main__":
    algo = AmplitudeEstimationAlgorithm()
    
    backend='unitarylab'
    # backend='torch'
    
    # 测试案例 1: 均匀叠加态的 QAE (True p = 0.25)
    print("\n>>> 运行案例 1: 2-Qubit 均匀叠加态 (理论 p=0.25)")
    U_test = GateSequence(2)
    U_test.h(0)
    U_test.h(1)
    
    res1 = algo.run(U=U_test, good_zero_qubits=[0, 1], d=6,backend=backend)
    print(res1['plot'])

    # 测试案例 2: 单比特自定义概率 QAE (True p = 0.36)
    print("\n>>> 运行案例 2: 单比特自定义成功率 (理论 p=0.36)")
    p_target = 0.36
    theta = math.acos(math.sqrt(p_target))
    U_single = GateSequence(1)
    U_single.ry(2 * theta, 0)
    
    res2 = algo.run(U=U_single, good_zero_qubits=[0], d=7,backend=backend)
    print(res2['plot'])