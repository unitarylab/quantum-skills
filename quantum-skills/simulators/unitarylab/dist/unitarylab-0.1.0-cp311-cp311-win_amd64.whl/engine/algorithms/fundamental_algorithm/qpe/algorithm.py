import time
import os
import numpy as np
from typing import Dict, Any, List, Optional

# 导入项目核心组件
from ....core import GateSequence, State

# 直接调用引擎内置的傅里叶变换组件
from ....library import IQFT

# ==========================================================
# Quantum Phase Estimation (QPE) 算法类实现
# ==========================================================

class QPEAlgorithm:
    r"""
    Quantum Phase Estimation (QPE) Algorithm Module (Standard Engineering Version)

    Given a unitary operator :math:`U` and its eigenstate :math:`|\psi\rangle`
    (satisfying :math:`U |\psi\rangle = e^{2\pi i \phi} |\psi\rangle`),

    QPE uses :math:`d` auxiliary qubits and the inverse quantum Fourier transform (iQFT)

    to extract a high-precision binary approximation of the phase :math:`\phi`.
    """
    def __init__(self):
        self.log_prefix = "INFO: [QPE] "
        self.last_result = None

    def run(self, U: GateSequence, d: int, 
            prepare_target: Optional[GateSequence] = None,
            backend: str = 'torch', algo_dir = None) -> Dict[str, Any]:
        r"""
        Execute the QPE main flow.

        Args:
            U (GateSequence): Unitary operator circuit for phase estimation.
            d (int): Number of qubits in the phase register, with precision
                :math:`1 / 2^d`.
            prepare_target (Optional[GateSequence]): Circuit preparing the eigenstate
                :math:`|\psi\rangle`. Defaults to :math:`|0\rangle`.
            backend (str): Simulation backend. Forces ``'torch'``.
            algo_dir (str): Directory for saving quantum circuit diagrams.

        Returns:
            Dict[str, Any]: Dictionary containing phase estimation results,
            most probable state, circuit path, and ASCII panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 量子相位估计 (QPE) 主程序 (精度位数 d={d}, 后端={backend.upper()})")
        print("=" * 70)

        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 验证并解析参数...")
        
        n_target = U.get_num_qubits()
        total_qubits = d + n_target
        
        print(f"  - 相位寄存器 (Phase): {d} Qubits")
        print(f"  - 目标寄存器 (Target): {n_target} Qubits")
        print(f"  - 总量子比特数: {total_qubits}")
        print(f"  - 理论相位分辨率: 1 / {2**d} ≈ {1/(2**d):.6f}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建 QPE 核心量子电路...")
        
        # 调用独立的电路构建方法
        gs = self.build_qpe_circuit(U, d, prepare_target,backend=backend)
        
        print(f"  - 已构建受控 U 算子序列 (cU^(2^k))")
        print(f"  - 已接入 engine.library 的 IQFT 模块")
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        sim_start = time.time()
        final_state = gs.execute()
        
        # 统一转为 numpy statevector
        state_arr = np.asarray(final_state, dtype=complex).reshape(-1)
        state_obj = State(state_arr)
        sim_time = time.time() - sim_start
        
        print(f"  - 底层模拟计算耗时: {sim_time:.4f} 秒")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行经典后处理 (提取高概率相位)...")
        
        # 获取相位寄存器 (前 d 个比特) 的测量概率分布
        phase_qubits = list(range(d))
        phase_probs = state_obj.probabilities_dict(phase_qubits, endian="little", threshold=1e-8)
        
        # 找出概率最高的一个态
        sorted_phases = sorted(phase_probs.items(), key=lambda item: item[1], reverse=True)
        best_bits_str = sorted_phases[0][0]
        best_prob = sorted_phases[0][1]
        
        # 将二进制字符串转换为 [0, 1) 之间的小数相位
        phi_est = int(best_bits_str, 2) / (2 ** d)
        
        print(f"  - 测得最优相位比特串: |{best_bits_str}> (概率: {best_prob:.4f})")
        print(f"  - 等效十进制估计相位 phi: {phi_est:.6f}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        circuit_path = os.path.join(algo_dir, f"QPE_d{d}_circuit.svg")
        
        gs.draw(filename=circuit_path, title=f"Quantum Phase Estimation (d={d})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        msg = f"QPE 成功提取相位，最优估计值 phi ≈ {phi_est:.6f}"
        
        self._update_last_result(
            d=d, n_target=n_target, backend=backend, comp_time=comp_time,
            best_bits=best_bits_str, best_prob=best_prob, phi_est=phi_est, 
            phase_probs=sorted_phases[:3], circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(phi_est, best_prob, gs, circuit_path, msg)

    # ==========================================================
    # 供外部 (如 HHL/QAE) 独立调用的核心构建模块
    # ==========================================================
    def build_qpe_circuit(self, U: GateSequence, d: int, prepare_target: Optional[GateSequence] = None,backend='torch') -> GateSequence:
        """
        Construct a pure QPE line and return it as a standalone GateSequence for easy embedding into other algorithms.
        """
        n_target = U.get_num_qubits()
        gs = GateSequence(d + n_target, name=f"QPE_d{d}",backend=backend)
        phase_qubits = list(range(d))
        target_qubits = list(range(d, d + n_target))

        # 1. 目标状态初始化
        if prepare_target is not None:
            if prepare_target.get_num_qubits() != n_target:
                raise ValueError("prepare_target 的比特数必须与 U 一致。")
            gs.append(prepare_target, target_qubits)

        # 2. 相位寄存器施加 Hadamard 变换
        for q in phase_qubits:
            gs.h(q)

        # 3. 受控演化 cU^{2^k}
        cU = U.control(1, '1')  # 假设底层引擎使用 '1' 表示受控态为 |1>
        for k in range(d):
            power = 2 ** k
            for _ in range(power):
                gs.append(cU, target_qubits + [phase_qubits[k]])

        # 4. 逆量子傅里叶变换 (直接调用引擎库)
        iqft_circ = IQFT(d,backend=backend)  # 假设 engine.library.IQFT 返回的是一个作用在 d 个比特上的组件
        gs.append(iqft_circ, phase_qubits)

        return gs

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, d, n_target, backend, comp_time, best_bits, best_prob, phi_est, phase_probs, circuit_path, msg):
        self.last_result = {
            "d": d, "n_target": n_target, "total": d + n_target,
            "backend": backend, "comp_time": comp_time,
            "best_bits": best_bits, "best_prob": best_prob, "phi_est": phi_est,
            "phase_probs": phase_probs, "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, phi_est, best_prob, gs, circuit_path, msg):
        return {
            "status": "success",
            "estimated_phase": phi_est,
            "confidence_probability": best_prob,
            "full_circuit": gs,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        r = self.last_result
        
        top_hist = ""
        for i, (bits, prob) in enumerate(r['phase_probs']):
            top_hist += f"    {i+1}. |{bits}> : {prob:.4f}\n"

        ascii_art = f"""
{'='*70}
{' '*15}⚛️  QUANTUM PHASE ESTIMATION 结果 ⚛️
{'='*70}

📊 最优相位估计 (phi): {r['phi_est']:.6f}

{'─'*70}
🔢 算法配置
{'─'*70}
  精度位数 (d): {r['d']} (理论分辨率: 1/{2**r['d']})
  系统寄存器: {r['n_target']} Qubits
  模拟后端: {r['backend'].upper()}
{'─'*70}
🎯 测量统计分析
{'─'*70}
  最可能态: |{r['best_bits']}>
  置信度 (概率): {r['best_prob']:.4f}
  Top 测量分布:
{top_hist.rstrip()}
{'─'*70}
⚡ 硬件执行追踪
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
  电路图路径: {r['circuit_path']}
{'─'*70}
💡 备注: {r['message']}
{'='*70}
"""
        return ascii_art


# ==========================================================
# Main 测试入口 (复刻 Jupyter 中的 T 门相位估计测试)
# ==========================================================
if __name__ == "__main__":
    # 测试案例: 估计 T 门在 |1> 态下的特征相位
    # 理论值: T|1> = e^{i * pi/4} |1> = e^{i * 2*pi * (1/8)} |1>
    # 预期输出 phi = 1/8 = 0.125
    backend='unitarylab'
    # backend='torch'

    print("\n>>> 开始执行 QPE 测试用例: T 门相位估计 ...")
    
    # 1. 构造待测算符 U (此处为 T 门，等价于 P(pi/4))
    U_test = GateSequence(1, name='U_T_gate',backend=backend)
    U_test.p(np.pi / 4, 0)
    
    # 2. 制备特征态 |1>
    prep_state = GateSequence(1, name='Prep_1_state',backend=backend)
    prep_state.x(0)
    
    # 3. 运行 QPE 算法 (使用 3 个相位比特)
    algo = QPEAlgorithm()
    result = algo.run(U=U_test, d=3, prepare_target=prep_state,backend=backend)
    
    # 打印酷炫的极客面板
    print(result['plot'])
    
    # 验证理论值
    expected_phi = 1/8
    print(f"理论期望相位: {expected_phi}")
    if np.isclose(result['estimated_phase'], expected_phi):
        print("✅ 算法估计结果与理论完全一致！")
    else:
        print("❌ 算法估计存在偏差。")