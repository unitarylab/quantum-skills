import time
import os
import numpy as np
from typing import Dict, Any, List, Optional

# 导入项目核心组件
from engine.core import GateSequence, Register
from engine.backend import set_backend

# ==========================================================
# Hadamard Transform 算法类实现
# ==========================================================

class HadamardTransformAlgorithm:
    """
    The Hadamard Transform algorithm module (standalone class version)

    encapsulates the n-qubit global Hadamard transform.

    Supports two modes:

    1. superposition: Generates a globally uniform superposition state.

    2. reflexive_test: Verifies reflexivity (H^2 = I) by randomly initializing the quantum state and applying two transformations.
    """
    def __init__(self):
        self.log_prefix = "INFO: [H-Trans] "
        self.last_result = None

    def run(self, n_qubits: int = 3, mode: str = "superposition", backend: str = 'torch', 
            algo_dir: str = './hadamard_results') -> Dict[str, Any]:
        """
        Modifiable input parameters params:

        - n_qubits: Number of qubits (default 3)

        - mode: Run mode, "superposition" or "reflexive_test"

        - backend: Simulation backend (force 'torch')

        - algo_dir: Directory for saving the quantum circuit diagram

        return: Dictionary containing the algorithm execution results, including state vectors, probability distributions, and ASCII panels.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Hadamard 变换主程序 (模式={mode}, 后端={backend.upper()})")
        print("=" * 70)

        # 强制设置后端
        set_backend(backend)

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 开始准备算法参数...")
        
        if n_qubits < 1:
            raise ValueError("量子比特数量 n_qubits 必须 >= 1")
        if mode not in ["superposition", "reflexive_test"]:
            raise ValueError("mode 必须是 'superposition' 或 'reflexive_test'")
            
        print(f"  - 目标寄存器大小: n = {n_qubits}")
        print(f"  - 运行模式: {mode}")
        print(f"  - 预设模拟后端: {backend}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路...")
        
        gs = GateSequence(n_qubits, name=f'Hadamard_{mode}', backend=backend)
        target_qubits = list(range(n_qubits))

        original_state = None

        if mode == "superposition":
            # 模式 1：单纯施加一层 H 门
            self._apply_hadamard_layer(gs, target_qubits)
            print(f"  - 已向所有 {n_qubits} 个比特添加 Hadamard 门。")
            
        elif mode == "reflexive_test":
            # 模式 2：生成随机态 -> 施加 H -> 再次施加 H -> 比较
            rng = np.random.default_rng()
            psi = rng.normal(size=2**n_qubits) + 1j * rng.normal(size=2**n_qubits)
            original_state = psi / np.linalg.norm(psi)
            
            # 使用引擎支持的 initialize 方法载入随机态
            gs.initialize(original_state, target=target_qubits)
            print(f"  - 已初始化随机量子态。")
            
            # 施加两次 Hadamard 变换
            for i in range(2):
                self._apply_hadamard_layer(gs, target_qubits)
            print(f"  - 已连续施加 2 次全局 Hadamard 变换。")
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        start_time = time.time()
        raw_result = gs.execute()
        state_vector = self._as_statevector(raw_result)
        
        if mode == "superposition":
            prob_dict = self._probabilities(state_vector)
        else:
            prob_dict = {} # 自反性测试不需要计算分布

        end_time = time.time()
        comp_time = end_time - start_time

        print(f"  - 计算耗时: {comp_time:.4f} 秒")
        print(f"  - 状态向量维度: {len(state_vector)}")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 执行结果验证与后处理...")
        
        is_success = False
        msg = ""
        max_deviation = 0.0

        if mode == "superposition":
            # 验证所有基态的概率是否均匀 (理论上应为 1 / 2^n)
            expected_prob = 1.0 / (2 ** n_qubits)
            is_uniform = all(np.isclose(p, expected_prob, atol=1e-5) for p in prob_dict.values())
            is_success = is_uniform and len(prob_dict) == (2 ** n_qubits)
            msg = "成功生成全局均匀叠加态。" if is_success else "状态分布不均匀，叠加态生成失败。"
            
            print(f"  - 理论基态概率: {expected_prob:.4f}")
            print(f"  - 测量得到有效基态数量: {len(prob_dict)}")
            print(f"  - 均匀性验证: {'通过' if is_success else '失败'}")
            
        elif mode == "reflexive_test":
            # 验证 H^2 = I，两次变换后应回到原态
            is_success = np.allclose(state_vector, original_state, atol=1e-10)
            max_deviation = np.max(np.abs(state_vector - original_state))
            msg = "自反性验证通过：H^2 = I。" if is_success else "自反性验证失败：状态发生偏离。"
            
            print(f"  - 最大幅度偏离值: {max_deviation:.2e}")
            print(f"  - 状态还原验证: {'通过 (完全一致)' if is_success else '失败'}")

        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        os.makedirs(algo_dir, exist_ok=True)
        circuit_filename = f"Hadamard_{mode}_n{n_qubits}.svg"
        circuit_path = os.path.join(algo_dir, circuit_filename)
        
        gs.draw(filename=circuit_path, title=f"Hadamard Transform ({mode})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        # ================= 结果包装 =================
        self._update_last_result(
            n_qubits=n_qubits, mode=mode, backend=backend, comp_time=comp_time,
            is_success=is_success, max_deviation=max_deviation, 
            circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(state_vector, prob_dict, is_success, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, n_qubits, mode, backend, comp_time, is_success, max_deviation, circuit_path, msg):
        self.last_result = {
            "n_qubits": n_qubits, "mode": mode, "backend": backend,
            "comp_time": comp_time, "is_success": is_success, 
            "max_deviation": max_deviation, "circuit_path": circuit_path, "message": msg
        }

    def _build_return(self, state_vector, prob_dict, is_success, circuit_path, msg):
        return {
            "status": "ok" if is_success else "failed",
            "state_vector": state_vector,
            "probabilities": prob_dict,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        
        r = self.last_result
        status_emoji = '✅' if r['is_success'] else '❌'
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  HADAMARD TRANSFORM 结果 ⚛️
{'='*70}

📊 执行状态: {status_emoji} {'验证通过' if r['is_success'] else '验证失败'}

{'─'*70}
🔢 算法配置
{'─'*70}
  量子比特数 (n): {r['n_qubits']}
  运行模式: {r['mode']}
  模拟后端: {r['backend'].upper()}
{'─'*70}
⚡ 执行统计
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
"""
        if r['mode'] == 'reflexive_test':
            ascii_art += f"  最大状态偏离值: {r['max_deviation']:.2e}\n"

        ascii_art += f"""{'─'*70}
📁 输出文件
{'─'*70}
  量子电路图: {r['circuit_path'] if r.get('circuit_path') else '无'}
{'─'*70}
💡 执行备注
{'─'*70}
  {r['message']}
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件与数学辅助函数 (还原自 jupyter notebook)
    # ==========================================================

    def _apply_hadamard_layer(self, gs: GateSequence, target_qubits: List[int]) -> None:
        """Apply a Hadamard gate to a specified list of bits"""
        for q in target_qubits:
            gs.h(q)

    def _as_statevector(self, res) -> np.ndarray:
        """The execution result is compatible and converted into a NumPy vector."""
        return np.asarray(res, dtype=complex)

    def _probabilities(self, statevec: np.ndarray, threshold: float = 1e-12) -> Dict[str, float]:
        """Calculate the probability distribution and convert it into a binary string dictionary of MSB->LSB."""
        probs = np.abs(statevec) ** 2
        n = int(np.log2(len(probs)))
        out = {}
        for idx, p in enumerate(probs):
            if p < threshold: continue
            bits = format(idx, f"0{n}b")
            out[bits] = float(p)
        return dict(sorted(out.items()))

if __name__ == "__main__":
    algo = HadamardTransformAlgorithm()
    
    # 测试模式 1：生成均匀叠加态
    print("\n>>> 运行模式: Superposition (产生均匀叠加态)")
    res1 = algo.run(n_qubits=2, mode="superposition")
    print(res1['plot'])
    
    # 测试模式 2：验证自反性 H^2 = I
    print("\n>>> 运行模式: Reflexive Test (验证 H^2 = I)")
    res2 = algo.run(n_qubits=3, mode="reflexive_test")
    print(res2['plot'])