import time
import os
import math
import numpy as np
from typing import Dict, Any, List, Optional

# 导入项目核心组件 (与 Simon 保持一致的结构)
from ....core import GateSequence, Register, State

# ==========================================================
# Amplitude Amplification 算法类实现
# ==========================================================

class AmplitudeAmplificationAlgorithm:
    r"""
    Executes the amplitude amplification algorithm.

    Args:

        U (GateSequence): Quantum circuit for state preparation (excluding auxiliary qubits).

        good_zero_qubits (List[int]): Indices of qubits that define "good" states,
            which must be in state :math:`|0\rangle`.

        p (float): Initial success probability (used to automatically infer the number of Grover iterations).

        reps (int): Manually specified number of Grover iterations (overrides p if provided).

        backend (str): Simulation backend (default: 'torch').

        algo_dir (str): Directory for saving the quantum circuit diagram.

    Returns:

        Dict[str, Any]: Dictionary containing execution results, including amplified probabilities,
        circuit diagram paths, and formatted ASCII panels.
    """
    def __init__(self):
        # 统一日志前缀与状态保存
        self.log_prefix = "INFO:  "
        self.last_result = None

    def run(self, U: GateSequence, good_zero_qubits: List[int], p: float, 
            reps: Optional[int] = None, backend: str = 'torch', 
            algo_dir = None) -> Dict[str, Any]:
        r"""
        Amplitude Amplification Algorithm Module (Standalone Class Version)

        Encapsulates the complete process of:

        - Initial state preparation
        - Oracle marking
        - Diffuser reflection
        - Final state verification

        Includes standardized stage logging and an ASCII result panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Amplitude Amplification 算法主程序 (后端={backend.upper()})")
        print("=" * 70)

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 开始准备算法参数...")
        
        n_data = U.get_num_qubits()
        ancilla = n_data  # 辅助比特放在最后一位
        
        if reps is None:
            if not (0.0 < p < 1.0):
                raise ValueError("初始概率 p 必须满足 0 < p < 1.")
            reps = self._get_optimal_iterations(p)
            
        print(f"  - 数据寄存器大小: n = {n_data} (总计 {n_data + 1} 量子比特)")
        print(f"  - 目标状态条件: Qubits {good_zero_qubits} 必须全为 |0>")
        print(f"  - 初始成功概率 p: {p:.4f}")
        print(f"  - 计算得出的迭代步数 (Reps): {reps}")
        print(f"  - 预设模拟后端: {backend}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路 (后端: {backend})...")
        
        gs = GateSequence(n_data + 1, name='Amplitude_Amplification', backend=backend)
        data_qubits = list(range(n_data))

        # 1) 制备初始态 |psi>
        gs.append(U, data_qubits)

        # 2) 展开 Grover/AA 迭代
        for _ in range(reps):
            self._build_oracle(gs, zero_qubits=good_zero_qubits, ancilla=ancilla)
            self._build_diffuser(gs, U=U, data_qubits=data_qubits, ancilla=ancilla)
        
        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟计算...")
        
        start_time = time.time()
        re_state = gs.execute()
        state_obj = State(re_state)
        # 获取数据寄存器的概率分布 (排除辅助比特)
        state_basis_dict = state_obj.calculate_state(data_qubits)
        end_time = time.time()
        comp_time = end_time - start_time

        print(f"  - 计算耗时: {comp_time:.4f} 秒")
        print(f"  - 测量得到有效基态数量: {len(state_basis_dict)}")
        print(f"{self.log_prefix}阶段 3/5: 量子计算完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 开始执行经典后处理 (验证概率放大效果)...")
        
        # 统计符合 good_zero_qubits 条件的目标态的总概率
        target_prob = 0.0
        for basis_str, state_info in state_basis_dict.items():
            # 检查基态字符串中，要求为 '0' 的位置是否确实为 '0'
            is_target = all(basis_str[q] == '0' for q in good_zero_qubits)
            if is_target:
                # 兼容底层环境：如果返回值是一个 dict，则提取其中的概率字段
                if isinstance(state_info, dict):
                    # 尝试读取常见的概率键名，比如 'prob', 'probability' 
                    if 'prob' in state_info:
                        target_prob += float(state_info['prob'])
                    elif 'probability' in state_info:
                        target_prob += float(state_info['probability'])
                    elif 'amp' in state_info:  # 如果只有振幅，则取模平方
                        target_prob += abs(state_info['amp']) ** 2
                    else:
                        # 极端情况：如果键名都不是这些，随便取 dict 里的第一个值凑合一下
                        target_prob += float(list(state_info.values())[0])
                else:
                    # 如果不是 dict（比如有些情况直接返回 float）
                    target_prob += float(state_info)

        # 判定是否放大成功 (至少比初始 p 有显著提升)
        is_success = target_prob > p
        
        print(f"  - 初始目标态概率: {p:.4f}")
        print(f"  - 放大后目标态概率: {target_prob:.4f}")
        print(f"  - 结果验证: {'成功 (概率已放大)' if is_success else '失败 (概率未提升)'}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        # 确保保存目录存在
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        circuit_filename = f"AmpAmp_p{p:.2f}_circuit.svg"
        circuit_path = os.path.join(algo_dir, circuit_filename)
        
        # 使用项目内置的 draw 功能保存电路图
        gs.draw(filename=circuit_path, title=f"Amplitude Amplification (p={p:.2f})")
        
        print(f"  - 电路图已保存至: {circuit_path}")
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        # ================= 结果包装 =================
        msg = "算法执行成功，目标态振幅已显著放大。" if is_success else "算法效果不佳，可能是迭代次数或初始算子 U 存在偏差。"
        
        # 更新内部状态，供 ASCII 面板使用
        self._update_last_result(
            n_data=n_data, ancilla=ancilla, backend=backend, p=p, reps=reps,
            comp_time=comp_time, valid_states=len(state_basis_dict),
            target_prob=target_prob, is_success=is_success,
            circuit_path=circuit_path, msg=msg
        )
        
        return self._build_return(target_prob, is_success, circuit_path, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, n_data, ancilla, backend, p, reps, comp_time, valid_states, target_prob, is_success, circuit_path, msg):
        """The internal state is saved uniformly for format_result_ascii rendering."""
        self.last_result = {
            "n_data": n_data, "ancilla": ancilla, "backend": backend,
            "p": p, "reps": reps, "comp_time": comp_time, 
            "valid_states": valid_states, "target_prob": target_prob,
            "is_success": is_success, "circuit_path": circuit_path,
            "message": msg
        }

    def _build_return(self, target_prob, is_success, circuit_path, msg):
        """Unified construction of returned dictionaries"""
        return {
            "status": "ok" if is_success else "failed",
            "amplified_prob": target_prob,
            "circuit_path": circuit_path,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        """Format the result of the last executed algorithm into beautiful ASCII art."""
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        
        r = self.last_result
        status_emoji = '✅' if r['is_success'] else '❌'
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  AMPLITUDE AMPLIFICATION 结果 ⚛️
{'='*70}

📊 执行状态: {status_emoji} {'成功放大目标态概率' if r['is_success'] else '概率放大失败'}

{'─'*70}
🔢 输入参数
{'─'*70}
  初始成功概率 p: {r['p']:.4f}
  理论迭代步数 (k): {r['reps']}
  模拟后端: {r['backend'].upper()}
{'─'*70}
⚡ 量子电路配置
{'─'*70}
  总量子比特数: {r['n_data'] + 1} (数据: {r['n_data']}, 辅助: 1)
{'─'*70}
🎯 量子计算结果
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
  测量得到有效态数量: {r['valid_states']}
{'─'*70}
🔓 经典后处理结果 (验证)
{'─'*70}
"""
        if r['is_success']:
            ascii_art += f"""  ✓ 放大成功！
  初始概率 p_0: {r['p']:.4f}
  最终概率 p_f: {r['target_prob']:.4f} (显著提升) ✓
"""
        else:
            ascii_art += f"""  ✗ 放大失败！
  初始概率 p_0: {r['p']:.4f}
  最终概率 p_f: {r['target_prob']:.4f} ✗
"""
            
        ascii_art += f"""{'─'*70}
📁 输出文件
{'─'*70}
  量子电路图: {r['circuit_path'] if r.get('circuit_path') else '无'}
{'─'*70}
💡 执行备注
{'─'*70}
  {r['message']}
{'='*70}
🔬 量子计算模拟器 | 振幅放大模块
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件与数学辅助函数 (还原自 test.py)
    # ==========================================================

    def _prepare_kickback_ancilla_minus(self, gs: GateSequence, ancilla: int) -> None:
        """Prepare ancilla in |-> = H X |0>"""
        gs.x(ancilla)
        gs.h(ancilla)

    def _unprepare_kickback_ancilla_minus(self, gs: GateSequence, ancilla: int) -> None:
        """Unprepare ancilla back to |0>"""
        gs.h(ancilla)
        gs.x(ancilla)

    def _build_oracle(self, gs: GateSequence, zero_qubits: List[int], ancilla: int) -> None:
        """Phase flip (-1) on computational basis states where `zero_qubits` are |0>"""
        self._prepare_kickback_ancilla_minus(gs, ancilla)

        for q in zero_qubits:
            gs.x(q)

        controls = list(zero_qubits)
        if len(controls) == 0:
            gs.z(ancilla)
        elif len(controls) == 1:
            gs.cx(controls[0], ancilla)
        else:
            gs.mcx(controls, ancilla)

        for q in zero_qubits:
            gs.x(q)

        self._unprepare_kickback_ancilla_minus(gs, ancilla)

    def _build_diffuser(self, gs: GateSequence, U: GateSequence, data_qubits: List[int], ancilla: int) -> None:
        """Reflection about |psi> = U|0..0>"""
        gs.append(U.dagger(), data_qubits)
        self._build_oracle(gs, zero_qubits=list(data_qubits), ancilla=ancilla)
        gs.append(U, data_qubits)

    def _get_optimal_iterations(self, p: float) -> int:
        """Calculate optimal Grover iteration count based on initial probability p"""
        theta = math.asin(math.sqrt(p))
        # 使用 round() 替代 math.floor() 解决浮点数精度导致的 0.9999 变成 0 的问题
        r = int(round((math.pi / (4.0 * theta)) - 0.5))
        return max(0, r)

if __name__ == "__main__":
    # 测试用例 (数据寄存器 2 个比特)
    U_test = GateSequence(2)
    U_test.h(0)
    U_test.h(1)

    good_zero_qubits = [0, 1]  # 目标态是 |00>
    initial_p = 0.25           # 对于 2 比特均匀叠加态，|00> 的概率是 0.25

    algo = AmplitudeAmplificationAlgorithm()
    result = algo.run(
        U=U_test, 
        good_zero_qubits=good_zero_qubits, 
        p=initial_p, 
        backend='torch'
    )
    
    print(result['plot'])