import time
import os
import numpy as np
from typing import Dict, Any, List, Optional

# 导入项目核心组件
from ....core import GateSequence, Register, State

# ==========================================================
# Hadamard Test 算法类实现
# ==========================================================

class HadamardTestAlgorithm:
    r"""
    Hadamard Test Algorithm (Standalone Version)

    Estimates the complex expectation value of a unitary operator :math:`U`
    with respect to a quantum state :math:`|\psi\rangle` using an ancilla qubit.

    Supports three core application modes:

    1. ``'expectation'``: Standard Hadamard test, which estimates the real or
    imaginary part of :math:`\langle \psi | U | \psi \rangle`.

    2. ``'swap_test'``: Swap test, which estimates the squared inner product
    magnitude between two states:
    :math:`|\langle \phi | \psi \rangle|^2`.

    3. ``'phase_estimation'``: Single-bit phase estimation, which reconstructs
    the eigenphase :math:`\phi` by combining real and imaginary components.
    """
    def __init__(self):
        self.log_prefix = "INFO: [H-Test] "
        self.last_result = None
        self.rng = np.random.default_rng()

    def run(self, mode: str = "expectation", 
            U: Optional[GateSequence] = None, 
            prepare_psi: Optional[GateSequence] = None, 
            prepare_phi: Optional[GateSequence] = None,
            imag: bool = False, 
            shots: int = 20000, 
            backend: str = 'torch', 
            algo_dir = None) -> Dict[str, Any]:
        r"""
        Execute the Hadamard test main flow, supporting expectation estimation,
        state overlap testing, and single-bit phase estimation.

        Args:
            mode (str): Execution mode. One of ``'expectation'``, ``'swap_test'``,
                or ``'phase_estimation'``.
            U (GateSequence): Unitary operator circuit to be evaluated. Not required
                in ``'swap_test'`` mode.
            prepare_psi (GateSequence): Circuit preparing the quantum state
                :math:`|\psi\rangle`.
            prepare_phi (GateSequence): Circuit preparing the quantum state
                :math:`|\phi\rangle`. Only required in ``'swap_test'`` mode.
            imag (bool): Whether to extract the imaginary part. Only valid in
                ``'expectation'`` mode.
            shots (int): Number of measurement samples. Default is ``20000``.
            backend (str): Simulation backend. Currently ``'torch'`` is required.
            algo_dir (str): Directory for saving quantum circuit diagrams.

        Returns:
            Dict[str, Any]: Dictionary containing execution results, including
            the estimated value (``est_val``), circuit diagram paths, and a
            formatted ASCII panel.
        """
        print("=" * 70)
        print(f"{self.log_prefix}启动 Hadamard Test 主程序 (模式={mode.upper()}, 后端={backend.upper()})")
        print("=" * 70)

        start_time = time.time()

        # ================= 阶段 1 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 1/5: 开始解析与验证参数...")
        
        if mode not in ["expectation", "swap_test", "phase_estimation"]:
            raise ValueError("mode 必须是 'expectation', 'swap_test' 或 'phase_estimation'")

        if mode == "swap_test" and (prepare_phi is None or prepare_psi is None):
            raise ValueError("swap_test 模式下必须提供 prepare_phi 和 prepare_psi")
        if mode in ["expectation", "phase_estimation"] and U is None:
            raise ValueError(f"{mode} 模式下必须提供幺正算符 U")

        print(f"  - 运行模式: {mode}")
        print(f"  - 采样次数 (Shots): {shots}")
        print(f"{self.log_prefix}阶段 1/5: 参数准备完成 ✓")

        # ================= 阶段 2 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 2/5: 开始构建量子电路...")
        
        circuits = {}
        
        if mode == "swap_test":
            # 构造 SWAP Test 的 U_swap 和联合态
            n = prepare_phi.get_num_qubits()
            U_swap = GateSequence(2 * n, name="swap ",backend=backend)
            for i in range(n):
                U_swap.swap(i, i + n)
                
            prepare_joint = GateSequence(2 * n, name="Prep(|phi>⊗|psi>)",backend=backend)
            prepare_joint.append(prepare_phi, target=list(range(n)))
            prepare_joint.append(prepare_psi, target=list(range(n, 2 * n)))
            
            gs_real = self._build_hadamard_test_circuit(U_swap, prepare_joint, imag=False,backend=backend)
            circuits["real"] = gs_real
            print(f"  - 已构建 SWAP Test 电路 (目标系统: {2*n} Qubits)")
            
        elif mode == "phase_estimation":
            # 相位估计需要同时运行实部和虚部电路
            gs_real = self._build_hadamard_test_circuit(U, prepare_psi, imag=False,backend=backend)
            gs_imag = self._build_hadamard_test_circuit(U, prepare_psi, imag=True,backend=backend)
            circuits["real"] = gs_real
            circuits["imag"] = gs_imag
            print(f"  - 已构建用于相位估计的 Real & Imag 电路")
            
        else:
            # 基础 Expectation 模式
            gs = self._build_hadamard_test_circuit(U, prepare_psi, imag=imag,backend=backend)
            circuits["main"] = gs
            print(f"  - 已构建基础 Hadamard Test 电路 (Imag={imag})")

        print(f"{self.log_prefix}阶段 2/5: 量子电路构建完成 ✓")

        # ================= 阶段 3 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 3/5: 执行量子模拟与统计采样...")
        
        measurements = {}
        for name, circ in circuits.items():
            statevec = self._as_statevector(circ.execute())
            state_obj = State(statevec)
            
            # 读取辅助比特 (qubit 0) 的测量概率
            anc_probs = state_obj.probabilities_dict([0], endian="little", threshold=0.0)
            p0_exact = float(anc_probs.get("0", 0.0))
            
            # 加入 Shot 噪声模拟
            if shots is not None and shots > 0:
                c0 = int(self.rng.binomial(int(shots), p0_exact))
                p0 = c0 / float(shots)
            else:
                p0 = p0_exact
                
            p1 = 1.0 - p0
            exp_val = p0 - p1  # <Z> = p(0) - p(1)
            measurements[name] = exp_val
            print(f"  - [{name.upper()}] 分支测得 <Z> 期望值: {exp_val:.6f}")

        print(f"{self.log_prefix}阶段 3/5: 量子计算与采样完成 ✓")

        # ================= 阶段 4 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 4/5: 经典后处理与估计提取...")
        
        est_val = None
        msg = ""

        if mode == "expectation":
            est_val = measurements["main"]
            val_type = "Im" if imag else "Re"
            msg = f"估计得 {val_type}(<psi|U|psi>) = {est_val:.6f}"
            
        elif mode == "swap_test":
            overlap_sq = float(np.clip(measurements["real"], 0.0, 1.0))
            est_val = overlap_sq
            msg = f"估计得态交叠度 |<phi|psi>|^2 = {overlap_sq:.6f}"
            
        elif mode == "phase_estimation":
            re_est = measurements["real"]
            im_est = measurements["imag"]
            est_val = self._estimate_phi_from_real_imag(re_est, im_est)
            msg = f"结合实虚部，估计得本征相位 phi = {est_val:.6f}"

        print(f"  - 最终处理结果: {msg}")
        print(f"{self.log_prefix}阶段 4/5: 处理完成 ✓")

        # ================= 阶段 5 =================
        print("=" * 50)
        print(f"{self.log_prefix}阶段 5/5: 导出量子电路图...")
        
        if algo_dir is None:
            _this = os.path.abspath(__file__)
            algo_dir = os.path.join(os.getcwd(), "results",
                                    os.path.basename(os.path.dirname(os.path.dirname(_this))),
                                    os.path.basename(os.path.dirname(_this)))
        os.makedirs(algo_dir, exist_ok=True)
        saved_paths = []
        for name, circ in circuits.items():
            circuit_filename = f"HadamardTest_{mode}_{name}.svg"
            circuit_path = os.path.join(algo_dir, circuit_filename)
            circ.draw(filename=circuit_path, title=f"Hadamard Test ({mode} - {name})")
            saved_paths.append(circuit_path)
            print(f"  - [{name.upper()}] 电路图已保存至: {circuit_path}")
            
        print(f"{self.log_prefix}阶段 5/5: 导出完成 ✓")

        comp_time = time.time() - start_time

        # ================= 结果包装 =================
        self._update_last_result(
            mode=mode, shots=shots, backend=backend, comp_time=comp_time,
            est_val=est_val, saved_paths=saved_paths, msg=msg
        )
        
        return self._build_return(est_val, saved_paths, msg)

    # ==========================================================
    # 面板与状态管理辅助方法
    # ==========================================================
    def _update_last_result(self, mode, shots, backend, comp_time, est_val, saved_paths, msg):
        self.last_result = {
            "mode": mode, "shots": shots, "backend": backend,
            "comp_time": comp_time, "est_val": est_val, 
            "saved_paths": saved_paths, "message": msg
        }

    def _build_return(self, est_val, saved_paths, msg):
        return {
            "status": "success",
            "estimated_value": est_val,
            "circuit_paths": saved_paths,
            "message": msg,
            "plot": self.format_result_ascii()
        }

    def format_result_ascii(self) -> str:
        if self.last_result is None:
            return "尚未执行算法，请先调用 run() 方法"
        
        r = self.last_result
        
        ascii_art = f"""
{'='*70}
{' '*15}⚛️  HADAMARD TEST 结果 ⚛️
{'='*70}

📊 核心提取结果: {r['est_val']:.6f}

{'─'*70}
🔢 算法配置
{'─'*70}
  运行模式: {r['mode']}
  采样次数 (Shots): {r['shots']}
  模拟后端: {r['backend'].upper()}
{'─'*70}
⚡ 执行统计
{'─'*70}
  计算耗时: {r['comp_time']:.4f} 秒
{'─'*70}
📁 输出文件
{'─'*70}
"""
        for path in r['saved_paths']:
            ascii_art += f"  电路图: {path}\n"
            
        ascii_art += f"""{'─'*70}
💡 执行备注
{'─'*70}
  {r['message']}
{'='*70}
"""
        return ascii_art

    # ==========================================================
    # 内部量子组件与数学辅助函数 (还原自 test.py)
    # ==========================================================
    def _as_statevector(self, result) -> np.ndarray:
        return np.asarray(result, dtype=complex).reshape(-1)

    def _build_hadamard_test_circuit(self, U: GateSequence, prepare_psi: Optional[GateSequence] = None, imag: bool = False,backend='torch') -> GateSequence:
        n = U.get_num_qubits()
        qc = GateSequence(1 + n, name="HadamardTest",backend=backend)
        anc = 0
        tgt = list(range(1, 1 + n))

        qc.h(anc)
        if imag:
            qc.sdag(anc)

        if prepare_psi is not None:
            if prepare_psi.get_num_qubits() != n:
                raise ValueError("prepare_psi 的比特数必须与 U 一致。")
            qc.append(prepare_psi, target=tgt)

        qc.append(U, target=tgt, control=[anc], control_sequence="1")
        qc.h(anc)
        return qc

    def _estimate_phi_from_real_imag(self, cos_est: float, sin_est: float) -> float:
        angle = float(np.arctan2(sin_est, cos_est))
        phi = float((angle / (2.0 * np.pi)) % 1.0)
        return phi

# ==========================================================
# Main 测试入口
# ==========================================================
if __name__ == "__main__":
    algo = HadamardTestAlgorithm()
    
    # ---------------------------------------------------------
    # 测试案例 1: 单比特相位估计 U = Rz(0.8), |psi> = |1>
    # ---------------------------------------------------------
    backend='unitarylab'
    theta = 0.8
    U_test = GateSequence(1,backend=backend)
    U_test.rz(theta, 0)
    
    prep_psi = GateSequence(1,backend=backend)
    prep_psi.x(0)
    
    print("\n>>> 运行模式: Phase Estimation (相位估计)")
    res_phase = algo.run(
        mode="phase_estimation", 
        U=U_test, prepare_psi=prep_psi, shots=30000,backend=backend
    )
    print(res_phase['plot'])

    # ---------------------------------------------------------
    # 测试案例 2: SWAP Test (比较 |0> 和 |+>)
    # ---------------------------------------------------------
    phi_state = GateSequence(1,backend=backend) # |0>
    psi_state = GateSequence(1,backend=backend)
    psi_state.h(0)              # |+>
    
    print("\n>>> 运行模式: SWAP Test (交叠测试)")
    res_swap = algo.run(
        mode="swap_test",
        prepare_phi=phi_state, prepare_psi=psi_state, shots=30000,backend=backend
    )
    print(res_swap['plot'])